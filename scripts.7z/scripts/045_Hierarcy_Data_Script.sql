--Use STEP_AMC_9
GO
Declare @CreatedBy Varchar(50)
Declare @CreatedDate DateTime
Set @CreatedBy ='Plateauinc'
Set @CreatedDate=GETDATE()

-- Update the Code for HQ
IF Exists (Select 1 from Hierarchy_Data Where Id=1 And Code<>'HQAMC' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'HQAMC' where Id = 1 
End

 -- HQ
 IF Not Exists (Select 1 from Hierarchy_Data Where Id=1 And Parent_Id Is Null  And Code='HQAMC') 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(1,NULL,'HQAMC','Head Quarters',1200,'HQ',Null,Null,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for AMCOM 
IF Exists (Select 1 from Hierarchy_Data Where Id=2 And Code<>'AMCOM' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'AMCOM' where Id = 2 
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=2 And Parent_Id=1  And Code='AMCOM' ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(2,1,'AMCOM','US Army Aviation Missile Life Cycle Management Command',1200,'MSC',Null,Null,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for Letterkenny
IF Exists (Select 1 from Hierarchy_Data Where Id=3 And Code<>'LEAD' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'LEAD' where Id = 3 
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=3 And Parent_Id=2  And Code='LEAD'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(3,2,'LEAD','Letterkenny Army Depot',1200,'INST',200,'PA',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End


IF Not Exists (Select 1 from Hierarchy_Data Where Id=4 And Parent_Id=2  And Code='CCAD'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(4,2,'CCAD','Corpus Christi Army Depot',1200,'INST',200,'PA',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End
-- MSC Id = 2
-- Update the Code for MSC Communication Electronics Life Cycle command
IF Exists (Select 1 from Hierarchy_Data Where Id=5 And Code<>'CECOM' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'CECOM' where Id = 5 
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=5 And Parent_Id=1  And Code='CECOM'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(5,1,'CECOM','US Army Communications - Electronics Life Cycle Management Command',1200,'MSC',Null,Null,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update Tobyhanna code for existing record
IF Exists (Select 1 from Hierarchy_Data Where Id=6 And Code<>'TYAD' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'TYAD' where Id = 6
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=6 And Parent_Id=5  And Code='TYAD'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(6,5,'TYAD','Tobyhanna Army Depot',1200,'INST',200,'PA',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for Chemical Material Activity
IF Exists (Select 1 from Hierarchy_Data Where Id=7 And Code<>'CMA' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'CMA' where Id = 7
End

-- MSC Id = 3
IF Not Exists (Select 1 from Hierarchy_Data Where Id=7 And Parent_Id=1  And Code = 'CMA' ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(7,1,'CMA','US Army Chemical Material Activity',1200,'MSC',Null,Null,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for Pueblo
IF Exists (Select 1 from Hierarchy_Data Where Id=8 And Code<>'PDC' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'PDC' where Id = 8 
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=8 And Parent_Id=7  And Code='PDC') 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(8,7,'PDC','Pueblo Chemical Depot',1200,'INST',200,'CO',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for MSC Joint Munitions
IF Exists (Select 1 from Hierarchy_Data Where Id=9 And Code<>'JMC' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'JMC' where Id = 9 
End

-- MSC Id = 4
IF Not Exists (Select 1 from Hierarchy_Data Where Id=9 And Parent_Id=1  And Code='JMC' ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES	
	(9,1,'JMC','Joint Munitions & Lethality Life Cycle Management Command/US Army Joint Munitions Command',1200,'MSC',
	Null,Null,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for Tooele
IF Exists (Select 1 from Hierarchy_Data Where Id=10 And Code<>'TEAD' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'TEAD' where Id = 10 
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=10 And Parent_Id=9  And Code='TEAD'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(10,9,'TEAD','Tooele Army Depot',1200,'INST',200,'UT',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for Scranton
IF Exists (Select 1 from Hierarchy_Data Where Id=11 And Code<>'SCAAP' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'SCAAP' where Id = 11
End


IF Not Exists (Select 1 from Hierarchy_Data Where Id=11 And Parent_Id=9  And Code='SCAAP'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(11,9,'SCAAP','Scranton Army Ammunition Plant',1200,'INST',200,'PA',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for Radford
IF Exists (Select 1 from Hierarchy_Data Where Id=12 And Code<>'RFAAP' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'RFAAP' where Id = 12
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=12 And Parent_Id=9  And Code='RFAAP'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(12,9,'RFAAP','Radford Army Ammunition Plant',1200,'INST',200,'VA',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for Pine Bluff
IF Exists (Select 1 from Hierarchy_Data Where Id=13 And Code<>'PBA' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'PBA' where Id = 13 
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=13 And Parent_Id=9  And Code='PBA'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(13,9,'PBA','Pine Bluff Arsenal',1200,'INST',200,'AR',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for Milan Army
IF Exists (Select 1 from Hierarchy_Data Where Id=14 And Code<>'MIAAP' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'MIAAP' where Id = 14
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=14 And Parent_Id=9  And Code='MIAAP'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(14,9,'MIAAP','Milan Army Ammunition Plant',1200,'INST',200,'TN',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for McAlester
IF Exists (Select 1 from Hierarchy_Data Where Id=15 And Code<>'MCAAP' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'MCAAP' where Id = 15
End


IF Not Exists (Select 1 from Hierarchy_Data Where Id=15 And Parent_Id=9  And Code='MCAAP'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(15,9,'MCAAP','McAlester Army Ammunition Plant',1200,'INST',200,'OK',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for Lake City
IF Exists (Select 1 from Hierarchy_Data Where Id=16 And Code<>'LCAAP' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'LCAAP' where Id = 16 
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=16 And Parent_Id=9  And Code='LCAAP'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(16,9,'LCAAP','Lake City Army Ammunition Plant',1200,'INST',200,'MO',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for IOWA
IF Exists (Select 1 from Hierarchy_Data Where Id=17 And Code<>'IAAAP' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'IAAAP' where Id = 17 
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=17 And Parent_Id=9  And Code='IAAAP'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(17,9,'IAAAP','Iowa Army Ammunition Plant',1200,'INST',200,'IA',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for Hawthorne
IF Exists (Select 1 from Hierarchy_Data Where Id=18 And Code<>'HAAD' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'HAAD' where Id = 18
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=18 And Parent_Id=9  And Code='HAAD'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(18,9,'HAAD','Hawthorne Army Depot',1200,'INST',200,'NV',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=19 And Parent_Id=9  And Code='HAAP'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(19,9,'HAAP','Holston Army Ammunition Plant',1200,'INST',200,'TN',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=20 And Parent_Id=9  And Code='CAAA'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(20,9,'CAAA','Crane Army Ammunition Activity',1200,'INST',200,'IN',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=21 And Parent_Id=9  And Code='BGAD'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(21,9,'BGAD','Blue Grass Army Depot',1200,'INST',200,'KY',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for Tank automative
IF Exists (Select 1 from Hierarchy_Data Where Id=22 And Code<>'TACOM' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'TACOM' where Id = 22
End

-- MSC Id = 5
IF Not Exists (Select 1 from Hierarchy_Data Where Id=22 And Parent_Id=1  And Code='TACOM'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(22,1,'TACOM','US Army Tank-automotive and Armaments Life Cycle Management Command',1200,'MSC',Null,Null,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for watervliet
IF Exists (Select 1 from Hierarchy_Data Where Id=23 And Code<>'WVAD' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'WVAD' where Id = 23 
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=23 And Parent_Id=22  And Code='WVAD'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(23,22,'WVAD','Watervliet Arsenal',1200,'INST',200,'NY',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for Sierra
IF Exists (Select 1 from Hierarchy_Data Where Id=24 And Code<>'SIAD' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'SIAD' where Id = 24
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=24 And Parent_Id=22  And Code='SIAD'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(24,22,'SIAD','Sierra Army Depot',1200,'INST',200,'CA',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=25 And Parent_Id=22  And Code='RRAD'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(25,22,'RRAD','Red River Army Depot',1200,'INST',200,'TX',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=26 And Parent_Id=22  And Code='ANAD'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(26,22,'ANAD','Anniston Army Depot',1200,'INST',200,'AL',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for Joint Systesm Lima
IF Exists (Select 1 from Hierarchy_Data Where Id=27 And Code<>'LIMA' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'LIMA' where Id = 27
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=27 And Parent_Id=22  And Code='LIMA'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(27,22,'LIMA','Joint Systems Manufacturing Center-Lima',1200,'INST',200,'OH',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End
-- MSC Id = 6

IF Not Exists (Select 1 from Hierarchy_Data Where Id=28 And Parent_Id=1  And Code= 'SDDC' ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(28,1,'SDDC','US Army Military Surface Deployment and Distribution Command',1200,'MSC',Null,Null,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for Military Ocean Terminal Sunny Point (MOTSU), N.Carolina
IF Exists (Select 1 from Hierarchy_Data Where Id=29 And Name <>'Military Ocean Terminal Sunny Point' ) 
Begin
	Update [Hierarchy_Data] Set Name = 'Military Ocean Terminal Sunny Point' where Id = 29 	
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=29 And Parent_Id=28  And Code='MOTSU'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(29,28,'MOTSU','Military Ocean Terminal Sunny Point',1200,'INST',200,'NC',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

-- Update the Code for Military Ocean Terminal Concord (MOTCO), California
IF Exists (Select 1 from Hierarchy_Data Where Id=30 And Code<>'MOTCO' ) 
Begin
	Update [Hierarchy_Data] Set Code = 'MOTCO' where Id = 30 
	Update [Hierarchy_Data] Set Name = 'Military Ocean Terminal Concord' where Id = 30 
	
End

IF Not Exists (Select 1 from Hierarchy_Data Where Id=30 And Parent_Id=28  And Code='MOTCO'  ) 
Begin
	INSERT INTO [Hierarchy_Data]([Id] ,[Parent_Id],[Code],[Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key],[State_Id],[State_Key],
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(30,28,'MOTCO','Military Ocean Terminal Concord',1200,'INST',200,'CA',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End