 --Use STEP_AMC_9
GO
/****** Table creation for Code******/
IF NOT EXISTS(SELECT 1 FROM sys.tables WHERE name = 'Code')
BEGIN
	CREATE TABLE [dbo].[Code](
	[Id] [int] NOT NULL,
	[Code_Description] [nvarchar](250) NOT NULL,
	[Created_By] [nvarchar](100) NOT NULL,
	[Created_Date] [datetime] NOT NULL,
	[Modified_By] [nvarchar](100)NOT NULL,
	[Modified_Date] [datetime] NOT NULL,
 CONSTRAINT [PK_Code] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

	Print '[Code] Table Created'
END
GO

/****** Table creation for Code_Value ******/
IF NOT EXISTS(SELECT 1 FROM sys.tables WHERE name = 'Code_Value')
BEGIN
	CREATE TABLE [dbo].[Code_Value](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Code_ID] [int] NOT NULL,
	[Code_Value_Key] [nvarchar](4) NOT NULL,
	[Code_Value_Description] [nvarchar](250) NULL,
	[Data1] [NVarchar](500) NULL,
	[Data2] [nvarchar](250) NULL,
	[Data3] [nvarchar](250) NULL,
	[SequenceNumber] [int] NULL,
	[Created_By] [nvarchar](100) NOT NULL,
	[Created_Date] [datetime] NOT NULL,
	[Modified_By] [nvarchar](100)NOT NULL,
	[Modified_Date] [datetime] NOT NULL,
 CONSTRAINT [PK_Code_Value] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

	ALTER TABLE [dbo].[Code_Value]  WITH CHECK ADD  CONSTRAINT [FK_Code_Value_Code] FOREIGN KEY([Code_ID])
	REFERENCES [dbo].[Code] ([Id])
	 

	ALTER TABLE [dbo].[Code_Value] CHECK CONSTRAINT [FK_Code_Value_Code]

	Print '[Code_Value] Table Created'
END
GO


/****** Table creation for Role ******/
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name='Role')
Begin
	CREATE TABLE [dbo].[Role](
	[Id] [int] NOT NULL,
	[Role_Key] [nvarchar](100) NULL,
	[Name] [nvarchar](75) NOT NULL,
	[Hierarchy_Level_Id] [int] NOT NULL,
	[Hierarchy_Level_Key] [nvarchar](4) NOT NULL,
	[Role_Group_Id] [int] NULL,
	[Role_Group_Key] [nvarchar](4) NULL,
	[Created_By] [nvarchar](100) NOT NULL,
	[Created_Date] [datetime] NOT NULL,
	[Modified_By] [nvarchar](100) NOT NULL,
	[Modified_Date] [datetime] NOT NULL,
	 CONSTRAINT [PK_Role] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
	Print '[Role] table created'		
End
GO

/****** Table creation for Action ******/
IF NOT EXISTS(SELECT 1 FROM sys.tables WHERE name = 'Action')
Begin
	CREATE TABLE [dbo].[Action](
		[Id] [int] NOT NULL,
		[Action_Name] [nvarchar](50) NOT NULL,
		[Action_Target] [int] NULL,
		[Action_Parent_Id] [int] NULL,
		[Action_Description] [nvarchar](200) NULL,
		[Created_By] [nvarchar](100) NOT NULL,
		[Created_Date] [datetime] NOT NULL,
		[Modified_By] [nvarchar](100)NOT NULL,
		[Modified_Date] [datetime] NOT NULL,
	 CONSTRAINT [PK_Action] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [dbo].[Action]  WITH CHECK ADD  CONSTRAINT [FK_Action_Parent] FOREIGN KEY([Action_Parent_Id])
	REFERENCES [dbo].[Action] ([Id])

	ALTER TABLE [dbo].[Action] CHECK CONSTRAINT [FK_Action_Parent]
	
	Print '[Action] table created'
End
GO

/****** Table creation for Role_Action ****************************/
IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'Role_Action')
Begin
	CREATE TABLE [dbo].[Role_Action](
		[Id] [int] NOT NULL,
		[Role_Id] [int] NOT NULL,
		[Action_Id] [int] NOT NULL,
		[Is_Allowed] [bit] NULL,
		[Created_By] [nvarchar](100) NOT NULL,
		[Created_Date] [datetime] NOT NULL,
		[Modified_By] [nvarchar](100)NOT NULL,
		[Modified_Date] [datetime] NOT NULL,
	 CONSTRAINT [PK_Role_Action] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
		
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
	ALTER TABLE [dbo].[Role_Action]  WITH CHECK ADD  CONSTRAINT [FK_Role_Action_Role] FOREIGN KEY([Role_Id])
	REFERENCES [dbo].[Role] ([Id])

	ALTER TABLE [dbo].[Role_Action] CHECK CONSTRAINT [FK_Role_Action_Role]

	ALTER TABLE [dbo].[Role_Action]  WITH CHECK ADD  CONSTRAINT [FK_Role_Action] FOREIGN KEY([Action_Id])
	REFERENCES [dbo].[Action] ([Id])

	ALTER TABLE [dbo].[Role_Action] CHECK CONSTRAINT [FK_Role_Action]
	Print '[Role_Action] table created'
End
GO

/* adding identity to Id coulumn in role_action table */
GO
IF EXISTS(SELECT * FROM sys.foreign_keys WHERE parent_object_id = OBJECT_ID(N'dbo.Role_Action'))
 BEGIN 
ALTER TABLE Role_Action DROP CONSTRAINT FK_Role_Action_Role 
END 

GO 

IF EXISTS(SELECT * FROM sys.foreign_keys WHERE parent_object_id = OBJECT_ID(N'dbo.Role_Action'))
 BEGIN 
ALTER TABLE Role_Action DROP CONSTRAINT FK_Role_Action 
END 

GO

IF EXISTS(SELECT * FROM sys.key_constraints WHERE parent_object_id = OBJECT_ID(N'dbo.Role_Action'))
 BEGIN 
ALTER TABLE Role_Action DROP CONSTRAINT PK_Role_Action 
END 


/* adding identity to Id coulumn in role_action table   */
Alter TABLE [dbo].Role_Action drop column [id]
GO
alter table Role_Action add  [Id] [int] CONSTRAINT PK_Role_Action PRIMARY KEY (Id) IDENTITY(1,1) NOT NULL
GO

IF NOT EXISTS(SELECT * FROM sys.foreign_keys WHERE parent_object_id = OBJECT_ID(N'dbo.Role_Action'))
 BEGIN 
	ALTER TABLE Role_Action ADD CONSTRAINT FK_Role_Action_Role FOREIGN KEY (Role_id) REFERENCES role(Id)
	ALTER TABLE Role_Action ADD CONSTRAINT FK_Role_Action FOREIGN KEY (Action_id) REFERENCES Action(Id)
END 

GO
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE Name = N'Type_Id' AND OBJECT_ID = OBJECT_ID(N'Action'))
BEGIN
	ALTER TABLE dbo.Action add  [Type_Id] int
END
GO
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE Name = N'Type_Key' AND OBJECT_ID = OBJECT_ID(N'Action'))
BEGIN
	ALTER TABLE dbo.Action add  [Type_Key] nvarchar(4)
END
GO

/****** Table creation for Role_Action ****************************/
IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'Role_Invitation_Mapping')
Begin
	
CREATE TABLE [dbo].[Role_Invitation_Mapping](
	[Id] [int] NOT NULL,
	[Parent_Role_Id] [int] NOT NULL,
	[Child_Role_Id] [int] NOT NULL,
	[Created_By] [nvarchar](100) NOT NULL,
	[Created_Date] [datetime] NOT NULL,
	[Modified_By] [nvarchar](100) NOT NULL,
	[Modified_Date] [datetime] NOT NULL,
 CONSTRAINT [PK_Role_Invitation_Mapping] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

	ALTER TABLE [dbo].[Role_Invitation_Mapping]  WITH CHECK ADD  CONSTRAINT [FK_Role_Role_Invitation_Mapping_Role_ParentRoleId] FOREIGN KEY([Parent_Role_Id])
	REFERENCES [dbo].[Role] ([Id])

	ALTER TABLE [dbo].[Role_Invitation_Mapping] CHECK CONSTRAINT [FK_Role_Role_Invitation_Mapping_Role_ParentRoleId]

	ALTER TABLE [dbo].[Role_Invitation_Mapping]  WITH CHECK ADD  CONSTRAINT [FK_Role_RoleMapping_Role_ChildRoleId] FOREIGN KEY([Child_Role_Id])
	REFERENCES [dbo].[Role] ([Id])
	 
	ALTER TABLE [dbo].[Role_Invitation_Mapping] CHECK CONSTRAINT [FK_Role_RoleMapping_Role_ChildRoleId]
	
	Print '[Role_Invitation_Mapping] table created'
	
End
GO

/****** Table creation for Hierarchy_Data ****************************/
IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'Hierarchy_Data')
Begin
	CREATE TABLE [dbo].[Hierarchy_Data](
	[Id] [int] NOT NULL,
	[Parent_Id] [int] NULL,
	[Code] [nvarchar](25) NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Hierarchy_Level_Id] [int] NOT NULL,
	[Hierarchy_Level_Key] [nvarchar](4) NOT NULL,
	[State_Id] [int] NULL,
	[State_Key] [nvarchar](4) NULL,
	[Created_By] [nvarchar](100) NOT NULL,
	[Created_Date] [datetime] NOT NULL,
	[Modified_By] [nvarchar](100) NOT NULL,
	[Modified_Date] [datetime] NOT NULL,
	 CONSTRAINT [PK_Hierarchy_Data] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [dbo].[Hierarchy_Data]  WITH CHECK ADD  CONSTRAINT [FK_Hierarchy_Data_Mapping_Parent_Id] FOREIGN KEY([Parent_Id])
	REFERENCES [dbo].[Hierarchy_Data] ([Id])

	ALTER TABLE [dbo].[Hierarchy_Data] CHECK CONSTRAINT [FK_Hierarchy_Data_Mapping_Parent_Id]
	 
	Print '[Hierarchy_Data] table created'
End
GO

/****** Table creation for Users ******/
IF NOT EXISTS (SELECT * FROM SYS.TABLES WHERE name='Users')
Begin
    CREATE TABLE [dbo].[Users](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Email_Id] [nvarchar](50) NOT NULL,
	[Ako_Email_Id] [nvarchar](50) NULL,
	[Title] [nvarchar](50) NULL,
	[First_Name] [nvarchar](50) NOT NULL,
	[Middle_Name] [nvarchar](50) NULL,
	[Last_Name] [nvarchar](50) NOT NULL,
	[Password] [nvarchar](250) NOT NULL,
	[Address_Line1] [nvarchar](50) NULL,
	[Address_Line2] [nvarchar](50) NULL,
	[City] [nvarchar](50) NULL,
	[State_Id] [int] NULL,
	[State_Key] [char](4) NULL,
	[Zip] [nvarchar](10) NULL,
	[Phone] [nvarchar](50) NULL,
	[Organization] [nvarchar](50) NULL,
	[User_Status_Id] [int] NOT NULL,
	[User_Status_Key] [nvarchar](4) NOT NULL,
	[Created_By] [nvarchar](100) NOT NULL,
	[Created_Date] [datetime] NOT NULL,
	[Modified_By] [nvarchar](100) NOT NULL,
	[Modified_Date] [datetime] NOT NULL,
	 CONSTRAINT [PK_Users] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
 
	Print '[Users] table created'
End 
GO

/****** Table creation for User_Role ******/
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name='User_Role')
Begin
	CREATE TABLE User_Role
	(
		Id INT NOT NULL identity(1,1),
		User_Id int NOT NULL, 
		Role_Id INT NOT NULL,
		[Created_By] [nvarchar](100) NOT NULL,
		[Created_Date] [datetime] NOT NULL,
		[Modified_By] [nvarchar](100)NOT NULL,
		[Modified_Date] [datetime] NOT NULL,
		CONSTRAINT [PK_User_role] PRIMARY KEY CLUSTERED 
		(
			[Id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]

	ALTER TABLE [dbo].[User_Role]  WITH CHECK ADD  CONSTRAINT [FK_User_role_Roles] FOREIGN KEY([Role_id])
	REFERENCES [dbo].[Role] ([Id])

	ALTER TABLE [dbo].[User_Role] CHECK CONSTRAINT [FK_User_role_Roles]


	ALTER TABLE [dbo].[User_Role]  WITH CHECK ADD  CONSTRAINT [FK_User_Role_User] FOREIGN KEY([User_Id])
	REFERENCES [dbo].[Users] ([Id]) ON DELETE CASCADE

	ALTER TABLE [dbo].[User_Role] CHECK CONSTRAINT [FK_User_Role_User]
		
	Print '[User_Role] table created'
End
GO
/****** Table creation for User_Role_Hierarchy_Assoication ******/
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name='User_Role_Hierarchy_Assoication')
Begin
    CREATE TABLE User_Role_Hierarchy_Assoication
    (
        Id INT NOT NULL identity(1,1),
        Hierarchy_Data_Id int  NULL, 
        User_Role_Id INT  NULL,
		[Created_By] [nvarchar](100) NOT NULL,
		[Created_Date] [datetime] NOT NULL,
		[Modified_By] [nvarchar](100)NOT NULL,
		[Modified_Date] [datetime] NOT NULL,
	 CONSTRAINT [PK_User_Role_Hierarchy_Assoication] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [dbo].[User_Role_Hierarchy_Assoication]  WITH CHECK ADD CONSTRAINT [FK_User_Role_Hierarchy_Assoication_User_role] FOREIGN KEY([User_role_id])
	REFERENCES [dbo].[User_role] ([Id]) ON DELETE CASCADE;

	ALTER TABLE [dbo].[User_Role_Hierarchy_Assoication] CHECK CONSTRAINT [FK_User_Role_Hierarchy_Assoication_User_role]

	ALTER TABLE [dbo].[User_Role_Hierarchy_Assoication]  WITH CHECK ADD  CONSTRAINT [FK_User_Role_Hierarchy_Assoication_Hierarchy] FOREIGN KEY([Hierarchy_Data_id])
	REFERENCES [dbo].[Hierarchy_Data] ([Id])

	ALTER TABLE [dbo].[User_Role_Hierarchy_Assoication] CHECK CONSTRAINT [FK_User_Role_Hierarchy_Assoication_Hierarchy]
	
	Print '[User_Role_Hierarchy_Assoication] table created'
End
GO

/****** Table creation for User_Preference ******/
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name='User_Preference')
Begin
    CREATE TABLE [dbo].[User_Preference](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[User_Id] [int] NOT NULL,
	[Theme_Id] [int] NOT NULL,
	[Theme_Key] [nvarchar](4) NOT NULL,
	[Page_Size_Id] [int] NOT NULL,
	[Page_Size_Key] [nvarchar](4) NOT NULL,
	[Created_By] [nvarchar](100) NOT NULL,
	[Created_Date] [datetime] NOT NULL,
	[Modified_By] [nvarchar](100)NOT NULL,
	[Modified_Date] [datetime] NOT NULL,
 CONSTRAINT [PK_User_Preference] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

	ALTER TABLE [dbo].[User_Preference]  WITH CHECK ADD  CONSTRAINT [FK_User_Preference_User] FOREIGN KEY([User_Id])
	REFERENCES [dbo].[Users] ([Id])

	ALTER TABLE [dbo].[User_Preference] CHECK CONSTRAINT [FK_User_Preference_User]

	Print '[User_Preference] Table created'
End
GO

/****** Table creation for User_Role_Pillar_Association ****************************/
IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'User_Role_Pillar_Association ')
Begin
	CREATE TABLE [dbo].[User_Role_Pillar_Association](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[User_Role_Id] [int] NOT NULL,
	[Pillar_Id] [int] NOT NULL,
	[Pillar_Key] [nvarchar](4) NOT NULL,
	[LawReg_Id] [int] NOT NULL,
	[LawReg_Key] [nvarchar](4) NOT NULL,
	[ProgramArea_Id] [int] NOT NULL,
	[ProgramArea_Key] [nvarchar](4) NOT NULL,
	[Created_By] [nvarchar](100) NOT NULL,
	[Created_Date] [datetime] NOT NULL,
	[Modified_By] [nvarchar](100) NOT NULL,
	[Modified_Date] [datetime] NOT NULL,
 CONSTRAINT [PK_User_Role_Pillar_Association] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

	ALTER TABLE [dbo].[User_Role_Pillar_Association]  WITH CHECK ADD  CONSTRAINT [FK_User_Role_Pillar_Association_User_Role_Id_UserRoleId] FOREIGN KEY([User_Role_Id])
	REFERENCES [dbo].[User_Role] ([Id])

	ALTER TABLE [dbo].[User_Role_Pillar_Association] CHECK CONSTRAINT [FK_User_Role_Pillar_Association_User_Role_Id_UserRoleId]
 
	Print '[User_Role_Pillar_Association] Table Created'
End
GO

/****** Table creation for Pillar_PB28_Mapping ****************************/
IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'Pillar_PB28_Mapping')
Begin
	CREATE TABLE [dbo].[Pillar_PB28_Mapping](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[Pillar_Id] Int NOT NULL,			 
		[Pillar_Key] NVarchar(4) NOT NULL,
		[Title_Id] Int NOT NULL,
        [Title_Key] NVarchar(4) NOT NULL,
        [Category_Id] Int NOT Null,
        [Category_Key] NVarchar(4) NOT NULL,       
        [SubCategory_Id] Int NOT Null,
        [SubCategory_Key] NVarchar(4) NOT NULL,       
		[Created_By] [nvarchar](100) NOT NULL,
		[Created_Date] [datetime] NOT NULL,
		[Modified_By] [nvarchar](100)NOT NULL,
		[Modified_Date] [datetime] NOT NULL,
	 CONSTRAINT [PK_Pillar_PB28_Mapping] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

	Print '[Pillar_PB28_Mapping] table created'
End
GO

/****** Table creation for Pillar_LawReg_Mapping ****************************/
IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'Pillar_LawReg_Mapping')
Begin
	CREATE TABLE [dbo].[Pillar_LawReg_Mapping](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[Pillar_Id] Int NOT NULL,			 
		[Pillar_Key] NVarchar(4) NOT NULL,
		[LawReg_Id] Int NOT NULL,
        [LawReg_Key] NVarchar(4) NOT NULL,
        [ProgramArea_Id] Int NOT NULL,
        [ProgramArea_Key] NVarchar(4) NOT NULL,       
		[Created_By] [nvarchar](100) NOT NULL,
		[Created_Date] [datetime] NOT NULL,
		[Modified_By] [nvarchar](100)NOT NULL,
		[Modified_Date] [datetime] NOT NULL,
	 CONSTRAINT [PK_Pillar_LawReg_Mapping] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
	
	Print '[Pillar_LawReg_Mapping] table created'
End
GO

/**************** Table creation for Catalog ************************/

IF NOT EXISTS(SELECT 1 FROM sys.tables WHERE name = 'Catalog')
BEGIN
	CREATE TABLE [dbo].[Catalog](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Catalog_Number] [nvarchar](50) NOT NULL,
	[Catalog_Name] [nvarchar](500) NOT NULL,
	[Class_Id] Int NOT NULL,
    [Class_Key] NVarchar(4) NOT NULL,
	[Status_Id] Int NOT NULL,
    [Status_Key] NVarchar(4) NOT NULL,
	[Pillar_Lawreg_Mapping_Id] [int] NOT NULL,
	[Pillar_PB28_Mapping_Id] [int] NOT NULL,
	[Catalog_Narrative] [nvarchar](max) NOT NULL,
	[Created_By] [nvarchar](100) NOT NULL,
	[Created_Date] [datetime] NOT NULL,
	[Modified_By] [nvarchar](100) NOT NULL,
	[Modified_Date] [datetime] NOT NULL,
	 CONSTRAINT [PK_Catalog] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]	

	ALTER TABLE [dbo].[Catalog]  WITH CHECK ADD  CONSTRAINT [FK_Catalog_Pillar_LawReg_Mapping] FOREIGN KEY([Pillar_Lawreg_Mapping_Id])
	REFERENCES [dbo].[Pillar_LawReg_Mapping] ([Id])	

	ALTER TABLE [dbo].[Catalog] CHECK CONSTRAINT [FK_Catalog_Pillar_LawReg_Mapping]	

	ALTER TABLE [dbo].[Catalog]  WITH CHECK ADD  CONSTRAINT [FK_Catalog_Pillar_PB28_Mapping] FOREIGN KEY([Pillar_PB28_Mapping_Id])
	REFERENCES [dbo].[Pillar_PB28_Mapping] ([Id])

	ALTER TABLE [dbo].[Catalog] CHECK CONSTRAINT [FK_Catalog_Pillar_PB28_Mapping]	
	 
Print '[Catalog] Table Created'
END
GO


/****** Table Creation for [Catalog_Questions]   ***********************/

IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'Catalog_Questions')
BEGIN
		CREATE TABLE [dbo].[Catalog_Questions](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[Catalog_Id] [int] NOT NULL,
		[Question] [nvarchar](500) NOT NULL,
		[Answer_Type_Id] [int] NOT NULL,
		[Answer_Type_Key] [nvarchar](4) NOT NULL,
		[IsRequired] [bit] NOT NULL,
		[Start_FY] [int] NOT NULL,
		[End_FY] [int] NULL,
		[Created_By] [nvarchar](100) NOT NULL,
		[Created_Date] [datetime] NOT NULL,
		[Modified_By] [nvarchar](100) NOT NULL,
		[Modified_Date] [datetime] NOT NULL,
	 CONSTRAINT [PK_Catalog_Questions] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [dbo].[Catalog_Questions]  WITH CHECK ADD  CONSTRAINT [FK_Catalog_Questions_Catalog] FOREIGN KEY([Catalog_Id])
	REFERENCES [dbo].[Catalog] ([Id])

	ALTER TABLE [dbo].[Catalog_Questions] CHECK CONSTRAINT [FK_Catalog_Questions_Catalog]

Print '[Catalog_Questions] table created'
END
GO


/****************** Table Creation for [AMSCO]  **************************/

IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'AMSCO')
BEGIN
	CREATE TABLE [dbo].[AMSCO](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[AMSCO_Code] [nvarchar](50) NOT NULL,
		[AMSCO_Description] [nvarchar](250) NOT NULL,
		[Created_By] [nvarchar](100) NOT NULL,
		[Created_Date] [datetime] NOT NULL,
		[Modified_By] [nvarchar](100) NOT NULL,
		[Modified_Date] [datetime] NOT NULL
	 CONSTRAINT [PK_AMSCO] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

Print '[AMSCO] table created'
END
GO


/****************** Table Creation for [Catalog_AMSCO]  **************************/

IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'Catalog_AMSCO')
BEGIN
	CREATE TABLE [dbo].[Catalog_AMSCO](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[Catalog_Id] [int] NOT NULL,
		[AMSCO_Id] [int] NOT NULL,
		[Start_FY] [int] NOT NULL,
		[End_FY] [int] NULL,
		[Created_By] [nvarchar](100) NOT NULL,
		[Created_Date] [datetime] NOT NULL,
		[Modified_By] [nvarchar](100) NOT NULL,
		[Modified_Date] [datetime] NOT NULL
	 CONSTRAINT [PK_Catalog_AMSCO] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [dbo].[Catalog_AMSCO]  WITH CHECK ADD  CONSTRAINT [FK_Catalog_AMSCO_AMSCO] FOREIGN KEY([AMSCO_Id])
	REFERENCES [dbo].[AMSCO] ([Id])

	ALTER TABLE [dbo].[Catalog_AMSCO] CHECK CONSTRAINT [FK_Catalog_AMSCO_AMSCO]

	ALTER TABLE [dbo].[Catalog_AMSCO]  WITH CHECK ADD  CONSTRAINT [FK_Catalog_AMSCO_Catalog] FOREIGN KEY([Catalog_Id])
	REFERENCES [dbo].[Catalog] ([Id])

	ALTER TABLE [dbo].[Catalog_AMSCO] CHECK CONSTRAINT [FK_Catalog_AMSCO_Catalog]

Print '[Catalog_AMSCO] table created'
END
GO


/****************** Table Creation for [Fiscal_Year]  **************************/
IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'Fiscal_Year')
BEGIN
	CREATE TABLE [dbo].[Fiscal_Year](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[FY] [int] NOT NULL,
		[FY_Start_Date] [datetime] NOT NULL,
		[FY_End_Date] [datetime] NOT NULL,
		[CurrentYear_Start_Date] [datetime] NOT NULL,
		[CurrentYear_End_Date] [datetime] NOT NULL,		
		[Current_Required_Start_Date] [datetime] NOT NULL,
		[Current_Required_End_Date] [datetime] NOT NULL,
		[Planning_Start_Date] [datetime] NOT NULL,
		[Planning_End_Date] [datetime] NOT NULL,
		[Funding_Start_Date] [datetime] NOT NULL,
		[Funding_End_Date] [datetime] NOT NULL,
		[Obligation_Start_Date] [datetime] NOT NULL,
		[Obligation_End_Date] [datetime] NOT NULL,
		[Created_By] [nvarchar](100) NOT NULL,
		[Created_Date] [datetime] NOT NULL,
		[Modified_By] [nvarchar](100) NOT NULL,
		[Modified_Date] [datetime] NOT NULL
	 CONSTRAINT [PK_Fiscal_Year] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
	
Print '[Fiscal_Year] table created'	
END
GO

/****************** Table Creation for [MDEP]  **************************/


IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'MDEP')
BEGIN
		CREATE TABLE [dbo].[MDEP](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[Pillar_Id] [int] NOT NULL,
	    [Pillar_Key] [nvarchar](4) NOT NULL,
	    [MDEP_Code] [nvarchar](50) NOT NULL,
	    [Start_FY] [int] NOT NULL,
	    [End_FY] [int] NULL,
		[Created_By] [nvarchar](100) NOT NULL,
		[Created_Date] [datetime] NOT NULL,
		[Modified_By] [nvarchar](100) NOT NULL,
		[Modified_Date] [datetime] NOT NULL,
	 CONSTRAINT [PK_MDEP] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

Print '[MDEP] table created'
END
GO
IF Exists(Select 1 from INFORMATION_SCHEMA.TABLES Where TABLE_NAME = 'Project_Audit_Details')
BEGIN
	Drop Table dbo.Project_Audit_Details;
END
GO

/****************** Table Creation for [User_Audit]  **************************/
IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'User_Audit')
BEGIN
	CREATE TABLE [dbo].[User_Audit](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[User_Role_Id] [int] NOT NULL,
	[Login_Date_Time] [datetime] NOT NULL,
	[Created_By] [nvarchar](100) NOT NULL,
	[Created_Date] [datetime] NOT NULL,
	[Modified_By] [nvarchar](100) NOT NULL,
	[Modified_Date] [datetime] NOT NULL,
	 CONSTRAINT [PK_User_Audit] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [dbo].[User_Audit]  WITH CHECK ADD  CONSTRAINT [FK_User_Audit_User_Role_Mapping_UserRoleId] FOREIGN KEY([User_Role_Id])
	REFERENCES [dbo].[User_Role] ([Id])
	 

	ALTER TABLE [dbo].[User_Audit] CHECK CONSTRAINT [FK_User_Audit_User_Role_Mapping_UserRoleId]
 
	
Print '[User_Audit] table created'	
END
GO

/****************** Table Creation for [Project]  **************************/
IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'Project')
BEGIN

	CREATE TABLE [dbo].[Project](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[Project_Name] [nvarchar](255) NULL,
		[Project_Number] [nvarchar](50) NULL,
		[Hierarchy_Data_Id] [int] NULL,
		[Catalog_Id] [int] NULL,
		[Class_Id] [int] NULL,
		[Class_Key] [nvarchar](4) NULL,
		[Owner_ID] [int] NULL,
		[Project_Owner] [nvarchar](250) NULL,
		[Created_User_Role_Id] [int] NULL,
		[POC_User_Id] [varchar](100) NULL,
		[Project_Description] [nvarchar](max) NULL,
		[ROI] [varchar](50) NULL,
		[Status_Id] [int] NULL,
		[Status_Key] [nvarchar](4) NULL,		 
		[Created_By] [nvarchar](100) NULL,
		[Created_Date] [datetime] NULL,
		[Modified_By] [nvarchar](100) NULL,
		[Modified_Date] [datetime] NULL,
	 CONSTRAINT [PK_Project] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [dbo].[Project]  WITH CHECK ADD  CONSTRAINT [FK_Project_Catalog_CatalogId] FOREIGN KEY([Catalog_Id])
	REFERENCES [dbo].[Catalog] ([Id])

	ALTER TABLE [dbo].[Project] CHECK CONSTRAINT [FK_Project_Catalog_CatalogId]

	ALTER TABLE [dbo].[Project]  WITH CHECK ADD  CONSTRAINT [FK_Project_HierarchyData_HieararchyId] FOREIGN KEY([Hierarchy_Data_Id])
	REFERENCES [dbo].[Hierarchy_Data] ([Id])

	ALTER TABLE [dbo].[Project] CHECK CONSTRAINT [FK_Project_HierarchyData_HieararchyId]

	ALTER TABLE [dbo].[Project]  WITH CHECK ADD  CONSTRAINT [FK_Project_User_Role_UserRoleId] FOREIGN KEY([Created_User_Role_Id])
	REFERENCES [dbo].[User_Role] ([Id])

	ALTER TABLE [dbo].[Project] CHECK CONSTRAINT [FK_Project_User_Role_UserRoleId]

	ALTER TABLE [dbo].[Project]  WITH CHECK ADD  CONSTRAINT [FK_Project_Users_CreatedUserId] FOREIGN KEY([Owner_ID])
	REFERENCES [dbo].[Users] ([Id])

	ALTER TABLE [dbo].[Project] CHECK CONSTRAINT [FK_Project_Users_CreatedUserId]

Print '[Project] table created'	
END
GO

/****************** Add impact mission  in project table   **************************/
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE Name = N'Impact_to_Mission_Id' AND OBJECT_ID = OBJECT_ID(N'Project'))
BEGIN
	ALTER TABLE dbo.Project add  [Impact_to_Mission_Id] int
END
GO
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE Name = N'Impact_to_Mission_Key' AND OBJECT_ID = OBJECT_ID(N'Project'))
BEGIN
	ALTER TABLE dbo.Project add  [Impact_to_Mission_Key] nvarchar(4)
END
GO

/****************** Add impact code in project table   **************************/
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE Name = N'Mission_Code_Id' AND OBJECT_ID = OBJECT_ID(N'Project'))
BEGIN
	ALTER TABLE dbo.Project add  [Mission_Code_Id] int
END
GO
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE Name = N'Mission_Code_Key' AND OBJECT_ID = OBJECT_ID(N'Project'))
BEGIN
	ALTER TABLE dbo.Project add  [Mission_Code_Key] nvarchar(4)
END
GO
/****************** updating Impact to mission as "Medium" and Mission code as "Mission code 1"   **************************/
If EXISTS(select 1 from project where Impact_to_Mission_Id is null and Impact_to_Mission_Key is null)
BEGIN
	update  project set Impact_to_Mission_Id=2020 , Impact_to_Mission_Key ='ITML' where Impact_to_Mission_Id is null and Impact_to_Mission_Key is null
END

If EXISTS(select 1 from project where Mission_Code_Id is null and  Mission_Code_Key is null)
BEGIN
	update  project set Mission_Code_Id=2021 , Mission_Code_Key ='ITML' where Mission_Code_Id is null and Mission_Code_Key is null
END

/****************** Table Creation for [Project_Answer]  **************************/
IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'Project_Answer')
BEGIN

	CREATE TABLE [dbo].[Project_Answer](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[Project_Id] [int] NOT NULL,
		[Catalog_Question_Id] [int] NULL,
		[FY] [int] NULL,
		[Answer] [nvarchar](500) NULL,
		[Created_By] [nvarchar](100) NULL,
		[Created_Date] [datetime] NULL,
		[Modified_By] [nvarchar](100) NULL,
		[Modified_Date] [datetime] NULL,
	 CONSTRAINT [PK_Project_Answer] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [dbo].[Project_Answer]  WITH CHECK ADD  CONSTRAINT [FK_Project_Answer_CatalogQuestions_CatalogQuestionId] FOREIGN KEY([Catalog_Question_Id])
	REFERENCES [dbo].[Catalog_Questions] ([Id])

	ALTER TABLE [dbo].[Project_Answer] CHECK CONSTRAINT [FK_Project_Answer_CatalogQuestions_CatalogQuestionId]
 
	
	ALTER TABLE [dbo].[Project_Answer]  WITH CHECK ADD  CONSTRAINT [FK_Project_Answer_Project] FOREIGN KEY([Project_Id])
	REFERENCES [dbo].[Project] ([Id])

	ALTER TABLE [dbo].[Project_Answer] CHECK CONSTRAINT [FK_Project_Answer_Project]

Print '[Project_Answer] table created'	
END
GO


/****************** Table Creation for [Project_Document]  **************************/
IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'Project_Document')
BEGIN

	CREATE TABLE [dbo].[Project_Document](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[Project_Id] [int] NOT NULL,
		[Document_Original_Name] [nvarchar](500) NULL,
		[Document_Name] [nvarchar](500) NULL,
		[Created_By] [nvarchar](100) NULL,
		[Created_Date] [datetime] NULL,
		[Modified_By] [nvarchar](100) NULL,
		[Modified_Date] [datetime] NULL,
	 CONSTRAINT [PK_Project_Document] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [dbo].[Project_Document]  WITH CHECK ADD  CONSTRAINT [FK_Project_Document_Project] FOREIGN KEY([Project_Id])
	REFERENCES [dbo].[Project] ([Id])

	ALTER TABLE [dbo].[Project_Document] CHECK CONSTRAINT [FK_Project_Document_Project]

	Print '[Project_Document] table created'	
END
GO

/****************** Table Creation for [Project_Note]  **************************/
IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'Project_Note')
BEGIN

	CREATE TABLE [dbo].[Project_Note](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[Project_Id] [int] NOT NULL,
		[Type_Id] [int] NULL,
		[Type_Key] [nvarchar](4) NULL,
		[User_Role_Id] [int] NULL,
		[Notes] [nvarchar](2000) NULL,
		[SubSystem_Ref_Id] [int] NULL,
		[Approval_Status_Id] [int] NULL,
		[Approval_Status_Key] [nvarchar](4) NULL,
		[Created_By] [nvarchar](100) NULL,
		[Created_Date] [datetime] NULL,
		[Modified_By] [nvarchar](100) NULL,
		[Modified_Date] [datetime] NULL,
	 CONSTRAINT [PK_Project_Note] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [dbo].[Project_Note]  WITH CHECK ADD  CONSTRAINT [FK_Project_Note_Project] FOREIGN KEY([Project_Id])
	REFERENCES [dbo].[Project] ([Id])
 
	ALTER TABLE [dbo].[Project_Note] CHECK CONSTRAINT [FK_Project_Note_Project]
 
	ALTER TABLE [dbo].[Project_Note]  WITH CHECK ADD  CONSTRAINT [FK_Project_Note_User_Role_UserRoleId] FOREIGN KEY([User_Role_Id])
	REFERENCES [dbo].[User_Role] ([Id])

	ALTER TABLE [dbo].[Project_Note] CHECK CONSTRAINT [FK_Project_Note_User_Role_UserRoleId]

	Print '[Project_Note] table created'	
END
GO


/****************** Table Creation for [Project_Funding]  **************************/
IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'Project_Funding')
BEGIN

	CREATE TABLE [dbo].[Project_Funding](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[Project_Id] [int] NOT NULL,
		[FY] [int] NULL,
		[Priority] [int] NULL,
		[Initial_Required] [decimal](20, 2) NULL,
		[Current_Required] [decimal](20, 2) NULL,
		[Planned] [decimal](20, 2) NULL,		
		[Funded] [decimal](20, 2) NULL,
		[Obligated] [decimal](20, 2) NULL,
		[Approval_Status_Id] [int] NOT NULL,
		[Approval_Status_Key] [nvarchar](4) NOT NULL,
		[Created_By] [nvarchar](100) NULL,
		[Created_Date] [datetime] NULL,
		[Modified_By] [nvarchar](100) NULL,
		[Modified_Date] [datetime] NULL,
	 CONSTRAINT [PK_Project_Funding] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [dbo].[Project_Funding]  WITH CHECK ADD  CONSTRAINT [FK_Project_Funding_Project] FOREIGN KEY([Project_Id])
	REFERENCES [dbo].[Project] ([Id])

	ALTER TABLE [dbo].[Project_Funding] CHECK CONSTRAINT [FK_Project_Funding_Project]

	Print '[Project_Funding] table created'	
END
GO

/****** Table creation for Help_Documents ****************************/
IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'Help_Documents')
Begin
	CREATE TABLE [dbo].[Help_Documents](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[FileName] [nvarchar](1000) NULL,
		[DisplayName] [nvarchar](1000) NULL,
		[Created_By] [nvarchar](100) NOT NULL,
		[Created_Date] [datetime] NOT NULL,
		[Modified_By] [nvarchar](100)NOT NULL,
		[Modified_Date] [datetime] NOT NULL,
	 CONSTRAINT [PK_Help_Documents] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

	Print '[Help_Documents] table created'
End
GO



IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Project_Funding' AND COLUMN_NAME = 'Planned' 
and NUMERIC_PRECISION = 20
)
Begin
	Alter Table Project_Funding
		Alter Column Planned decimal(20,2)
	
	Print 'Project_Funding -> Planned Column modified'
End

IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Project_Funding' AND COLUMN_NAME = 'Funded' 
and NUMERIC_PRECISION = 20
)
Begin
	Alter Table Project_Funding
		Alter Column Funded decimal(20,2)
	
	Print 'Project_Funding -> Funded Column modified'
End

IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Project_Funding' AND COLUMN_NAME = 'Obligated' 
and NUMERIC_PRECISION = 20
)
Begin
	Alter Table Project_Funding
		Alter Column Obligated decimal(20,2)
	
	Print 'Project_Funding -> Obligated Column modified'
End
GO
 
/* Table Creation for Reports START*/
IF NOT EXISTS(SELECT 1 FROM sys.tables WHERE name = 'Report')
BEGIN
	CREATE TABLE [dbo].[Report](
	[Id] [int] NOT NULL identity (1,1),
	[Name] [nvarchar](500) NOT NULL,
	[Created_By] [nvarchar](100) NOT NULL,
	[Created_Date] [datetime] NOT NULL,
	[Modified_By] [nvarchar](100)NOT NULL,
	[Modified_Date] [datetime] NOT NULL,

CONSTRAINT [PK_Report] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

	Print '[Report] Table Created'
END
GO

IF NOT EXISTS(SELECT 1 FROM sys.tables WHERE name = 'Report_Role_Mapping')
BEGIN
	CREATE TABLE [dbo].[Report_Role_Mapping](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Report_Id] [int] NOT NULL,
	[Role_Id] [int] NOT NULL,
	[Is_Allowed] bit,
	[Created_By] [nvarchar](100) NOT NULL,
	[Created_Date] [datetime] NOT NULL,
	[Modified_By] [nvarchar](100)NOT NULL,
	[Modified_Date] [datetime] NOT NULL,
 CONSTRAINT [PK_Report_Role_Mapping] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

	ALTER TABLE [dbo].[Report_Role_Mapping]  WITH CHECK ADD  CONSTRAINT [FK_Report_Role_Mapping] FOREIGN KEY([Role_Id])
	REFERENCES [dbo].[Role] ([Id])
	ALTER TABLE [dbo].[Report_Role_Mapping] CHECK CONSTRAINT [FK_Report_Role_Mapping]
	ALTER TABLE [dbo].[Report_Role_Mapping]  WITH CHECK ADD  CONSTRAINT [FK_Report_Mapping] FOREIGN KEY([Report_Id])
	REFERENCES [dbo].[Report] ([Id])
	ALTER TABLE [dbo].[Report_Role_Mapping] CHECK CONSTRAINT [FK_Report_Mapping]

	Print '[Report_Role_Mapping] Table Created'
END
GO
/* Table Creation for Reports END*/
---- Remove AKO Email Id From User Table
--IF EXISTS ( Select * From INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Users' And Table_schema = 'dbo' 
--		And COLUMN_NAME = 'Ako_Email_Id')
--BEGIN
--	Alter Table dbo.Users Drop Column Ako_Email_Id
--END

-- Remove Project_Owner From Project Table  
IF EXISTS ( Select * From INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Project' And Table_schema = 'dbo' 
		And COLUMN_NAME = 'Project_Owner')
BEGIN
	Alter Table dbo.Project Drop Column Project_Owner
END
-- Increase Column size of Project Name from Project table
IF EXISTS
    (   SELECT  *
        FROM    SYS.COLUMNS c
                INNER JOIN SYS.TYPES t
                    ON t.system_type_id = c.system_type_id
                    AND t.user_type_id = c.user_type_id
        WHERE   c.name = 'Project_Name'
        AND     c.[object_id] = OBJECT_ID(N'dbo.Project', 'U')
        AND     t.name = 'nvarchar'
        AND     c.max_length = 200
        AND     c.is_computed = 0
    )
BEGIN
    ALTER TABLE Project ALTER COLUMN Project_Name NVarchar(200) NULL
END;

/****************** Table Creation for [Approval_Process]  **************************/
IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'Approval_Process')
BEGIN

	CREATE TABLE [dbo].[Approval_Process](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Project_Type_Id] [int] NOT NULL,
	[Project_Type_Key] [nvarchar](4) NOT NULL,
	[Role_Id] [int] NOT NULL,
	[Action_Id] [int] NOT NULL,
	[Action_Key] [nvarchar](4) NOT NULL,
	[CurrentStatus_Approval_Status_Id] [int] NOT NULL,
	[CurrentStatus_Approval_Status_Key] [nvarchar](4) NOT NULL,
	[NewStatus_Approval_Status_Id] [int] NOT NULL,
	[NewStatus_Approval_Status_Key] [nvarchar](4) NOT NULL,
	[Notes] [nvarchar](250) NULL,
	[Created_By] [nvarchar](100) NOT NULL,
	[Created_Date] [datetime] NOT NULL,
	[Modified_By] [nvarchar](100) NOT NULL,
	[Modified_Date] [datetime] NOT NULL,
	 CONSTRAINT [PK_Approval_Process] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [dbo].[Approval_Process]  WITH CHECK ADD  CONSTRAINT [FK_Approval_Process_Role_RoleId] FOREIGN KEY([Role_Id])
	REFERENCES [dbo].[Role] ([Id])

	ALTER TABLE [dbo].[Approval_Process] CHECK CONSTRAINT [FK_Approval_Process_Role_RoleId]

	Print '[Approval_Process] table created'	
END
GO

/****************** Table Creation for [Approval_Process_Email_Config]  **************************/
IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE Name = 'Approval_Process_Email_Config')
BEGIN
	CREATE TABLE [dbo].[Approval_Process_Email_Config](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[Approval_Process_Id] [Int] NOT NULL,
		[To_Project_Owner] [Bit] NULL,
		[Roled_Id_To_Send] [Int] NULL,
		[Hierarchy_Level] [NVarchar](50) NULL,
		[Is_Enabled] [Bit] NULL,
		[Subject] [NVarchar](Max) NULL,
		[Message] [NVarchar](Max) NULL,
		[Created_By] [NVarchar](100) NOT NULL,
		[Created_Date] [Datetime] NOT NULL,
		[Modified_By] [NVarchar](100) NOT NULL,
		[Modified_Date] [Datetime] NOT NULL
	 CONSTRAINT [PK_Approval_Process_Email_Config] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

Print '[Approval_Process_Email_Config] table created'
END
GO
IF Exists(Select 1 from INFORMATION_SCHEMA.TABLES where TABLE_NAME = 'Project_Audit')
BEGIN
	Drop Table dbo.Project_Audit;
END
GO

/****************** Table Creation for [Audit]]  **************************/
IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'Audit')
BEGIN

	CREATE TABLE [dbo].[Audit](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Table_Name] [nvarchar](100) NOT NULL,
	[Primary_Key] [int] NOT NULL,
	[Project_Id] [int] NOT NULL,
	[User_Role_Id] [int] NOT NULL,
	[Change_Type_Id] [int] NOT NULL,
	[Change_Type_Value] [nvarchar](4) NOT NULL,
	[Created_By] [nvarchar](100) NOT NULL,
	[Created_Date] [datetime] NOT NULL,
	[Modified_By] [nvarchar](100) NOT NULL,
	[Modified_Date] [datetime] NOT NULL,
 CONSTRAINT [PK_Audits] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

	ALTER TABLE [dbo].[Audit]  WITH CHECK ADD  CONSTRAINT [FK_Audit_User_Role_UserRoleId] FOREIGN KEY([User_Role_Id])
	REFERENCES [dbo].[User_Role] ([Id])

	ALTER TABLE [dbo].[Audit] CHECK CONSTRAINT [FK_Audit_User_Role_UserRoleId]

	ALTER TABLE [dbo].[Audit]  WITH CHECK ADD  CONSTRAINT [FK_Audits_Audits_Project_ProjectId] FOREIGN KEY([Project_Id])
	REFERENCES [dbo].[Project] ([Id])

	ALTER TABLE [dbo].[Audit] CHECK CONSTRAINT [FK_Audits_Audits_Project_ProjectId]

	Print '[Audit] table created'	
END
GO

IF Exists(Select 1 from INFORMATION_SCHEMA.TABLES Where TABLE_NAME = 'Project_Audit_Details')
BEGIN
	Drop Table dbo.Project_Audit_Details;
END
GO

/****************** Table Creation for [Audit_Details]]  **************************/
IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'Audit_Details')
BEGIN
	CREATE TABLE [dbo].[Audit_Details](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Audit_Id] [int] NOT NULL,
	[Column_Name] [nvarchar](150) NOT NULL,
	[Old_Value] [nvarchar](max) NOT NULL,
	[New_Value] [nvarchar](max) NOT NULL,
	[Created_By] [nvarchar](100) NOT NULL,
	[Created_Date] [datetime] NOT NULL,
	[Modified_By] [nvarchar](100) NOT NULL,
	[Modified_Date] [datetime] NOT NULL,
	 CONSTRAINT [PK_Audit_Details] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [dbo].[Audit_Details]  WITH CHECK ADD  CONSTRAINT [FK_Audit_Details_Audits_AuditId] FOREIGN KEY([Audit_Id])
	REFERENCES [dbo].[Audit] ([Id])
 

	ALTER TABLE [dbo].[Audit_Details] CHECK CONSTRAINT [FK_Audit_Details_Audits_AuditId]
 

	Print '[Audit_Details] table created'	
END
GO

/****************** Table Creation for [Audit_Display]  **************************/
IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'Audit_Display')
BEGIN
	CREATE TABLE [dbo].[Audit_Display](
	[Id] [Int] IDENTITY(1,1) NOT NULL,
	[Entity_Name] [nvarchar](200) NULL,
	[Display_Name] [nvarchar](200) NULL,
	[Code_Id] [Int] NULL,	 
	[Created_By] [Nvarchar](100) NOT NULL,
	[Created_Date] [Datetime] NOT NULL,
	[Modified_By] [Nvarchar](100) NOT NULL,
	[Modified_Date] [Datetime] NOT NULL,
	 CONSTRAINT [PK_Audit_Display] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

	Print '[Audit_Display] table created'	
END
GO

/****************** Table Creation for Hierarchy_Data_Planning]  **************************/

IF NOT EXISTS(SELECT 1 FROM SYS.TABLES WHERE name = 'Hierarchy_Data_Planning')
BEGIN
CREATE TABLE [dbo].[Hierarchy_Data_Planning](
	[Id] [int]  IDENTITY(1,1) NOT NULL,
	[FY] [int] NOT NULL,
	[Hierarchy_Data_Id] [int] NOT NULL,
	[Control_Amount] [decimal](9,2) NULL,
	[Priority_Status_Id] int NULL,
	[Priority_Status_Key]  [nvarchar](4) NULL,
	[Priority_Completion_Date] [datetime] NULL,
	[Allocation_Status_Id] int NULL,
	[Allocation_Status_Key] [nvarchar](4) NULL,
	[Allocation_Completion_Date] [datetime] NULL,
	[Created_By] [nvarchar](100) NOT NULL,
	[Created_Date] [datetime] NOT NULL,
	[Modified_By] [nvarchar](100) NOT NULL,
	[Modified_Date] [datetime] NOT NULL,
CONSTRAINT [PK_Hierarchy_Data_Planning] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

ALTER TABLE [dbo].[Hierarchy_Data_Planning]  WITH CHECK ADD  CONSTRAINT [FK_Hierarchy_Data_Planning_Hierarchy] FOREIGN KEY([Hierarchy_Data_id])
REFERENCES [dbo].[Hierarchy_Data] ([Id])

ALTER TABLE [dbo].[Hierarchy_Data_Planning] CHECK CONSTRAINT [FK_Hierarchy_Data_Planning_Hierarchy]

Print '[Hierarchy_Data_Planning] table created'	

END
GO

IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Hierarchy_Data_Planning' AND COLUMN_NAME = 'Control_Amount' 
and NUMERIC_PRECISION = 20
)
Begin
	Alter Table Hierarchy_Data_Planning
		Alter Column Control_Amount decimal(20,2)
	
	Print 'Hierarchy_Data_Planning -> Control_Amount Column modified'
End

GO
/*================ Adding Columns in User Role Table =======================*/
IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'User_Role' AND COLUMN_NAME = 'User_Role_Status_Id')
Begin
	Alter Table User_Role Add User_Role_Status_Id Int 
	
	Print 'User_Role -> User_Role_Status_Id Column added'
End
GO

IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'User_Role' AND COLUMN_NAME = 'User_Role_Status_Key')
Begin
	Alter Table User_Role Add User_Role_Status_Key nvarchar(4)
	
	Print 'User_Role -> User_Role_Status_Key Column added'
End
GO

/*================ Adding Columns in Audit Table =======================*/
IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Audit' AND COLUMN_NAME = 'Transaction_Unique_Id')
Begin
	Alter Table Audit Add Transaction_Unique_Id Uniqueidentifier Null
	
	Print 'Audit -> Transaction_Unique_Id Column added'
End
GO
 
 /* ============= Remove the columns from action table =======================*/
 IF EXISTS (SELECT * FROM SYS.FOREIGN_KEYS  WHERE OBJECT_ID = OBJECT_ID(N'dbo.FK_Action_Parent')
				AND PARENT_OBJECT_ID = OBJECT_ID(N'dbo.Action'))
BEGIN
	ALTER TABLE dbo.Action DROP CONSTRAINT [FK_Action_Parent] 
	Print 'Deleted FK_Action_Parent CONSTRAINT  From Action Table' 	
END
GO
IF EXISTS(SELECT * FROM SYS.COLUMNS WHERE Name = N'Action_Target' AND OBJECT_ID = OBJECT_ID(N'Action'))
BEGIN
	ALTER TABLE dbo.Action DROP COLUMN Action_Target
	Print 'Deleted Action_Target Column From Action Table'
END
GO
IF EXISTS(SELECT * FROM SYS.COLUMNS WHERE Name = N'Action_Parent_Id' AND OBJECT_ID = OBJECT_ID(N'Action'))
BEGIN
    
    ALTER TABLE dbo.Action DROP COLUMN Action_Parent_Id
    Print 'Deleted Action_Parent_Id Column From Action Table'
END
GO
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE Name = N'Controller_Name' AND OBJECT_ID = OBJECT_ID(N'Action'))
BEGIN
    ALTER TABLE dbo.Action Add Controller_Name Varchar(100)
    Print 'Controller_Name Column Added In Action Table'
END
GO

-- Renaming Created User Id Column as Owner Id 
IF EXISTS(SELECT 1 FROM SYS.COLUMNS WHERE [Name] = N'Created_User_Id' AND OBJECT_ID = OBJECT_ID(N'Project'))
BEGIN
    EXEC SP_RENAME 'Project.Created_User_Id', 'Owner_ID' , 'COLUMN'
END;

GO
--Add Is_ReadOnly Columns in Role Table

--IF NOT EXISTS(SELECT * FROM sys.columns
--WHERE Name = 'Is_ReadOnly' AND OBJECT_ID = OBJECT_ID('role'))
--BEGIN
--	alter table role add  Is_ReadOnly bit not null default(0)
--END  


/*================ Adding Foreign Key Constraint Of Role in Approval_Process_Email_Config Table =======================*/
 IF NOT EXISTS (SELECT * FROM DBO.SYSOBJECTS WHERE Id = object_id(N'[dbo].[FK_Approval_Process_Email_Config_Role_Id]') AND OBJECTPROPERTY(id, N'IsForeignKey') = 1)
BEGIN
	ALTER TABLE [dbo].[Approval_Process_Email_Config]  WITH CHECK ADD  CONSTRAINT [FK_Approval_Process_Email_Config_Role_Id] FOREIGN KEY([Roled_Id_To_Send])
	REFERENCES [dbo].[Role] ([ID])
	 
	ALTER TABLE [dbo].[Approval_Process_Email_Config] CHECK CONSTRAINT [FK_Approval_Process_Email_Config_Role_Id]
	
	Print 'Created FK_Approval_Process_Email_Config_Role_Id'
	
END
GO

-- Removing Column from Approval_Process_Email_Config Table
IF EXISTS(SELECT * FROM SYS.COLUMNS WHERE Name = N'Hierarchy_Level' AND OBJECT_ID = OBJECT_ID(N'Approval_Process_Email_Config'))
BEGIN
	ALTER TABLE dbo.Approval_Process_Email_Config DROP COLUMN Hierarchy_Level
	Print 'Deleted Hierarchy_Level Column From Approval_Process_Email_Config Table'
END
GO

/*================ Adding Columns in Approval_Process_Email_Config Table =======================*/
IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Approval_Process_Email_Config' AND COLUMN_NAME = 'Hierarchy_Parent_Selection_Id')
Begin
	Alter Table Approval_Process_Email_Config Add Hierarchy_Parent_Selection_Id Int 
	
	Print 'Approval_Process_Email_Config -> Hierarchy_Parent_Selection_Id Column added'
End
GO

IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Approval_Process_Email_Config' AND COLUMN_NAME = 'Hierarchy_Parent_Selection_Key')
Begin
	Alter Table Approval_Process_Email_Config Add Hierarchy_Parent_Selection_Key nvarchar(4)
	
	Print 'Approval_Process_Email_Config -> Hierarchy_Parent_Selection_Key Column added'
End
GO

/*================ Adding Is_UFR Columns in Project Funding Table =======================*/
IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Project' AND COLUMN_NAME = 'Project_Status_Date')
Begin
	Alter Table Project Add Project_Status_Date DateTime Null
	
	Print 'Project -> Project_Status_Date Column added'
End
GO

/*================ Adding Is_UFR Column in Project Funding Table =======================*/
IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Project_Funding' AND COLUMN_NAME = 'Is_UFR')
Begin
	Alter Table Project_Funding Add Is_UFR Bit not null default(0)
	
	Print 'Project_Funding -> Is_UFR Column added'
End
GO
/*================ Adding Is_Recurring  Column in Project Table =======================*/
IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Project' AND COLUMN_NAME = 'Is_Recurring')
Begin
	Alter Table Project Add Is_Recurring Bit not null default(1)
	
	Print 'Project -> Is_Recurring Column added'
End
GO

/*================ Adding Columns of MDEP Code Id && Code Value  In Project Funding Table =======================*/
IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Project_Funding' AND COLUMN_NAME = 'MDEP_Id')
Begin
	Alter Table Project_Funding Add MDEP_Id Int 
	
	Print 'Project_Funding -> MDEP_Id Column added'
End
GO

IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Project_Funding' AND COLUMN_NAME = 'MDEP_Key')
Begin
	Alter Table Project_Funding Add MDEP_Key nvarchar(4)
	
	Print 'Project_Funding -> MDEP_Key Column added'
End
GO

IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Project_Funding' AND COLUMN_NAME = 'MDEP_Key')
Begin
	Alter Table Project_Funding Add MDEP_Key nvarchar(4)
	
	Print 'Project_Funding -> MDEP_Key Column added'
End
GO

IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Project_Funding' AND COLUMN_NAME = 'MSC_Priority')
Begin
	Alter Table Project_Funding Add MSC_Priority Int 
	
	Print 'Project_Funding -> MSC_Priority Column added'
End
GO

IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Project_Funding' AND COLUMN_NAME = 'HQ_Priority')
Begin
	Alter Table Project_Funding Add HQ_Priority Int 	
	Print 'Project_Funding -> HQ_Priority Column added'
End
GO


GO
IF Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Role' AND COLUMN_NAME = 'Role_Group_Id')
Begin
	ALTER TABLE Role drop column Role_Group_Id
	
	Print 'Role -> Role_Group_Id Column removed'
End

GO
IF Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Role' AND COLUMN_NAME = 'Role_Group_Key')
Begin
	ALTER TABLE Role drop column Role_Group_Key
	
	Print 'Role -> Role_Group_Key Column removed'
End
GO
IF Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'project_funding' AND COLUMN_NAME = 'Initial_Required')
Begin
	EXEC  sp_rename 'project_funding.Initial_Required', 'Validated' , 'COLUMN';
	Print 'project_funding -> Initial_Required Column renamed to Validated'
End
GO
IF Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'project_funding' AND COLUMN_NAME = 'Current_Required')
Begin
	EXEC  sp_rename 'project_funding.Current_Required', 'Programmed' , 'COLUMN';
	Print 'project_funding -> Current_Required Column renamed to Programmed '
End
GO
IF Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'project_funding' AND COLUMN_NAME = 'FAD_Amount')
Begin
	EXEC  sp_rename 'project_funding.FAD_Amount', 'FAD' , 'COLUMN';
	Print 'project_funding -> FAD_Amount Column renamed to FAD '
End
GO

IF Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Fiscal_Year' AND COLUMN_NAME = 'Current_Required_Start_Date')
Begin
	EXEC  sp_rename 'Fiscal_Year.Current_Required_Start_Date', 'Programmed_Start_Date' , 'COLUMN';
	Print 'Fiscal_Year -> Current_Required_Start_Date Column renamed to Programmed_Start_Date '
End
GO

IF Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Fiscal_Year' AND COLUMN_NAME = 'Current_Required_End_Date')
Begin
	EXEC  sp_rename 'Fiscal_Year.Current_Required_End_Date', 'Programmed_End_Date' , 'COLUMN';
	Print 'Fiscal_Year -> Current_Required_End_Date Column renamed to Programmed_End_Date '
End
GO

IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Project_Funding' AND COLUMN_NAME = 'Validated' 
and NUMERIC_PRECISION = 20
)
Begin
	Alter Table Project_Funding
		Alter Column Validated decimal(20,2)
	
	Print 'Project_Funding -> Validated Column modified'
End
GO
IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Project_Funding' AND COLUMN_NAME = 'Programmed' 
and NUMERIC_PRECISION = 20
)
Begin
	Alter Table Project_Funding
		Alter Column Programmed decimal(20,2)
	
	Print 'Project_Funding -> Programmed Column modified'
End
GO
IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Project_Funding' AND COLUMN_NAME = 'FAD')
Begin
	Alter Table Project_Funding Add FAD [decimal](20, 2) NULL 
	
	Print 'Project_Funding -> FAD Column added'
End
GO 
IF EXISTS ( Select * From INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Project' And Table_schema = 'dbo' 
		And COLUMN_NAME = 'POC_User_Id')
BEGIN
	Alter Table dbo.Project Drop Column POC_User_Id
	Print 'Removed POC_User_Id Column from Project Table'
END
GO
IF EXISTS ( Select * From INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Project' And Table_schema = 'dbo' 
		And COLUMN_NAME = 'Status_Id')
BEGIN
	Alter Table dbo.Project Drop Column Status_Id
	Print 'Removed Status_Id Column from Project Table'
END
GO
IF EXISTS ( Select * From INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Project' And Table_schema = 'dbo' 
		And COLUMN_NAME = 'Status_Key')
BEGIN
	Alter Table dbo.Project Drop Column Status_Key
	Print 'Removed Status_Key Column from Project Table'
END
GO
IF EXISTS ( Select * From INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Project' And Table_schema = 'dbo' 
		And COLUMN_NAME = 'Project_Status_Date')
BEGIN
	Alter Table dbo.Project Drop Column Project_Status_Date
	Print 'Removed Project_Status_Date Column from Project Table'
END
GO
IF EXISTS ( Select * From INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Project' And Table_schema = 'dbo' 
		And COLUMN_NAME = 'Mission_Code_Id')
BEGIN
	Alter Table dbo.Project Drop Column Mission_Code_Id
	Print 'Removed Mission_Code_Id Column from Project Table'
END
GO
IF EXISTS ( Select * From INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Project' And Table_schema = 'dbo' 
		And COLUMN_NAME = 'Mission_Code_Key')
BEGIN
	Alter Table dbo.Project Drop Column Mission_Code_Key
	Print 'Removed Mission_Code_Key Column from Project Table'
END
GO
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE Name = N'Environmental_Impact_Code_Id' AND OBJECT_ID = OBJECT_ID(N'Project'))
BEGIN
	ALTER TABLE dbo.Project add  [Environmental_Impact_Code_Id] Int
END
GO
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE Name = N'Environmental_Impact_Code_Key' AND OBJECT_ID = OBJECT_ID(N'Project'))
BEGIN
	ALTER TABLE dbo.Project add  [Environmental_Impact_Code_Key] nvarchar(4)
END
GO
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE Name = N'Funding_Status_Code_Id' AND OBJECT_ID = OBJECT_ID(N'Project_Funding'))
BEGIN
	ALTER TABLE dbo.Project_Funding add  [Funding_Status_Code_Id] Int
END
GO
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE Name = N'Funding_Status_Code_Key' AND OBJECT_ID = OBJECT_ID(N'Project_Funding'))
BEGIN
	ALTER TABLE dbo.Project_Funding add  [Funding_Status_Code_Key] nvarchar(4)
END
GO
IF EXISTS ( Select * From INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Project_Funding' And Table_schema = 'dbo' 
		And COLUMN_NAME = 'FAD')
BEGIN
	Alter Table dbo.Project_Funding Drop Column FAD
	Print 'Removed FAD Column from Project_Funding Table'
END
GO
IF EXISTS ( Select * From INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Project' And Table_schema = 'dbo' 
		And COLUMN_NAME = 'Resource_Sponsor_Id')
BEGIN
	Alter Table dbo.Project Drop Column Resource_Sponsor_Id
	Print 'Removed Resource_Sponsor_Id Column from Project Table'
END
GO
IF EXISTS ( Select * From INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Project' And Table_schema = 'dbo' 
		And COLUMN_NAME = 'Resource_Sponsor_Key')
BEGIN
	Alter Table dbo.Project Drop Column Resource_Sponsor_Key
	Print 'Removed Resource_Sponsor_Key Column from Project Table'
END
GO
IF EXISTS ( Select * From INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Project' And Table_schema = 'dbo' 
		And COLUMN_NAME = 'Source_Id')
BEGIN
	Alter Table dbo.Project Drop Column Source_Id
	Print 'Removed Source_Id Column from Project Table'
END
GO
IF EXISTS ( Select * From INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Project' And Table_schema = 'dbo' 
		And COLUMN_NAME = 'Source_Key')
BEGIN
	Alter Table dbo.Project Drop Column Source_Key
	Print 'Removed Source_Key Column from Project Table'
END
GO
IF Not Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Audit_Details' AND COLUMN_NAME = 'FY')
Begin
	Alter Table Audit_Details Add FY Int
	Print 'Audit_Details -> FY Column added'
End
GO 
IF Exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Code_Value' AND COLUMN_NAME = 'Data1' 
AND DATA_TYPE = 'Nvarchar' AND CHARACTER_MAXIMUM_LENGTH = 2500)
Begin
	ALTER TABLE Code_Value ALTER COLUMN Data1 NVarchar(500) NULL;
	Print 'Code_Value -> Data1 Column Lenght Increased '
End
GO
IF NOT EXISTS ( Select * From INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='AMSCO' And Table_schema = 'dbo' 
		And COLUMN_NAME = 'Start_FY')
BEGIN
	Alter Table dbo.AMSCO add  Start_FY int
	Print 'Added Start_FY Column to AMSCO Table'
END
GO
IF NOT EXISTS ( Select * From INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='AMSCO' And Table_schema = 'dbo' 
		And COLUMN_NAME = 'End_FY')
BEGIN
	Alter Table dbo.AMSCO add  End_FY int
	Print 'Added End_FY Column to AMSCO Table'
END
GO
GO

IF EXISTS ( Select * From INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Catalog_AMSCO' And Table_schema = 'dbo' 
		And COLUMN_NAME = 'Start_FY')
BEGIN
	Alter Table dbo.Catalog_AMSCO Drop Column Start_FY
	Print 'Removed Start_FY Column from Catalog_AMSCO Table'
END
GO
IF EXISTS ( Select * From INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Catalog_AMSCO' And Table_schema = 'dbo' 
		And COLUMN_NAME = 'End_FY')
BEGIN
	Alter Table dbo.Catalog_AMSCO Drop Column End_FY
	Print 'Removed End_FY Column from Catalog_AMSCO Table'
END
GO
-- Renaming Login_Date_Time  Column as Date_Time In User_Audit Table
IF EXISTS(SELECT 1 FROM SYS.COLUMNS WHERE [Name] = N'Login_Date_Time' AND OBJECT_ID = OBJECT_ID(N'User_Audit'))
BEGIN
    EXEC SP_RENAME 'User_Audit.Login_Date_Time', 'Date_Time' , 'COLUMN'
END;
GO
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE Name = N'Action_Id' AND OBJECT_ID = OBJECT_ID(N'User_Audit'))
BEGIN
	ALTER TABLE dbo.User_Audit add  [Action_Id] Int
	Print 'Added Action_Id Column to User_Audit Table'
END
GO
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE Name = N'Action_Key' AND OBJECT_ID = OBJECT_ID(N'User_Audit'))
BEGIN
	ALTER TABLE dbo.User_Audit add  [Action_Key] nvarchar(4)
	Print 'Added Action_Key Column to User_Audit Table'
END
GO
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE Name = N'Current_User_Role_Id' AND OBJECT_ID = OBJECT_ID(N'User_Audit'))
BEGIN
	ALTER TABLE dbo.User_Audit add  [Current_User_Role_Id] Int
	Print 'Added Current_User_Role_Id Column to User_Audit Table'
END
GO

IF EXISTS(SELECT * FROM SYS.COLUMNS WHERE Name = N'User_Role_Id' AND OBJECT_ID = OBJECT_ID(N'User_Audit'))
BEGIN
	ALTER TABLE dbo.User_Audit ALTER COLUMN User_Role_Id Int NULL
	Print 'Modified User_Role_Id Column to allow null'
END
GO 
