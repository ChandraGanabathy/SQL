Declare @User_Id int
Declare @User_Role_Id int
Declare @Created_Modified_User_Name varchar(100)
Select @Created_Modified_User_Name = 'QA Process'
Declare @Environemnt varchar(50)
SET @Environemnt='DEV'

If Not exists (Select 1 from Users where Email_Id = 'admin@plateauinc.com')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'admin@plateauinc.com',  NULL, N'Plateau', NULL, N'Admin', N'Test', 'Prosperity Avenue', 'Suite 200', 'Fairfax', 200, 'VA', 
			'22031','703-385-8300', 'Plateau Inc', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 1, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (1, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

/* BEGIN - HQ Users Creation */


IF @Environemnt='UAT'
BEGIN

If Not exists (Select 1 from Users where Email_Id = 'terry.l.funderburg.civ@mail.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'terry.l.funderburg.civ@mail.mil',  NULL, N'Terry', NULL, N'Funderburg', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'AMC HQ', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 2, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (1, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End


If Not exists (Select 1 from Users where Email_Id = 'pamela.a.whitman2.civ@mail.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'pamela.a.whitman2.civ@mail.mil',  NULL, N'Pamela', NULL, N'Whitman', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'AMC HQ', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 2, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (1, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'bridgett.e.lyons.civ@mail.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'bridgett.e.lyons.civ@mail.mil',  NULL, N'Bridgett', NULL, N'Lyons', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'AMC HQ', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 2, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (1, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'jeffrey.r.muehlmann.civ@mail.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'jeffrey.r.muehlmann.civ@mail.mil',  NULL, N'Jeffrey', NULL, N'Muehlmann', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'AMC HQ', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 2, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (1, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'andrew.j.lady.civ@mail.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'andrew.j.lady.civ@mail.mil',  NULL, N'Andrew', NULL, N'J', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'AMC HQ', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 2, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (1, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End


If Not exists (Select 1 from Users where Email_Id = 'rodney.w.amacher.civ@mail.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'rodney.w.amacher.civ@mail.mil',  NULL, N'Rodney', NULL, N'Amacher', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'AMC HQ', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 2, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (1, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End


If Not exists (Select 1 from Users where Email_Id = 'phillip.f.dark.civ@mail.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'phillip.f.dark.civ@mail.mil',  NULL, N'Philip', NULL, N'Dark', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'AMCOM', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 5, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (2, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'kevin.r.tiemeier.civ@mail.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'kevin.r.tiemeier.civ@mail.mil',  NULL, N'Kevin', NULL, N'Tiemeier', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'JMC', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 5, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (9, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End


If Not exists (Select 1 from Users where Email_Id = 'mark.l.manor.civ@mail.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'mark.l.manor.civ@mail.mil',  NULL, N'Mark', NULL, N'Manor', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'TACOM', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 5, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (22, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End


If Not exists (Select 1 from Users where Email_Id = 'carlos.i.moreno.civ@mail.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'carlos.i.moreno.civ@mail.mil',  NULL, N'Carlos', NULL, N'Moreno', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'TACOM', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 5, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (22, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End


If Not exists (Select 1 from Users where Email_Id = 'daniela.i.caughron.civ@mail.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'daniela.i.caughron.civ@mail.mil',  NULL, N'Daniela', NULL, N'Caughron', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'SDDC', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 5, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (28, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'penny.s.thompson2.civ@mail.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'penny.s.thompson2.civ@mail.mil',  NULL, N'Penny', NULL, N'Thompson', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'CMA', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 5, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (7, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'bruce.e.williams10.civ@mail.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'bruce.e.williams10.civ@mail.mil',  NULL, N'Bruce', NULL, N'Williams', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'CECOM', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 5, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (5, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'john.r.ramsauer.civ@mail.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'john.r.ramsauer.civ@mail.mil',  NULL, N'John', NULL, N'Ramsauer', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'AMCOM', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 5, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (2, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'ralph.c.demartino.civ@mail.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'ralph.c.demartino.civ@mail.mil',  NULL, N'Ralph', NULL, N'Demartino', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'TACOM', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 5, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (5, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'julie.a.halstead.civ@mail.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'julie.a.halstead.civ@mail.mil',  NULL, N'Julie', NULL, N'Halstead', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'AMC HQ', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 2, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (1, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

END

If Not exists (Select 1 from Users where Email_Id = 'HQ_Admin@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'HQ_Admin@amc.army.mil',  NULL, N'HQ', NULL, N'Admin', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'AMC HQ', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 2, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (1, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'HQ_User@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'HQ_User@amc.army.mil',  NULL, N'HQ', NULL, N'User', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'AMC HQ', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 3, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (1, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'HQ_Read@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'HQ_Read@amc.army.mil',  NULL, N'HQ', NULL, N'ReadOnly', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'AMC HQ', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 4, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (1, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

/* END - HQ Users Creation */

/* BEGIN - JMC MSC Users Creation */

If Not exists (Select 1 from Users where Email_Id = 'AMCOM_MSC_Admin@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'AMCOM_MSC_Admin@amc.army.mil',  NULL, N'AMCOM', NULL, N'MSC Admin', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'AMCOM', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 5, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (2, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End


If Not exists (Select 1 from Users where Email_Id = 'CECOM_MSC_Admin@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'CECOM_MSC_Admin@amc.army.mil',  NULL, N'CECOM', NULL, N'MSC Admin', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'CECOM', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 5, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (5, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'CMA_MSC_Admin@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'CMA_MSC_Admin@amc.army.mil',  NULL, N'CMA', NULL, N'MSC Admin', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'CMA', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 5, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (7, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'SDDC_MSC_Admin@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'SDDC_MSC_Admin@amc.army.mil',  NULL, N'SDDC', NULL, N'MSC Admin', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'SDDC', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 5, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (28, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'JMC_MSC_Admin@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'JMC_MSC_Admin@amc.army.mil',  NULL, N'JMC', NULL, N'MSC Admin', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'JMC', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 5, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (9, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End


If Not exists (Select 1 from Users where Email_Id = 'JMC_MSC_User@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'JMC_MSC_User@amc.army.mil',  NULL, N'JMC', NULL, N'MSC User', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'JMC', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 6, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (9, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End


If Not exists (Select 1 from Users where Email_Id = 'JMC_MSC_Read@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'JMC_MSC_Read@amc.army.mil',  NULL, N'JMC', NULL, N'MSC Read Only', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'JMC', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 6, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (9, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

/* END - JMC MSC Users Creation */

/* BEGIN - TACOM MSC Users Creation */

If Not exists (Select 1 from Users where Email_Id = 'TACOM_MSC_Admin@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'TACOM_MSC_Admin@amc.army.mil',  NULL, N'TACOM', NULL, N'MSC Admin', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'TACOM', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 5, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (22, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End



If Not exists (Select 1 from Users where Email_Id = 'TACOM_MSC_User@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'TACOM_MSC_User@amc.army.mil',  NULL, N'TACOM', NULL, N'MSC User', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'TACOM', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 6, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (22, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End



If Not exists (Select 1 from Users where Email_Id = 'TACOM_MSC_Read@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'TACOM_MSC_Read@amc.army.mil',  NULL, N'TACOM', NULL, N'MSC Read Only', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'TACOM', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 6, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (22, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

/* END - TACOM MSC Users Creation */

/* BEGIN - Installation Users Creation */

If Not exists (Select 1 from Users where Email_Id = 'LEAD_Inst_Admin@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'LEAD_Inst_Admin@amc.army.mil',  NULL, N'Letterkenny', NULL, N'Inst Admin', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'Letterkenny Army Depot', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 8, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (3, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'CCAD_Inst_Admin@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'CCAD_Inst_Admin@amc.army.mil',  NULL, N'CorpusChristi', NULL, N'Inst Admin', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'Corpus Christi Army Depot', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 8, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (4, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'TYAD_Inst_Admin@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'TYAD_Inst_Admin@amc.army.mil',  NULL, N'Tobyhanna', NULL, N'Inst Admin', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'Tobyhanna Army Depot', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 8, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (6, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End


If Not exists (Select 1 from Users where Email_Id = 'PDC_Inst_Admin@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'PDC_Inst_Admin@amc.army.mil',  NULL, N'Pueblo', NULL, N'Inst Admin', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'Pueblo Chemical Depot', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 8, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (8, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End


If Not exists (Select 1 from Users where Email_Id = 'MOTSU_Inst_Admin@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'MOTSU_Inst_Admin@amc.army.mil',  NULL, N'Sunny Point', NULL, N'Inst Admin', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'Sunny Point', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 8, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (29, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End


If Not exists (Select 1 from Users where Email_Id = 'MOTCO_Inst_Admin@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'MOTCO_Inst_Admin@amc.army.mil',  NULL, N'Concord', NULL, N'Inst Admin', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'Concord', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 8, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (30, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End
/* BEGIN - Tooele Installation Users Creation */

If Not exists (Select 1 from Users where Email_Id = 'TEAD_Inst_Admin@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'TEAD_Inst_Admin@amc.army.mil',  NULL, N'Tooele', NULL, N'Inst Admin', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'Tooele Army Depot', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 8, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (10, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End



If Not exists (Select 1 from Users where Email_Id = 'TEAD_Inst_User@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'TEAD_Inst_User@amc.army.mil',  NULL, N'Tooele', NULL, N'Inst User', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'Tooele', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 9, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (10, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End



If Not exists (Select 1 from Users where Email_Id = 'TEAD_Inst_Read@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'TEAD_Inst_Read@amc.army.mil',  NULL, N'Tooele', NULL, N'Inst Read Only', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'Tooele', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 10, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (10, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

/* END - Tooele Installation Users Creation */

/* BEGIN - Blue Grass Army Depot Installation Users Creation */

If Not exists (Select 1 from Users where Email_Id = 'BGAD_Inst_Admin@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'BGAD_Inst_Admin@amc.army.mil',  NULL, N'Blue Grass', NULL, N'Inst Admin', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'Blue Grass', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 8, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (21, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'BGAD_Inst_User@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'BGAD_Inst_User@amc.army.mil',  NULL, N'Blue Grass', NULL, N'Inst User', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'Blue Grass', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 9, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (21, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'BGAD_Inst_Read@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'BGAD_Inst_Read@amc.army.mil',  NULL, N'Blue Grass', NULL, N'Inst Read Only', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'Blue Grass', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 10, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (21, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

/* END - Blue Grass Inst Users Creation */

/* BEGIN - Sierra Army Depot Installation Users Creation */

If Not exists (Select 1 from Users where Email_Id = 'SIAD_Inst_Admin@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'SIAD_Inst_Admin@amc.army.mil',  NULL, N'Sierra', NULL, N'Inst Admin', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'Sierra', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 8, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (24, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'SIAD_Inst_User@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'SIAD_Inst_User@amc.army.mil',  NULL, N'Sierra', NULL, N'Inst User', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'Sierra', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 9, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (24, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'SIAD_Inst_Read@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'SIAD_Inst_Read@amc.army.mil',  NULL, N'Sierra', NULL, N'Inst Read Only', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'Sierra', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 10, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (24, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

/* END - Sierra Army Depot Inst Users Creation */


/* BEGIN - Red River Army Depot Installation Users Creation */

If Not exists (Select 1 from Users where Email_Id = 'RRAD_Inst_Admin@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'RRAD_Inst_Admin@amc.army.mil',  NULL, N'Red River', NULL, N'Inst Admin', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'Red River', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 8, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (25, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'RRAD_Inst_User@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'RRAD_Inst_User@amc.army.mil',  NULL, N'Red River', NULL, N'Inst User', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'Red River', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 9, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (25, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

If Not exists (Select 1 from Users where Email_Id = 'RRAD_Inst_Read@amc.army.mil')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'RRAD_Inst_Read@amc.army.mil',  NULL, N'Red River', NULL, N'Inst Read Only', N'Test', 'Redstone Arsenal', Null, 'Huntsville', 200, 'AL', 
			'35808','256-876-2151', 'Red River', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 10, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (25, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End

/* END - Red River Army Depot Inst Users Creation */

-------------- Conversion User----------------
If Not exists (Select 1 from Users where Email_Id = 'Conversion_Admin@plateauinc.com')
Begin
	INSERT [dbo].[Users] ([Email_Id],  [Title], [First_Name], [Middle_Name], [Last_Name], [Password], 
		[Address_Line1], [Address_Line2], [City], [State_Id],[State_Key], [Zip], [Phone], [Organization], 
		[User_Status_Id],[User_Status_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
		VALUES 
		(
			N'Conversion_Admin@plateauinc.com',  'Admin', N'Conversion', NULL, N'Admin', N'Test', 'Prosperity Avenue', 'Suite 200', 'Fairfax', 200, 'VA', 
			'22031','703-385-8300', 'Plateau Inc', 
			1300, N'ACTV'
			, @Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
		)

	Select @User_Id = Scope_identity()

	INSERT [dbo].[User_Role] ([User_Id], [Role_Id], [Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (
				@User_Id, 2, 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)

	Select @User_Role_Id = SCOPE_IDENTITY()

	INSERT [dbo].[User_Role_Hierarchy_Assoication] ([Hierarchy_Data_Id], [User_Role_Id], 
						[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES (1, @User_Role_Id, 
					@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
				)

	INSERT [dbo].[User_Role_Pillar_Association] 
			([User_Role_Id], [Pillar_Id], [Pillar_Key], [LawReg_Id], [LawReg_Key], [ProgramArea_Id], [ProgramArea_Key], 
			[Created_By], [Created_Date], [Modified_By], [Modified_Date]) 
		VALUES 
			(
				@User_Role_Id, 2000, N'ALL', 2004, N'ALL', 2005, N'ALL', 
				@Created_Modified_User_Name, GETDATE(), @Created_Modified_User_Name, GETDATE()
			)
End
Update User_Role Set User_Role_Status_Id=1300,User_Role_Status_Key='ACTV'

--Update Project_Funding Set FAD=0

Update Users Set Password='PVlDwWplv+dZZ/I94D0uTQ==:DpAZ25Ytyok=:EOnYZshh5ISiBaq/lh/xDA=='