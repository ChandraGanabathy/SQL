Declare @Created_By varchar(100)
Declare @Modified_By varchar(100)

Select @Created_By = 'Plateauinc'
Select @Modified_By = 'Plateauinc'
/*
1		Web Administrator
2	 	HQ Administrator
3	 	HQ User
4	 	HQ Read Only User
5	 	MSC Administrator
6	 	MSC User
7	 	MSC Read Only User
8	 	Installation Administrator
9	 	Installation  User
10	 	Installation  Read Only User
*/
--1
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' And Role_Id=9 And Action_Id=2015 And Action_Key='SUBT' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SIAA' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='PRCR'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',9,2015,'SUBT',2010,'SIAA',2010,'PRCR','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
--2
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' And Role_Id=9 And Action_Id=2015 And Action_Key='SUBT' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SIAA' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='IADA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
VALUES
	(1200,'INST',9,2015,'SUBT',2010,'SIAA',2010,'IADA','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
--3
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' And Role_Id=8 
	And Action_Id=2015 And Action_Key='SUBT' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='IAAP' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='PRCR'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
VALUES
	(1200,'INST',8,2015,'SUBT',2010,'IAAP',2010,'PRCR','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
	
--4
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' And Role_Id=8 And Action_Id=2015 And Action_Key='APPR' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='IAAP' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='SIAA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
VALUES
	(1200,'INST',8,2015,'APPR',2010,'IAAP',2010,'SIAA','Installation Admin Approved',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
--5
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' And Role_Id=8 And Action_Id=2015 
And Action_Key='DAPP' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='IADA' And CurrentStatus_Approval_Status_Id=2010 
	And CurrentStatus_Approval_Status_Key='SIAA'
	)  
BEGIN
INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
VALUES
	(1200,'INST',8,2015,'DAPP',2010,'IADA',2010,'SIAA','Installation Admin Disapproved',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
--6	
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' And Role_Id=8 And Action_Id=2015 
	And Action_Key='APPR' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='IAAP' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='MADA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
VALUES
	(1200,'INST',8,2015,'APPR',2010,'IAAP',2010,'MADA','Installation Admin Approved',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
-- 7
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' And Role_Id=8 And Action_Id=2015 
	And Action_Key='DAPP' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='IADA' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='MADA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
VALUES
	(1200,'INST',8,2015,'DAPP',2010,'IADA',2010,'MADA','Installation Admin Disapproved',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
 
 --10
 IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' And Role_Id=5 And 
	Action_Id=2015 And Action_Key='APPR' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='MAAR' And 
	CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='IAAP'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(1200,'INST',5,2015,'APPR',2010,'MAAR',2010,'IAAP','MSC Admin Approved',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
--11
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' And Role_Id=5 And Action_Id=2015 And Action_Key='DAPP' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='MADA' And CurrentStatus_Approval_Status_Id=2010 
	And CurrentStatus_Approval_Status_Key='IAAP'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(1200,'INST',5,2015,'DAPP',2010,'MADA',2010,'IAAP','MSC Admin Disapproved',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
--12
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' And Role_Id=2 And Action_Id=2015 And Action_Key='APPR' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='FELI' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='MAAR'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
VALUES
	(1200,'INST',2,2015,'APPR',2010,'FELI',2010,'MAAR','Funding Eligible',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
--13
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' And Role_Id=2 And Action_Id=2015 And Action_Key='DAPP' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='FINE' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='MAAR'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(1200,'INST',2,2015,'DAPP',2010,'FINE',2010,'MAAR','Funding Ineligible',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
 
 --15
 IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='MSC' And Role_Id=6 And Action_Id=2015 And Action_Key='SUBT' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SMAA' And CurrentStatus_Approval_Status_Id=2010 
	And CurrentStatus_Approval_Status_Key='PRCR'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(1200,'MSC',6,2015,'SUBT',2010,'SMAA',2010,'PRCR','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
 --16
 IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='MSC' And Role_Id=6 And Action_Id=2015 And Action_Key='SUBT' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SMAA' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='MADA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(1200,'MSC',6,2015,'SUBT',2010,'SMAA',2010,'MADA','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
 --17
 IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='MSC' And Role_Id=5 
	And Action_Id=2015 And Action_Key='SUBT' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='MAAR' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='PRCR'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(1200,'MSC',5,2015,'SUBT',2010,'MAAR',2010,'PRCR','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

--18
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='MSC' And Role_Id=5 And Action_Id=2015 And Action_Key='APPR' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='MAAR' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='SMAA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(1200,'MSC',5,2015,'APPR',2010,'MAAR',2010,'SMAA','MSC Admin Approved',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
--19
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='MSC' And Role_Id=5 And Action_Id=2015 And Action_Key='DAPP' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='MADA' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='SMAA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
VALUES
	(1200,'MSC',5,2015,'DAPP',2010,'MADA',2010,'SMAA','MSC Admin Disapproved',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
--20
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='MSC' And Role_Id=2 And Action_Id=2015 And Action_Key='APPR' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='FELI' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='MAAR'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'MSC',2,2015,'APPR',2010,'FELI',2010,'MAAR','Funding Eligible',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
--21
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='MSC' And Role_Id=2 And Action_Id=2015 And Action_Key='DAPP' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='FINE' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='MAAR'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(1200,'MSC',2,2015,'DAPP',2010,'FINE',2010,'MAAR','Funding Ineligible',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

--22
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='HQ' And Role_Id=3 And Action_Id=2015 And Action_Key='SUBT' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='PRCR'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
VALUES
	(1200,'HQ',3,2015,'SUBT',2010,'SHAP',2010,'PRCR','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
--23
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='HQ' And Role_Id=3 And Action_Id=2015 And Action_Key='SUBT' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='FINE'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
	(1200,'HQ',3,2015,'SUBT',2010,'SHAP',2010,'FINE','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END	
--24
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='HQ' And Role_Id=2 And Action_Id=2015 And Action_Key='SUBT' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='PRCR'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
VALUES
	(1200,'HQ',2,2015,'SUBT',2010,'SHAP',2010,'PRCR','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

--25
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='HQ' And Role_Id=2 And Action_Id=2015 And Action_Key='APPR' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='FELI' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='SHAP'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
VALUES
	(1200,'HQ',2,2015,'APPR',2010,'FELI',2010,'SHAP','Funding Eligible',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
--26
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='HQ' And Role_Id=2 And Action_Id=2015 And Action_Key='DAPP' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='FINE' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='SHAP'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'HQ',2,2015,'DAPP',2010,'FINE',2010,'SHAP','Funding Ineligible',@Created_By, GETDATE(), @Modified_By, GETDATE())
END


/*========== WEB Admin Role ===========================*/
--27
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='HQ' And Role_Id=1 And Action_Id=2015 And Action_Key='SUBT' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='PRCR'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
VALUES
	(1200,'HQ',1,2015,'SUBT',2010,'SHAP',2010,'PRCR','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
--28
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='HQ' And Role_Id=1 And Action_Id=2015 And Action_Key='APPR' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='FELI' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='SHAP'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
	,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
	,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
VALUES
	(1200,'HQ',1,2015,'APPR',2010,'FELI',2010,'SHAP','Funding Eligible',@Created_By, GETDATE(), @Modified_By, GETDATE())
END
--29
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='HQ' And Role_Id=1 And Action_Id=2015 And Action_Key='DAPP' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='FINE' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='SHAP'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'HQ',1,2015,'DAPP',2010,'FINE',2010,'SHAP','Funding Ineligible',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

-- HQ Admin, Operation is Funding In Eligible for MSC Project, Then it goes to MSC Admin plate for approving or disapproving
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='MSC' And Role_Id=5 And Action_Id=2015 And Action_Key='APPR' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='MAAR' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='FINE'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'MSC',5,2015,'APPR',2010,'MAAR',2010,'FINE','MSC Admin Approved',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='MSC' And Role_Id=5 And Action_Id=2015 And Action_Key='DAPP' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='MADA' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='FINE'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'MSC',5,2015,'DAPP',2010,'MADA',2010,'FINE','MSC Admin Approved',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='MSC' And Role_Id=5 And Action_Id=2015 And Action_Key='DAPP' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='MADA' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='FINE'
	and Notes = 'MSC Admin Approved'
	)
	BEGIN
		update Approval_Process set Notes = 'MSC Admin DisApproved' where Project_Type_Id=1200 And Project_Type_Key='MSC' And Role_Id=5 And Action_Id=2015 And Action_Key='DAPP' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='MADA' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='FINE'
	and Notes = 'MSC Admin Approved'
	END


	IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' And Role_Id=8 And Action_Id=2015 And Action_Key='SUBT' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SIAA' And CurrentStatus_Approval_Status_Id=2010 
	And CurrentStatus_Approval_Status_Key='IADA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',8,2015,'SUBT',2010,'SIAA',2010,'IADA','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END


IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='MSC' And Role_Id=5 And Action_Id=2015 And Action_Key='SUBT' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SMAA' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='MADA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'MSC',5,2015,'SUBT',2010,'SMAA',2010,'MADA','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='HQ' And Role_Id=2 And Action_Id=2015 And Action_Key='SUBT' And 
	NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='FINE'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'HQ',2,2015,'SUBT',2010,'SHAP',2010,'FINE','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

/* ============= MSC Admin Creating a Installation Project ========================= */
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=5 And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='PRCR'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',5,2015,'SUBT',2010,'SHAP',2010,'PRCR','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=2 And Action_Id=2015 And Action_Key='APPR' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='FELI' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='SHAP'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',2,2015,'APPR',2010,'FELI',2010,'SHAP','HQ Administrator approves the project',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=2 And Action_Id=2015 And Action_Key='DAPP' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='FINE' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='SHAP'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',2,2015,'DAPP',2010,'FINE',2010,'SHAP','HQ Administrator disapproves the project.',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=5 And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='IADA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',5,2015,'SUBT',2010,'SHAP',2010,'IADA','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END


IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=5 And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='MADA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',5,2015,'SUBT',2010,'SHAP',2010,'MADA','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

/* ============= HQ Admin Creating a  MSC Project ========================= */
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='MSC' 
	And Role_Id=2 And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='PRCR'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'MSC',2,2015,'SUBT',2010,'SHAP',2010,'PRCR','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='MSC' 
	And Role_Id=2 And Action_Id=2015 And Action_Key='APPR' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='FELI' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='SHAP'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'MSC',2,2015,'APPR',2010,'FELI',2010,'SHAP','HQ Administrator approves the project.',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='MSC' 
	And Role_Id=2 And Action_Id=2015 And Action_Key='DAPP' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='FINE' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='SHAP'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'MSC',2,2015,'DAPP',2010,'FINE',2010,'SHAP','HQ Administrator disapproves the project.',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='MSC' 
	And Role_Id=2 And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='FINE'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'MSC',2,2015,'SUBT',2010,'SHAP',2010,'FINE','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='MSC' 
	And Role_Id=2 And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='MADA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'MSC',2,2015,'SUBT',2010,'SHAP',2010,'MADA','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

/* ============= HQ Admin Creating a  Installation Project ========================= */
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=2 And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='PRCR'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',2,2015,'SUBT',2010,'SHAP',2010,'PRCR','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=2 And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='FINE'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',2,2015,'SUBT',2010,'SHAP',2010,'FINE','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=2 And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='MADA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',2,2015,'SUBT',2010,'SHAP',2010,'MADA','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=2 And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='IADA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',2,2015,'SUBT',2010,'SHAP',2010,'IADA','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

 
/* ============= MSC User Creating a Installation Project ========================= */
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=6 And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SMAA' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='PRCR'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',6,2015,'SUBT',2010,'SMAA',2010,'PRCR','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=5 And Action_Id=2015 And Action_Key='APPR' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='MAAR' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='SMAA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',5,2015,'APPR',2010,'MAAR',2010,'SMAA','MSC Admin Approved',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=5 And Action_Id=2015 And Action_Key='DAPP' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='MADA' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='SMAA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',5,2015,'DAPP',2010,'MADA',2010,'SMAA','MSC Admin Disapproved',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=6 And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SMAA' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='MADA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',6,2015,'SUBT',2010,'SMAA',2010,'MADA','Submitted for MSC Admin Approval',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=5  And Action_Id=2015 And Action_Key='APPR' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='MAAR' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='FINE'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',5,2015,'APPR',2010,'MAAR',2010,'FINE','MSC Admin Approved',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=5  And Action_Id=2015 And Action_Key='DAPP' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='MADA' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='FINE'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',5,2015,'DAPP',2010,'MADA',2010,'FINE','MSC Admin Disapproved',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=6 And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SMAA' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='IADA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',6,2015,'SUBT',2010,'SMAA',2010,'IADA','Submitted for MSC Admin Approval',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

/* ============= HQ User Creating a Installation Project ========================= */
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=3  And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='PRCR'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',3,2015,'SUBT',2010,'SHAP',2010,'PRCR','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=3  And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='FINE'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',3,2015,'SUBT',2010,'SHAP',2010,'FINE','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=3 And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='MADA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',3,2015,'SUBT',2010,'SHAP',2010,'MADA','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END


IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='INST' 
	And Role_Id=3 And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='IADA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'INST',3,2015,'SUBT',2010,'SHAP',2010,'IADA','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

/* ============= HQ User Creating a MSC Project ========================= */
IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='MSC' 
	And Role_Id=3  And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='PRCR'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'MSC',3,2015,'SUBT',2010,'SHAP',2010,'PRCR','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='MSC' 
	And Role_Id=3  And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='FINE'
	)  
BEGIN
INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'MSC',3,2015,'SUBT',2010,'SHAP',2010,'FINE','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END


IF NOT EXISTS (SELECT 1 FROM Approval_Process WHERE Project_Type_Id=1200 And Project_Type_Key='MSC' 
	And Role_Id=3 And Action_Id=2015 And Action_Key='SUBT' 
	And NewStatus_Approval_Status_Id=2010 And NewStatus_Approval_Status_Key='SHAP' 
	And CurrentStatus_Approval_Status_Id=2010 And CurrentStatus_Approval_Status_Key='MADA'
	)  
BEGIN
	INSERT INTO [dbo].[Approval_Process] ([Project_Type_Id],[Project_Type_Key],[Role_Id],[Action_Id],[Action_Key]
		,[NewStatus_Approval_Status_Id],[NewStatus_Approval_Status_Key],[CurrentStatus_Approval_Status_Id],[CurrentStatus_Approval_Status_Key],[Notes]
		,[Created_By],[Created_Date],[Modified_By],[Modified_Date])
	VALUES
		(1200,'MSC',3,2015,'SUBT',2010,'SHAP',2010,'MADA','',@Created_By, GETDATE(), @Modified_By, GETDATE())
END

/*========================== Installation Email Configuration =============*/

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=1)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				1,0,
				8,2016,'CURT',1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=2)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				2,0,
				8,2016,'CURT',1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=3)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				3,0,
				8,2016,'CURT',1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=4)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				4,0
				,5,2016,'FLPT',1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=5)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				5,1
				,NULL,NULL,NULL,1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=6)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				6,0
				,5,2016,'FLPT',1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=7)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				7,1
				,NULL,NULL,NULL,1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=8)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				8,0,
				5,2016,'FLPT',1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=9)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				9,1
				,NULL,NULL,NULL,1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=10)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				10,0
				,2,2016,'SLPT',1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=11)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				11,0
				,8,2016,'CURT',1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=12)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				12,1
				,NULL,NULL,NULL,1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=13)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				13,0
				,8,2016,'CURT',1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End
/*========================== MSC Email Configuration =============*/
IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=14)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				14,0
				,5,2016,'CURT',1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=15)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				15,0
				,5,2016,'CURT',1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=16)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				16,0
				,5,2016,'CURT',1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=17)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				17,0
				,2,2016,'FLPT',1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=18)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				18,1
				,NULL,NULL,NULL,1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=19)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				19,1
				,NULL,NULL,NULL,1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=20)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				20,0
				,5,2016,'CURT',1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

/*========================== HQ Email Configuration =============*/

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=21)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				21,0
				,2,2016,'CURT',1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=22)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				22,0
				,2,2016,'CURT',1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=23)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				23,0
				,2,2016,'CURT',1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=24)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				24,1
				,NULL,NULL,NULL,1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=25)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				25,1
				,NULL,NULL,NULL,1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=26)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				26,0
				,1,2016,'CURT',1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=27)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				27,1
				,NULL,NULL,NULL,1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=28)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				28,1
				,NULL,NULL,NULL,1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

-- Sending Email :  HQ Admin, Operation is Funding In Eligible for MSC Project, Then it goes to MSC Admin plate for approving or disapproving

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=29)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				29,0
				,2,2016,'FLPT',1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=30)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				30,1
				,NULL,NULL,NULL,1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=31)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				31,1
				,NULL,NULL,NULL,1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End

IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=32)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				32,1
				,NULL,NULL,NULL,1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End
IF NOT EXISTS (SELECT 1 FROM Approval_Process_Email_Config WHERE Approval_Process_Id=33)  
BEGIN
	INSERT INTO [Approval_Process_Email_Config]
			   (
				[Approval_Process_Id], [To_Project_Owner]
				,[Roled_Id_To_Send],[Hierarchy_Parent_Selection_Id],[Hierarchy_Parent_Selection_Key]
				,[Is_Enabled],[Subject],[Message]
				,[Created_By],[Created_Date],[Modified_By],[Modified_Date]
			   )
		 VALUES
			   (
				33,1
				,NULL,NULL,NULL,1
				,'Project Number {0}'
				,'The project Number {0} has been submitted to the role {1}'
				,@Created_By, GETDATE(), @Modified_By, GETDATE()
			   )
End