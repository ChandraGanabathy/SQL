GO
Declare @Created_By varchar(100)
Declare @Modified_By varchar(100)

Select @Created_By = 'Plateauinc'
Select @Modified_By = 'Plateauinc'
-- Table Name Display
IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project','Project',NULL,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project_Funding')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project_Funding','Funding',NULL,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project_Answer')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project_Answer','Answer',NULL,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project_Document')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project_Document','Document',NULL,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project_Note')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project_Note','Notes',NULL,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

-- Project Table - Column Name Display 
IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project.Project_Description')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project.Project_Description','Description',Null,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project.Class_Key')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project.Class_Key','Class',2011,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project.Status_Key')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project.Status_Key','Status',2007,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project.ROI')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project.ROI','ROI',NULL,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project.Is_Recurring')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project.Is_Recurring','Recurring',Null,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project.Impact_to_Mission_Key')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project.Impact_to_Mission_Key','Impact to Mission',2020,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project.Environmental_Impact_Code_Key')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project.Environmental_Impact_Code_Key','Environmental Impact',2022,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project.Project_Status_Date')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project.Project_Status_Date','Project Status Date',Null,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Audit_Display Where Entity_Name ='Project.Owner_ID')  
Begin
       Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
       values  ('Project.Owner_ID','Existing Owner',NULL,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

-- Project Funding - Column Name Display 
IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project_Funding.Priority')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project_Funding.Priority','Local Priority',Null,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project_Funding.Validated')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project_Funding.Validated','Validated',Null,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project_Funding.Programmed')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project_Funding.Programmed','Programmed',Null,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project_Funding.Funded')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project_Funding.Funded','Funded',Null,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project_Funding.Obligated')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project_Funding.Obligated','Obligated',Null,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project_Funding.Approval_Status_Key')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project_Funding.Approval_Status_Key','Approval Status',2010,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project_Funding.Is_UFR')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project_Funding.Is_UFR','Is UFR',Null,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where Entity_Name ='Project_Funding.MDEP_Key')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project_Funding.MDEP_Key','MDEP',2019,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where Entity_Name ='Project_Funding.MSC_Priority')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project_Funding.MSC_Priority','MSC Priority',Null,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Audit_Display Where Entity_Name ='Project_Funding.HQ_Priority')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project_Funding.HQ_Priority','HQ Priority',Null,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Audit_Display Where Entity_Name ='Project_Funding.Funding_Status_Code_Key')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project_Funding.Funding_Status_Code_Key','Funding Status',2024,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

-- Project Answer - Column Name Display 
IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project_Answer.Answer')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project_Answer.Answer','Answer',Null,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

-- Project Note - Column Name Display 
IF Not Exists (Select 1 from Audit_Display Where   Entity_Name ='Project_Note.Notes')  
Begin
	Insert Audit_Display (Entity_Name, Display_Name, Code_Id, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  ('Project_Note.Notes','Notes',Null,@Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Exists (Select 1 from Audit_Display Where Entity_Name ='Project.Owner_ID' And Display_Name='Existing Owner')  
Begin
	Update Audit_Display Set Display_Name='Project Owner' Where Entity_Name ='Project.Owner_ID'
End

IF Exists (Select 1 from Audit_Display Where Entity_Name ='Project.Project_Description' And Display_Name='Description')  
Begin
	Update Audit_Display Set Display_Name='Project Description' Where Entity_Name ='Project.Project_Description' And Display_Name='Description'
End

IF Exists (Select 1 from Audit_Display Where Entity_Name ='Project.Impact_to_Mission_Key' And Display_Name='Impact to Mission')  
Begin
	Update Audit_Display Set Display_Name='Mission Impact' Where Entity_Name ='Project.Impact_to_Mission_Key' And Display_Name='Impact to Mission'
End

