 
IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'report_Catalog_Usage')
BEGIN
	DROP PROC report_Catalog_Usage
END

GO
--report_Catalog_Usage 'CON','CWA','NG2H',2013
CREATE procedure [dbo].[report_Catalog_Usage]
(
 @Pillar VARCHAR(MAX),
 @LawReg VARCHAR(MAX),
 @ProgramArea VARCHAR(MAX),
 @FiscalYear VARCHAR(MAX),
 @ApprovalStatus VARCHAR(MAX),
 @FundingStatus VARCHAR(MAX),
 @HierarchyDataIds VARCHAR(MAX)
)
AS
BEGIN
	
		 Select ID,PropertyName As Property,ProjectCount,CatalogNumber
				,CatalogName,Pillar,LawReg,ProgramArea,Validated,Programmed
				,Planned,Funded,Obligated,FAD,ApprovalStatus 
		 From 
	 (
			  Select * From (
								Select 
										C.Id, C.Catalog_Number
										, HD.Name
										
								From Project P
								Join Catalog C 
										ON P.Catalog_Id=C.Id
								Join Hierarchy_Data HD
										ON P.Hierarchy_Data_Id=HD.Id
								Join Pillar_LawReg_Mapping lm 
										ON lm.Id = c.Pillar_Lawreg_Mapping_Id
								Left Join Code_Value pr 
										ON pr.CODE_ID=lm.Pillar_Id and pr.Code_Value_Key = lm.Pillar_Key
								Left Join Code_Value law 
										ON law.CODE_ID=lm.LawReg_Id  and law.Code_Value_Key = lm.LawReg_Key
								Left Join Code_Value pa 
										ON pa.CODE_ID=lm.ProgramArea_Id  and pa.Code_Value_Key = lm.ProgramArea_Key
								Where 
										(pr.Code_Value_Key IN(SELECT data from dbo.Split(@Pillar,','))
										 AND law.Code_Value_Key IN(SELECT data from dbo.Split(@LawReg,','))
										 AND pa.Code_Value_Key IN(SELECT data from dbo.Split(@ProgramArea,','))
										 AND HD.Id IN (	SELECT data from dbo.Split(@HierarchyDataIds,','))	
										 --AND c.Catalog_Number ='CMP0099'		 
										 )
								Group By 
										C.Id, C.Catalog_Number,HD.Name 
						) A 
				
			Join 
						(
								Select 
										C.Id AS CatalogId, C.Catalog_Number AS CatalogNumber, COUNT(P.Catalog_Id) AS ProjectCount
										, HD.Name AS PropertyName,c.Catalog_Name as CatalogName ,
										CASE WHEN pr.Code_Value_Description = 'All' then @Pillar ELSE pr.Code_Value_Description end as [Pillar],
										CASE WHEN law.Code_Value_Description = 'All' then @LawReg ELSE law.Code_Value_Description end as [LawReg],
										pa.Code_Value_Description as ProgramArea 
										,SUM(ISNULL(PF.Validated,0)) Validated, SUM(ISNULL(PF.Programmed,0)) Programmed,SUM(ISNULL(PF.Planned,0)) Planned,
										SUM(ISNULL(PF.Funded,0)) Funded, SUM(ISNULL(PF.Obligated,0)) Obligated,0 as FAD
										,ApprovalStatus.Code_Value_Description as ApprovalStatus
							 
								From Project P
								Join Catalog C 
										ON P.Catalog_Id=C.Id
								Join Hierarchy_Data HD
										ON P.Hierarchy_Data_Id=HD.Id
								Join Project_Funding PF
										ON P.Id=PF.Project_Id
								Join Pillar_LawReg_Mapping lm on lm.Id = c.Pillar_Lawreg_Mapping_Id
								Left Join Code_Value pr 
										ON pr.CODE_ID=lm.Pillar_Id and pr.Code_Value_Key = lm.Pillar_Key
								Left Join Code_Value law 
										ON law.CODE_ID=lm.LawReg_Id  and law.Code_Value_Key = lm.LawReg_Key
								Left Join Code_Value pa 
										ON pa.CODE_ID=lm.ProgramArea_Id  and pa.Code_Value_Key = lm.ProgramArea_Key
								Left Join Code_Value ApprovalStatus 
										ON ApprovalStatus.CODE_ID=pf.Approval_Status_Id  AND ApprovalStatus.Code_Value_Key = pf.Approval_Status_Key
								Left Join Code_Value FundingStatus 
										ON FundingStatus.CODE_ID=pf.Funding_Status_Code_Id  AND FundingStatus.Code_Value_Key = pf.Funding_Status_Code_Key
								Where 
										(pr.Code_Value_Key IN(SELECT data from dbo.Split(@Pillar,','))
										 AND law.Code_Value_Key IN(SELECT data from dbo.Split(@LawReg,','))
										 AND pa.Code_Value_Key IN(SELECT data from dbo.Split(@ProgramArea,','))
										 AND PF.FY IN(SELECT data from dbo.Split(@FiscalYear,','))
										 AND (@ApprovalStatus ='' OR ApprovalStatus.Code_Value_Key IN(SELECT data FROM dbo.Split(@ApprovalStatus,',')))
										 AND (@FundingStatus ='' OR FundingStatus.Code_Value_Key IN(SELECT data FROM dbo.Split(@FundingStatus,',')))
										 AND HD.Id IN (	SELECT data from dbo.Split(@HierarchyDataIds,','))	
										 --AND c.Catalog_Number ='CMP0099'		 		 
										 )
								Group By 
									C.Id, C.Catalog_Number, HD.Name,C.Catalog_Name,pr.Code_Value_Description 
									,law.Code_Value_Description,pa.Code_Value_Description
									,ApprovalStatus.Code_Value_Description
						) B 
				ON A.Id =B.CatalogId And A.Catalog_Number=B.CatalogNumber And A.Name=B.PropertyName
	 
 ) T
 
END

 
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'report_Funding_Summary_Pb28')
BEGIN
	DROP PROC report_Funding_Summary_Pb28
END

GO
---report_Funding_Summary_Pb28 '','ENFD','0','','','','','','PRCR,SIAA,IAAP,IADA,SMAA,MAAR,MADA,SHAP,FELI,FINE'
CREATE procedure [dbo].[report_Funding_Summary_Pb28]
(
@Property VARCHAR(MAX),
@Class VARCHAR(MAX),
@Pillar VARCHAR(MAX),
@LawReg VARCHAR(MAX),
@ProgramArea VARCHAR(MAX),
@PB28Title VARCHAR(MAX),
@PB28Category VARCHAR(MAX),
@FundingFiscalYear VARCHAR(MAX),
@ApprovalStatus VARCHAR(MAX),
@FundingStatus VARCHAR(MAX)
)
AS
BEGIN


Select 
    PF.Id,CASE WHEN pr.Code_Value_Description = 'All' then @Pillar ELSE pr.Code_Value_Description end as [Pillar]
    ,Title.Code_Value_Description as Pb28Title,
    cat.Code_Value_Description as Pb28Category,
    ISNULL(PF.FY,0) as FiscalYear,
    SUM(ISNULL(PF.Validated,0)) Validated, 
    SUM(ISNULL(PF.Programmed,0)) Programmed,
    SUM(ISNULL(PF.Planned,0)) Planned,
    SUM(ISNULL(PF.Funded,0)) Funded, SUM(ISNULL(PF.Obligated,0)) Obligated,
	0 as FAD

FROM Pillar_LawReg_Mapping lm 
LEFT JOIN Code_Value pr ON pr.CODE_ID=lm.Pillar_Id AND pr.Code_Value_Key = lm.Pillar_Key
LEFT JOIN Code_Value law ON lm.LawReg_Id=law.CODE_ID And lm.LawReg_Key=law.Code_Value_Key
LEFT JOIN Code_Value pa ON lm.ProgramArea_Id=pa.CODE_ID And lm.ProgramArea_Key=pa.Code_Value_Key
LEFT JOIN Catalog cl ON lm.Id = cl.Pillar_Lawreg_Mapping_Id
LEFT JOIN Project PJ ON cl.Id = PJ.Catalog_Id 
LEFT Join Project_Funding PF ON PJ.ID = PF.Project_Id
LEFT Join Pillar_PB28_Mapping P28M ON P28M.Id = cl.Pillar_PB28_Mapping_Id
LEFT JOIN Code_Value Title ON Title.CODE_ID=P28M.Title_Id  AND Title.Code_Value_Key = P28M.Title_Key
LEFT JOIN Code_Value cat ON cat.CODE_ID=P28M.Category_Id  AND cat.Code_Value_Key = P28M.Category_Key
--LEFT JOIN Code_Value resspon ON resspon.CODE_ID=pj.Resource_Sponsor_Id  AND resspon.Code_Value_Key = pj.Resource_Sponsor_Key
LEFT Join Hierarchy_Data hd ON hd.Id= PJ.hierarchy_Data_id
LEFT JOIN Code_Value class ON class.CODE_ID=cl.Class_Id  AND class.Code_Value_Key = cl.Class_Key
LEFT JOIN Code_Value ApprovalStatus ON ApprovalStatus.CODE_ID=pf.Approval_Status_Id  AND ApprovalStatus.Code_Value_Key = pf.Approval_Status_Key
LEFT JOIN Code_Value FundingStatus ON FundingStatus.CODE_ID=pf.Funding_Status_Code_Id  AND FundingStatus.Code_Value_Key = pf.Funding_Status_Code_Key
WHERE 
(
 (@FundingFiscalYear ='' OR PF.FY IN(SELECT data from dbo.Split(@FundingFiscalYear,',')))
 --AND 
 --(@ResourceSponsor ='' OR resspon.Code_Value_Key IN(SELECT data from dbo.Split(@ResourceSponsor,',')))
 AND 
 (@Property ='' OR hd.Id IN(SELECT data from dbo.Split(@Property,','))) 
 AND 
 (@Class ='' OR class.Code_Value_Key IN(SELECT data from dbo.Split(@Class,',')))
 --AND 
 --(@Status ='' OR proStatus.Code_Value_Key IN(SELECT data from dbo.Split(@Status,',')))
 AND 
  (@Pillar ='' OR pr.Code_Value_Key IN(SELECT data from dbo.Split(@Pillar,',')))
 AND 
  (@LawReg ='' OR law.Code_Value_Key IN(SELECT data from dbo.Split(@LawReg,',')))
 AND 
  (@ProgramArea ='' OR pa.Code_Value_Key IN(SELECT data from dbo.Split(@ProgramArea,',')))
 AND 
 (@PB28Title ='' OR Title.Code_Value_Key IN(SELECT data from dbo.Split(@PB28Title,',')) )     
 AND 
 (@PB28Category ='' OR cat.Code_Value_Key IN(SELECT data from dbo.Split(@PB28Category,',')))
 AND 
 (@ApprovalStatus ='' OR ApprovalStatus.Code_Value_Key IN(SELECT data from dbo.Split(@ApprovalStatus,',')))
 AND 
 (@FundingStatus ='' OR FundingStatus.Code_Value_Key IN(SELECT data FROM dbo.Split(@FundingStatus,',')))
)
GROUP BY 
    PF.Id,pr.Code_Value_Description,Title.Code_Value_Description,
    cat.Code_Value_Description,PF.FY
END
















GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'report_Funding_Summary_MediaLawReg')
BEGIN
	DROP PROC report_Funding_Summary_MediaLawReg
END

GO
---report_Funding_Summary_MediaLawReg '','ENFD','0','','','','','','PRCR,SIAA,IAAP,IADA,SMAA,MAAR,MADA,SHAP,FELI,FINE'
CREATE PROCEDURE [dbo].[report_Funding_Summary_MediaLawReg]
(
@Property VARCHAR(MAX),
@Class VARCHAR(MAX),
@Pillar VARCHAR(MAX),
@LawReg VARCHAR(MAX),
@ProgramArea VARCHAR(MAX),
@FundingFiscalYear VARCHAR(MAX),
@ApprovalStatus VARCHAR(MAX),
@FundingStatus VARCHAR(MAX)
)
AS
BEGIN

SELECT 
    pf.Id,ISNULL(PF.FY,0) as FiscalYear,
    CASE WHEN pr.Code_Value_Description = 'All' THEN @Pillar ELSE pr.Code_Value_Description END AS [Pillar],
    CASE WHEN law.Code_Value_Description = 'All' THEN @LawReg ELSE law.Code_Value_Description END AS [LawReg],
    pa.Code_Value_Description as ProgramArea,
    SUM(ISNULL(pf.Validated,0)) Validated, 
    SUM(ISNULL(pf.Programmed,0)) Programmed,
    SUM(ISNULL(pf.Planned,0)) Planned,
    SUM(ISNULL(pf.Funded,0)) Funded, 
    SUM(ISNULL(pf.Obligated,0)) Obligated,
	0 as FAD
FROM Pillar_LawReg_Mapping lm 
JOIN Code_Value pr ON pr.CODE_ID=lm.Pillar_Id and pr.Code_Value_Key = lm.Pillar_Key
JOIN Code_Value law ON law.CODE_ID=lm.LawReg_Id  and law.Code_Value_Key = lm.LawReg_Key
JOIN Code_Value pa ON pa.CODE_ID=lm.ProgramArea_Id  and pa.Code_Value_Key = lm.ProgramArea_Key
LEFT JOIN Catalog cl ON lm.Id = cl.Pillar_Lawreg_Mapping_Id
LEFT JOIN Project pj ON cl.Id = pj.Catalog_Id 
LEFT Join Project_Funding pf ON pj.ID = pf.Project_Id
LEFT Join Hierarchy_Data hd ON hd.Id= pj.hierarchy_Data_id
--LEFT JOIN Code_Value resspon ON resspon.CODE_ID=pj.Resource_Sponsor_Id  AND resspon.Code_Value_Key = pj.Resource_Sponsor_Key
LEFT JOIN Code_Value class ON class.CODE_ID=cl.Class_Id  AND class.Code_Value_Key = cl.Class_Key
LEFT JOIN Code_Value ApprovalStatus ON ApprovalStatus.CODE_ID=pf.Approval_Status_Id  AND ApprovalStatus.Code_Value_Key = pf.Approval_Status_Key
LEFT JOIN Code_Value FundingStatus ON FundingStatus.CODE_ID=pf.Funding_Status_Code_Id  AND FundingStatus.Code_Value_Key = pf.Funding_Status_Code_Key

WHERE 
(
 (@FundingFiscalYear ='' OR pf.FY IN(SELECT data FROM dbo.Split(@FundingFiscalYear,',')))
--AND 
-- (@ResourceSponsor ='' OR resspon.Code_Value_Key IN(SELECT data FROM dbo.Split(@ResourceSponsor,',')))
AND 
 (@Property ='' OR hd.Id IN(SELECT data FROM dbo.Split(@Property,','))) 
 AND 
 (@Class ='' OR class.Code_Value_Key IN(SELECT data FROM dbo.Split(@Class,',')))
--AND 
-- (@Status ='' OR proStatus.Code_Value_Key IN(SELECT data FROM dbo.Split(@Status,',')))
AND 
  (@Pillar ='' OR pr.Code_Value_Key IN(SELECT data FROM dbo.Split(@Pillar,',')))
AND 
 (@LawReg ='' OR law.Code_Value_Key IN(SELECT data FROM dbo.Split(@LawReg,',')) )     
 AND 
 (@ProgramArea ='' OR pa.Code_Value_Key IN(SELECT data FROM dbo.Split(@ProgramArea,',')))
AND 
 (@ApprovalStatus ='' OR ApprovalStatus.Code_Value_Key IN(SELECT data FROM dbo.Split(@ApprovalStatus,',')))
AND 
 (@FundingStatus ='' OR FundingStatus.Code_Value_Key IN(SELECT data FROM dbo.Split(@FundingStatus,',')))
)
GROUP BY pf.Id,pr.Code_Value_Description,law.Code_Value_Description,pa.Code_Value_Description,PF.FY

END















GO
IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'GetAdminQuery')
BEGIN
	DROP PROC GetAdminQuery
END
GO
CREATE PROCEDURE [dbo].[GetAdminQuery]
(
	@SqlQuery VARCHAR(MAX)
)
AS	
BEGIN
	BEGIN TRY  
		BEGIN TRANSACTION  
		  EXECUTE(@SqlQuery)
		COMMIT TRANSACTION   
	END TRY  
	BEGIN CATCH    
		ROLLBACK TRANSACTION  
		select 'Selection failed!! ' + ERROR_MESSAGE() as Information
	END CATCH
END

GO
IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'GetAdminExecuteNonQuery')
BEGIN
	DROP PROC GetAdminExecuteNonQuery
END
GO
CREATE PROCEDURE [dbo].[GetAdminExecuteNonQuery]
(
	@SqlQuery VARCHAR(MAX)
)
AS	
BEGIN
	BEGIN TRY  
		BEGIN TRANSACTION  
		  EXECUTE(@SqlQuery)
		  Select 'Transaction successfully completed!! ' + cast(@@ROWCOUNT as nvarchar)	 + ' record(s) affected' as Information
		COMMIT TRANSACTION   
	END TRY  
	BEGIN CATCH    
		ROLLBACK TRANSACTION  
		select 'Transaction failed!! ' + ERROR_MESSAGE() as Information
	END CATCH
END





