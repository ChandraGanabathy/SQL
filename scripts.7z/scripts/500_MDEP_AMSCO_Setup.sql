

------------------- MDEP Table Data insertion Script Start---------------


Declare @Created_By varchar(100),@Modified_By varchar(100)
SELECT @Created_By='Plateauinc'
SELECT @Modified_By='Plateauinc'

DELETE from MDEP
IF not exists (select 1 from MDEP where Pillar_Id = 2000 and Pillar_Key ='CMP' and Start_FY=2010) Begin  Insert into MDEP   (Pillar_Id,Pillar_Key,MDEP_Code,Start_FY,End_FY,Created_By,Created_Date,Modified_By,Modified_Date) values   (2000,'CMP','VENQ' , 2010, NULL, @Created_By,GETDATE(), @Modified_By,GETDATE())  End
IF not exists (select 1 from MDEP where Pillar_Id = 2000 and Pillar_Key ='CNS' and Start_FY=2010) Begin  Insert into MDEP   (Pillar_Id,Pillar_Key,MDEP_Code,Start_FY,End_FY,Created_By,Created_Date,Modified_By,Modified_Date) values   (2000,'CNS','VENQ' , 2010, NULL, @Created_By,GETDATE(), @Modified_By,GETDATE())  End
IF not exists (select 1 from MDEP where Pillar_Id = 2000 and Pillar_Key ='PPN' and Start_FY=2010) Begin  Insert into MDEP   (Pillar_Id,Pillar_Key,MDEP_Code,Start_FY,End_FY,Created_By,Created_Date,Modified_By,Modified_Date) values   (2000,'PPN','VENQ' , 2010, NULL, @Created_By,GETDATE(), @Modified_By,GETDATE())  End

Delete from AMSCO

------------------- MDEP Table Data insertion Script END---------------

------------------- AMSCO Table Data insertion Script START---------------
IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.00' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.00', 'ENVIRONMENTAL CONSERVATION (SUMMARY ACCOUNT)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.10' )    
BEGIN  
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date) 
    VALUES  ('131*53.10', 'RECURRING NATURAL & CULTURAL RESOURCES (SUMMARY ACCOUNT)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.11' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.11', 'PROGRAM MANAGEMENT (CONSERVATION)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.12' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.12', 'PERSONNEL TRAVEL AND TRAINING (CONSERVATION)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.16' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.16', 'PROGRAM MANAGEMENT','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.21' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.21', 'NATURAL RESOURCES PLANNING LEVEL SURVEYS','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.22' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.22', 'INTEGRATED NATURAL RESOURCES MANAGEMENT PLAN (INRMP)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.23' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.23', 'OTHER NATURAL RESOURCES MANAGEMENT','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.30' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.30', 'THREATENED AND ENDANGERED SPECIES (SUMMARY ACCOUNT)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.31' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.31', 'INVENTORIES AND SURVEYS','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.33' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.33', 'ENDANGERED SPECIES MANAGEMENT PLAN (ESMP)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.34' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.34', 'EXECUTION OF ESMP','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.40' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)    
	 VALUES  ('131*53.40', 'WETLANDS AND RUNOFF (SUMMARY ACCOUNT)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.50' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.50', 'CULTURAL RESOURCES MANAGEMENT (SUMMARY ACCOUNT)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.51' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.51', 'CULTURAL RESOURCES PLANNING LEVEL SURVEYS','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.52' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.52', 'INTEGRATED CULTURAL RESOURCES MANAGEMENT PLANS','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.53' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.53', 'HISTORIC PROPERTIES','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.54' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.54', 'NATIVE AMERICAN GRAVES PROTECTION AND REPATRIATION','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.55' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.55', 'CURATION','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.56' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.56', 'OTHER CULTURAL RESOURCES MANAGEMENT','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.60' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.60', 'REVENUE GENERATING ACTIVITIES (SUMMARY ACCOUNT)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.61' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.61', 'FOREST PRODUCTS PRODUCTION AREAS','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.63' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.63', 'AGRICULTURAL/GRAZING OUTLEASE','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())  
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.70' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*53.70', 'PEST MANAGEMENT','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())  
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*54.00' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*54.00', 'POLLUTION PREVENTION (SUMMARY ACCOUNT)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*54.10' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*54.10', 'RECURRING POLLUTION PREVENTION (SUMMARY ACCOUNT)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*54.11' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*54.11', 'ARNG PROGRAM MANAGEMENT (POLLUTION PREVENTION)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())  
 END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*54.12' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*54.12', 'ARNG PERSONNEL TRAVEL AND TRAINING (POLLUTION PREVENTION)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*54.16' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*54.16', 'ARNG PROGRAM MANAGEMENT','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*54.20' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*54.20', 'RCRA C - HAZARDOUS WASTE REDUCTION','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*54.30' )   
 BEGIN   
     INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
     VALUES  ('131*54.30', 'RCRA D- SOLID WASTE REDUCTION  (SUMMARY ACCOUNT)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
 END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*54.40' )   
 BEGIN   
     INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
     VALUES  ('131*54.40', 'AIR QUALITY','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
 END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*54.50' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*54.50', 'WATER QUALITY','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*54.60' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*54.60', 'OTHER POLLUTION PREVENTION','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*54.70' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*54.70', 'HAZARDOUS MATERIAL REDUCTION','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.00' )   
 BEGIN   
     INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
     VALUES  ('131*56.00', 'ENVIRONMENTAL COMPLIANCE (SUMMARY ACCOUNT)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
 END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.10' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.10', 'RECURRING COMPLIANCE (SUMMARY ACCOUNT)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.11' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.11', 'ARNG PROGRAM MANAGEMENT (COMPLIANCE)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.12' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.12', 'ARNG PERSONNEL TRAVEL AND TRAINING (COMPLIANCE)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.13' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.13', 'PERMITS AND FEES','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.14' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.14', 'SAMPLING, ANALYSIS AND MONITORING','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.15' )    
BEGIN
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.15', 'HAZARDOUS WASTE DISPOSAL','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.16' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.16', 'ARNG PROGRAM MANAGEMENT','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.20' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.20', 'WATER  (SUMMARY ACCOUNT)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.21' )   
 BEGIN   
     INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
     VALUES  ('131*56.21', 'RECURRING WASTEWATER MANAGEMENT','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
 END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.22' )   
 BEGIN   
     INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
     VALUES  ('131*56.22', 'SAFE DRINKING WATER','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
 END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.30' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.30', 'CLEAN AIR','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.40' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.40', 'HAZARDOUS WASTE','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.50' )   
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.50', 'UNDERGROUND STORAGE TANKS (UST)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.60' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.60', 'SOLID WASTE','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.70' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.70', 'PLANNING','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.80' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.80', 'OTHER COMPLIANCE (SUMMARY ACCOUNT)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.81' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.81', 'MULTI-MEDIA ASSESSMENTS','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.83' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.83', 'OTHER COMPLIANCE','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.92' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.92', 'ARNG PERSONNEL COMPENSATION TECHNICIANS (EPS)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.44' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*53.44', 'WETLANDS MITIGATION','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.20' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*53.20', 'NATURAL RESOURCES MANAGEMENT','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.43' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*53.43', 'WETLANDS SURVEYS AND DELINEATIONS','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.84' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.84', 'UXO & CONSTITUENTS - PROGRAMMATIC STUDIES','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.90' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.90', 'ARMY NATIONAL GUARD SPECIFIC COSTS','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.A0' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.A0', 'COMPLIANCE-RELATED CLEANUP','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.A1' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.A1', 'CLEANUP IN THE UNITED STATES AND TERRITORIES','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.A2' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.A2', 'OVERSEAS REMEDIATION','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.A3' )   
 BEGIN   
     INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
     VALUES  ('131*56.A3', 'OPERATIONAL RANGE RESPONSE ACTIONS','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
 END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '137010.AA' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('137010.AA', 'GWOT RESET','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.17' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*53.17', 'PROJECT REVIEW AND IMPACT ASSESSMENT','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.18' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*53.18', 'PLANNING AND COORDINATION','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.19' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*53.19', 'CONSERVATION STEWARDSHIP','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())  
 END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.24' )    
    BEGIN   INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*53.24', 'NON-RECURRING ECO SYSTEM MANAGEMENT','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.36' )    
BEGIN   

    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*53.36', 'NON-RECURRING IMPLEMENTATION OF ESMC AND/OR BIOLOGICAL OPINIONS','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.42' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*53.42', 'EROSION AND SEDIMENT CONTROL','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.62' )    
    BEGIN   INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*53.62', 'ADMINISTRATIVE EXPENSES OF TIMBER DISPOSAL (COE ONLY)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.64' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*53.64', 'ADMINSTRATIVE EXPENSES OF AGRICULTURE/ GRAZING OUTLEASE (COE ONLY)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*54.17' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*54.17', 'EPCRA COMPLIANCE','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*54.18' )    
BEGIN   

    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*54.18', 'OTHER POLLUTION PREVENTION NON-RECURRING','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.17' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.17', 'ADVISORY SERVICES, PLANNING AND PROJECT REVIEW','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.18' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.18', 'NON-PERMIT ENV STATUTORY RECURRING REQUIREMENTS','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.19' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.19', 'RECURRING LOW PRIORITY ENVIRONMENTAL STEWARDSHIP (CLASS 3)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.23' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.23', 'NON-RECURRING WASTE WATER','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.24' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.24', 'NON-RECURRING SAFE DRINKING WATER','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.31' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.31', 'RECURRING CLEAN AIR','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.32' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.32', 'NON-RECURRING CLEAN AIR','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.41' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.41', 'RECURRING HAZARDOUS WASTE','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.42' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.42', 'NON-RECURRING HAZARDOUS WASTE','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.51' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.51', 'RECURRING UNDERGROUND STORAGE TANKS (UST)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.52' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.52', 'NON-RECURRING UNDERGROUND STORAGE TANKS (UST)','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.86' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.86', 'NON-RECURRING TSCA','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*54.31' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*54.31', 'NON-RECURRING RCRA D - SOLID WASTE REDUCTION & DIVERSION','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.B0' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.B0', 'NON-RECURRING ENVIRONMENTAL MITIGATION COSTS','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53.25' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*53.25', 'RECURRING GEOGRAPHIC INFORMATION SYSTEMS','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.88' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.88', 'Recurring Geographic Information Systems','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.89' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.89', 'RECURRING EMERGENCY PLANNING AND COMMUNITY RIGHT TO KNOW ACT','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.27' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.27', 'RECURRING SPILL PREVENTION CONTROL AND COUNTERMEASURE (SPCC) AND ABOVE GROUND STORAGE TANKS','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.28' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.28', 'NON-RECURRING SPILL PREVENTION CONTROL AND COUNTERMEASURE (SPCC) AND ABOVE GROUND STORAGE TANKS','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.25' )    
BEGIN   
    INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
    VALUES  ('131*56.25', 'RECURRING STORM WATER MANAGEMENT','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END

IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56.26' )    
BEGIN  
	 INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)
     VALUES  ('131*56.26', 'NONRECURRING STORM WATER MANAGEMENT','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END
     
IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*56' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*56', 'Compliance APE','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END
	
IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*53' )    
BEGIN  
   INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)  
   VALUES  ('131*53', 'Conservation APE','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
   END
IF NOT EXISTS (SELECT 1 FROM AMSCO WHERE AMSCO_Code = '131*54' )    
BEGIN   
	INSERT AMSCO (AMSCO_Code, AMSCO_Description, Created_By, Created_Date, Modified_By, Modified_Date)     
	VALUES  ('131*54', 'Pollution Prevention APE','PlateauInc',GETDATE(), 'PlateauInc',GETDATE())   
END
------------------- AMSCO Table Data insertion Script END---------------

Update AMSCO SET Start_FY=2011 

