--Use STEP_AMC_7
GO
Declare @Created_By varchar(100)
Declare @Modified_By varchar(100)

Select @Created_By = 'Plateauinc'
Select @Modified_By = 'Plateauinc'

/* ============= Code Data Insertion  [BEGIN] ==============*/
IF Not Exists (Select 1 from Code where Id = 100)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (100, 'System Constant', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End 

IF Not Exists (Select 1 from Code where Id = 200)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (200, 'State', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code where Id = 300)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (300, 'User Audit Action', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End 

IF Not Exists (Select 1 from Code where Id = 1100)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (1100, 'Theme', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End 

IF Not Exists (Select 1 from Code where Id = 1200)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (1200, 'Hierarchy_Level', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End 

IF Not Exists (Select 1 from Code where Id = 1300)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (1300, 'User_Status', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End 

If Not Exists (Select 1 from Code where Id = 1400)  
Begin
Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
values  (1400, 'PageSize', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End 

If Not Exists (Select 1 from Code where Id = 1800)  
Begin
Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
values  (1800, 'Planning_Status', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End 

If Not Exists (Select 1 from Code where Id = 1801)  
Begin
Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
values  (1801, 'Prioritazation_Status', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End 

If Not Exists (Select 1 from Code where Id = 1999)  
Begin
Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
values  (1999, 'Catalog_Status', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End 

IF Not Exists (Select 1 from Code where Id = 2000)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2000, 'Pillar', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End 

IF Not Exists (Select 1 from Code where Id = 2001)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2001, 'PB28 Title', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End 

IF Not Exists (Select 1 from Code where Id = 2002)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2002, 'PB28 Category', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End 

IF Not Exists (Select 1 from Code where Id = 2003)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2003, 'PB28 SubCategory', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End 

IF Not Exists (Select 1 from Code where Id = 2004)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2004, 'Law Reg', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code where Id = 2005)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2005, 'Program Area', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code where Id = 2006)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2006, 'Answer Type', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End


IF Not Exists (Select 1 from Code where Id = 2006)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2006, 'Resource Sponsor', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code where Id = 2007)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2007, 'Status of project ', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code where Id = 2008)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2008, 'Source of project ', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code where Id = 2009)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2009, 'Type ', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code where Id = 2010)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2010, 'Approval Status', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code where Id = 2011)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2011, 'Class', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code where Id = 2012)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2012, 'Resource Sponsor', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code where Id = 2013)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2013, 'Report List', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End




--IF Not Exists (Select 1 from Code where Id = 2013)  
--Begin
--	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
--	Values  (2013, 'Project Note', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
--End

IF Not Exists (Select 1 from Code where Id = 2014)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2014, 'Change Type', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code where Id = 2015)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2015, 'Approval Action', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

/* ============= Code Data Insertion  For Approval Process Email Configuration ==============*/
IF Not Exists (Select 1 from Code where Id = 2016)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2016, 'Hierarchy Parent Selection In Approval Process Email Configuration', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code where Id = 2018)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2018, 'Role Action', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

-- MDEP Code Data
IF Not Exists (Select 1 from Code where Id = 2019)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2019, 'MDEP', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

/* ============= Impact to Mission	==============  */

IF Not Exists (Select 1 from Code where Id = 2020)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2020, 'ImpactToMission', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

/* ============= Mission Code	==============  */
IF Not Exists (Select 1 from Code where Id = 2021)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2021, 'MissionCode', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code where Id = 2022)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2022, 'Environmental Impact', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code where Id = 2023)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2023, 'Project Module Config', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code where Id = 2024)  
Begin
	Insert Code (Id, Code_Description,Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2024, 'Funding Status', @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

/* ============= Code Data Insertion  [END] ==============  */

/* ============= Code_Value Data Insertion  [BEGIN] ==============*/
-- Configuration For Enterprise & AKO Email Format
IF Not Exists (Select 1 from Code_Value where Code_ID = 100 and Code_Value_Key = 'EEML' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (100, 'EEML','EnterPrise EMail Format','mail.mil1',NULL,NULL,1, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 100 and Code_Value_Key = 'AEML' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (100, 'AEML','AKO EMail Format','us.army.mil1',NULL,NULL,2, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

---- Configuration for Version of the System
IF Not Exists (Select 1 from Code_Value where Code_ID = 100 and Code_Value_Key = 'VRSN')  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 Values  (100, 'VRSN','Version of the System','1.0.0.0',NULL,NULL,1, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

-- Configure System Constant for no of Fiscal Years to be populated for funding module.
IF Not Exists (Select 1 from Code_Value where Code_ID = 100 and Code_Value_Key = 'FYRO')  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 Values  (100, 'FYRO','No Of Fiscal Years Rows','1',NULL,NULL,1, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

-- Configuration For Pages Count To Show In All Listing Page
IF Not Exists (Select 1 from Code_Value where Code_ID = 100 and Code_Value_Key = 'PCTS' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (100, 'PCTS','Page Counts To Show','25',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

-- State Data
IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'AL' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'AL','ALABAMA',Null,NULL,NULL,1, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'AK' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'AK','ALASKA',Null,NULL,NULL,2, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'AZ' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'AZ','ARIZONA',Null,NULL,NULL,3, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End	
	
IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'AR' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'AR','ARKANSAS',Null,NULL,NULL,4, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'CA' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'CA','CALIFORNIA',Null,NULL,NULL,5, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'CO' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'CO','COLORADO',Null,NULL,NULL,6, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'CT' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'CT','CONNECTICUT',Null,NULL,NULL,7, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'DE' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'DE','DELAWARE',Null,NULL,NULL,8, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'FL' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'FL','FLORIDA',Null,NULL,NULL,9, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End	


IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'GA' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'GA','GEORGIA',Null,NULL,NULL,10, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'HI' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'HI','HAWAII',Null,NULL,NULL,11, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'ID' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'ID','IDAHO',Null,NULL,NULL,12, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'IL' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'IL','ILLINOIS',Null,NULL,NULL,13, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'IN' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'IN','INDIANA',Null,NULL,NULL,14, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'IA' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'IA','IOWA',Null,NULL,NULL,15, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'KS' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'KS','KANSAS',Null,NULL,NULL,16, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'KY' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'KY','KENTUCKY',Null,NULL,NULL,17, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End	

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'LA' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'LA','LOUISIANA',Null,NULL,NULL,18, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'ME' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'ME','MAINE',Null,NULL,NULL,19, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'MD' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'MD','MARYLAND',Null,NULL,NULL,20, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'MA' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'MA','MASSACHUSETTS',Null,NULL,NULL,21, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End	

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'MI' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'MI','MICHIGAN',Null,NULL,NULL,22, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'MN' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'MN','MINNESOTA',Null,NULL,NULL,23, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'MS' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'MS','MISSISSIPPI',Null,NULL,NULL,24, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'MO' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'MO','MISSOURI',Null,NULL,NULL,25, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'MT' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'MT','MONTANA',Null,NULL,NULL,26, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'NE' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'NE','NEBRASKA',Null,NULL,NULL,27, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End


IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'NV' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'NV','NEVADA',Null,NULL,NULL,28, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'NH' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'NH','NEW HAMPSHIRE',Null,NULL,NULL,29, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'NJ' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'NJ','NEW JERSEY',Null,NULL,NULL,30, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'NM' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'NM','NEW MEXICO',Null,NULL,NULL,31, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'NY' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'NY','NEW YORK',Null,NULL,NULL,32, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'NC' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'NC','NORTH CAROLINA',Null,NULL,NULL,33, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End


IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'ND' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'ND','NORTH DAKOTA',Null,NULL,NULL,34, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'OH' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'OH','OHIO',Null,NULL,NULL,35, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'OK' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'OK','OKLAHOMA',Null,NULL,NULL,36, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End


IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'OR' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'OR','OREGON',Null,NULL,NULL,37, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'PA' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'PA','PENNSYLVANIA',Null,NULL,NULL,38, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'RI' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'RI','RHODE ISLAND',Null,NULL,NULL,39, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'SC' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'SC','SOUTH CAROLINA',Null,NULL,NULL,40, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'SD' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'SD','SOUTH DAKOTA',Null,NULL,NULL,41, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'TN' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'TN','TENNESSEE',Null,NULL,NULL,42, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'TX' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'TX','TEXAS',Null,NULL,NULL,43, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'UT' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'UT','UTAH',Null,NULL,NULL,44, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
	
IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'VT' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'VT','VERMONT',Null,NULL,NULL,45, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'VA' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'VA','VIRGINIA',Null,NULL,NULL,46, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End	

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'WA' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'WA','WASHINGTON',Null,NULL,NULL,47, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'WV' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'WV','WEST VIRGINIA',Null,NULL,NULL,48, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'WI' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'WI','WISCONSIN',Null,NULL,NULL,49, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 200 and Code_Value_Key = 'WY' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (200, 'WY','WYOMING',Null,NULL,NULL,50, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

-- User Audit 
IF Not Exists (Select 1 from Code_Value where   Code_ID = 300 and Code_Value_Key = 'LOGI' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (300, 'LOGI','Login',Null,NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 300 and Code_Value_Key = 'CHRO' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (300, 'CHRO','Change Role',Null,NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 300 and Code_Value_Key = 'IMPE' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (300, 'IMPE','Impersonation',Null,NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 300 and Code_Value_Key = 'GOBA' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (300, 'GOBA','Go back to Original user',Null,NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 300 and Code_Value_Key = 'LOGT' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (300, 'LOGT','Logout',Null,NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

-- Bootstrap Theme
IF Not Exists (Select 1 from Code_Value where  Code_Id = 1100 and Code_Value_Key = 'GREN' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (1100, 'GREN','Environment green','/Bootstrap/css/Bootstrap.css',NULL,NULL,1, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_Id = 1100 and Code_Value_Key = 'ORNG' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (1100, 'ORNG','Mandarin Orange','/Bootstrap/css/Orange.css',NULL,NULL,2, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_Id = 1100 and Code_Value_Key = 'BLUE' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (1100, 'BLUE','Cool Blue','/Bootstrap/css/CoolBlue.css',NULL,NULL,3, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
-- Hieraarchy Level
IF Not Exists (Select 1 from Code_Value where   Code_Id = 1200 and Code_Value_Key = 'HQ' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (1200, 'HQ','Head Quarters',NULL,NULL,NULL,1, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_Id = 1200 and Code_Value_Key = 'MSC' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (1200, 'MSC','Major SubCommand',NULL,NULL,NULL,2, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_Id = 1200 and Code_Value_Key = 'INST' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (1200, 'INST','Installation',NULL,NULL,NULL,3, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

-- User Status
IF Not Exists (Select 1 from Code_Value where   Code_Id = 1300 and Code_Value_Key = 'ACTV' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (1300, 'ACTV','Active',NULL,NULL,NULL,1, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_Id = 1300 and Code_Value_Key = 'IACT' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (1300, 'IACT','InActive',NULL,NULL,NULL,2, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_Id = 1300 and Code_Value_Key = 'INVT' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (1300, 'INVT','Invited',NULL,NULL,NULL,3, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

-- Page Size Code Value Data
If Not Exists (Select 1 from Code_Value where Code_ID = 1400 and Code_Value_Key = '1' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (1400, '1','10',NULL,NULL,NULL,1, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End  
If Not Exists (Select 1 from Code_Value where Code_ID = 1400 and Code_Value_Key = '2' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (1400, '2','25',NULL,NULL,NULL,2, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End  
If Not Exists (Select 1 from Code_Value where Code_ID = 1400 and Code_Value_Key = '3' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (1400, '3','50',NULL,NULL,NULL,3, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End  
If Not Exists (Select 1 from Code_Value where Code_ID = 1400 and Code_Value_Key = '4' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (1400, '4','100',NULL,NULL,NULL,4, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End  
If Not Exists (Select 1 from Code_Value where Code_ID = 1400 and Code_Value_Key = '5' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (1400, '5','200',NULL,NULL,NULL,4, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End  
If Not Exists (Select 1 from Code_Value where Code_ID = 1400 and Code_Value_Key = '6' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (1400, '6','500',NULL,NULL,NULL,4, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End 



-- Update Data 1 Value for Code Id 1400
If Exists (Select 1 from Code_Value where Code_ID = 1400 and Code_Value_Key = '1' And Data1 Is Null )  
BEGIN
	Update Code_Value Set Data1='10' Where Code_ID = 1400 and Code_Value_Key = '1'
END

If Exists (Select 1 from Code_Value where Code_ID = 1400 and Code_Value_Key = '2' And Data1 Is Null )  
BEGIN
	Update Code_Value Set Data1='25' Where Code_ID = 1400 and Code_Value_Key = '2'
END

If Exists (Select 1 from Code_Value where Code_ID = 1400 and Code_Value_Key = '3' And Data1 Is Null )  
BEGIN
	Update Code_Value Set Data1='50' Where Code_ID = 1400 and Code_Value_Key = '3'
END

If Exists (Select 1 from Code_Value where Code_ID = 1400 and Code_Value_Key = '4' And Data1 Is Null )  
BEGIN
	Update Code_Value Set Data1='100' Where Code_ID = 1400 and Code_Value_Key = '4'
END

If Exists (Select 1 from Code_Value where Code_ID = 1400 and Code_Value_Key = '5' And Data1 Is Null )  
BEGIN
	Update Code_Value Set Data1='200' Where Code_ID = 1400 and Code_Value_Key = '5'
END

If Exists (Select 1 from Code_Value where Code_ID = 1400 and Code_Value_Key = '6' And Data1 Is Null )  
BEGIN
	Update Code_Value Set Data1='500' Where Code_ID = 1400 and Code_Value_Key = '6'
END
---- Planning Status Values

IF Not Exists (Select 1 from Code_Value where    Code_Id = 1800 and Code_Value_Key = 'NPLN' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (1800, 'NPLN','Not Planned','N',NULL,NULL,1, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where    Code_Id = 1800 and Code_Value_Key = 'PLND' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (1800, 'PLND','Planning Completed','N',NULL,NULL,1, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

---- Prioritization Status Values

IF Not Exists (Select 1 from Code_Value where    Code_Id = 1801 and Code_Value_Key = 'NPRD' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (1801, 'NPRD','Pending Prioritization','N',NULL,NULL,1, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where    Code_Id = 1801 and Code_Value_Key = 'PRCD' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (1801, 'PRCD','Prioritization Completed','N',NULL,NULL,1, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

---- Catalog Status Values

IF Not Exists (Select 1 from Code_Value where    Code_Id = 1999 and Code_Value_Key = 'ACTV' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (1999, 'ACTV','Active','N',NULL,NULL,1, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where    Code_Id = 1999 and Code_Value_Key = 'IACT' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (1999, 'IACT','Inactive','N',NULL,NULL,1, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

-- Pillar Code Values
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2000 and Code_Value_Key = 'ALL' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2000, 'ALL','All','N',NULL,NULL,1, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where    Code_Id = 2000 and Code_Value_Key = 'CMP' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2000, 'CMP','Compliance','Y','CMP',NULL,2, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where    Code_Id = 2000 and Code_Value_Key = 'CNS' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2000, 'CNS','Conservation','Y','CNS',NULL,3, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where    Code_Id = 2000 and Code_Value_Key = 'PPN' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	Values  (2000, 'PPN','Pollution Prevention','Y','PPN',NULL,4, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

-- Creation of code values for  PB28 Title
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'AIR')     Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'AIR','Air',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'ARCH')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'ARCH','Archaeology',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'CMCP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'CMCP','Compliance Cross-Cutting Programs',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'CMPM')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'CMPM','Compliance Manpower',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'CMPO')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'CMPO','Compliance Other',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'CONO')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'CONO','Conservation Other',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'CONP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'CONP','Conservation Cross-Cutting Programs',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'CONS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'CONS','Conservation Manpower',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'CURO')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'CURO','Cultural Resources Other',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'HSTR')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'HSTR','Historic Structures',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'INRP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'INRP','Integrated Natural Resource Planning',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'LIST')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'LIST','Listed And At Risk Species',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'NARO')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'NARO','Natural Resources Other',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'PLAN')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'PLAN','Planning',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'PPCP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'PPCP','Pollution Prevention Cross-Cutting Programs',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'PPMP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'PPMP','Pollution Prevention Manpower',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'PPO')     Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'PPO','Pollution Prevention Other',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'PPP')     Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'PPP','Pollution Prevention Projects',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'STAD')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'STAD','Storage And Disposal',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'TOXS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'TOXS','Toxic Substances',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'WATR')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'WATR','Water',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2001 and Code_Value_Key = 'WETL')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2001,'WETL','Wetlands',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End

--creation of values for PB28 Category
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'ACUB')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'ACUB','ACUB',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'APRD')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'APRD','Air Pollution Reduction',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'ARCH')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'ARCH','Archeological/Curation',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'CETR')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'CETR','Conservation Education And Training',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'CMPM')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'CMPM','Compliance Manpower',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'CMTR')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'CMTR','Compliance Education And Training',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'CONT')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'CONT','Controlled Substances',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'CULT')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'CULT','Cultural/Natural Manpower',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'EDUC')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'EDUC','Education And Training',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'ENVI')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'ENVI','Environmental Impact Anaysis',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'EPCR')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'EPCR','EPCRA',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'FEDL')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'FEDL','FEDERAL',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'GEOS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'GEOS','Geospatial Information Systems (GIS) and Information Technology',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'HAZS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'HAZS','Hazardous Material /Hazardous and Solid waste Reduction',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'HAZW')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'HAZW','Haz waste',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'HIST')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'HIST','Historic Built Environment',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'INRP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'INRP','Integrated Natural Resource Planning',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'MCAA')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'MCAA','Miscellaneous Compliance Activities',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'MCNA')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'MCNA','Misc CNS Activities',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'MCRA')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'MCRA','Misc Cultural Resources Activities',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'MISC')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'MISC','Misc CMP Activities',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'MNRA')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'MNRA','Misc Natural Resources Activities',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'MPAA')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'MPAA','Miscellaneous Pollution Prevention Activities',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'NOIS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'NOIS','Noise',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'PMGT')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'PMGT','Pest Management',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'POLL')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'POLL','Pollution Prevention Manpower',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'PPOA')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'PPOA','PPOA/P2 Plan/ Green Procurement',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'SAMS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'SAMS','Stationary and Mobile Sources',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'SDWA')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'SDWA','Safe Drinking Water',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'SOLI')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'SOLI','Solid waste',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'SPRP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'SPRP','Spill Prevention and Response/ASTs',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'SWAT')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'SWAT','StormWater',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'TCRP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'TCRP','Tribal Consultation/Repatriation',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'THRE')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'THRE','Threatened And Endangered Species',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'USTS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'USTS','USTs',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'WETL')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'WETL','Wetlands',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'WLDF')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'WLDF','Wildland Fire',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'WPRD')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'WPRD','Water Pollution Reduction',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2002 and Code_Value_Key = 'WWAT')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2002,'WWAT','WasteWater',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End

-- creation of code values for PB28 Subcategory
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'ABAN')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'ABAN','Abandoned Well Closure',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'ACUB')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'ACUB','ACUB',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'ADMI')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'ADMI','Administrative',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'ADMS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'ADMS','Admin Support',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'AIR')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'AIR','Air',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'AQMP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'AQMP','Air Quality Management Plan',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'ASBE')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'ASBE','Asbestos CAA NESHAP',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'ASMA')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'ASMA','Asbestos Management',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'ASSE')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'ASSE','Assessment/Study',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'ASTS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'ASTS','Sampling, Monitoring, and Analysis - ASTs',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'ATRG')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'ATRG','Awareness Training',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'BEPA')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'BEPA','BGEPA',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'BEST')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'BEST','Best Management Practices (BMPs)',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'CATE')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'CATE','CATEX/EA/EIS',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'CERC')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'CERC','CERCLA',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'CETP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'CETP','CETEP',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'CLOS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'CLOS','Closure Plan',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'CMGT')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'CMGT','Conservation and Management',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'COMP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'COMP','Compliance Assessment',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'CONI')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'CONI','Contractors/Interns',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'CONL')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'CONL','Consultation',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'CONS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'CONS','Consumer Confidence Report',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'CTRG')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'CTRG','Cultural Training',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'CURA')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'CURA','Curation',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'DELI')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'DELI','Inventory (incl. Delineation)',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'DISP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'DISP','Disposal',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'EANS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'EANS','Equipment and Supplies',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'EMS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'EMS','EMS',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'ENVS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'ENVS','Environmental Staff',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'EQUI')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'EQUI','Equipment and Upgrades - ASTs',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'ETTR')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'ETTR','Education, Training, and Travel',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'EVAL')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'EVAL','Inventory and Evaluation',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'FEDT')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'FEDT','Federal Tech',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'FRPS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'FRPS','SPCC/FRP/ICP Supplies',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'GIS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'GIS','GIS',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'GIST')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'GIST','GIS Training',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'HMIT')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'HMIT','HM/HW IT Tracking System Supplies & Equipment',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'HMMS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'HMMS','HMMS Program Management',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'HMPS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'HMPS','HM/HW Program Support',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'HWHW')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'HWHW','HM/HW IT Tracking System Licenses & Hosting Fees',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'HWSR')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'HWSR','HW Source Reduction',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'IAEV')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'IAEV','Inventory and Evaluation - NHPA',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'ICRM')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'ICRM','ICRMP',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'INRM')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'INRM','INRMP',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'INVE')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'INVE','Inventory',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'IOMA')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'IOMA','Implementation of Management Activities',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'IPMP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'IPMP','Integrated Pest Management Plan',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'IT')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'IT','IT',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'LANS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'LANS','Plans',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'LEAD')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'LEAD','Lead Management',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'LGOG')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'LGOG','Sampling, Monitoring, and Analysis (landfill gas or groundwater)',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'MAIN')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'MAIN','Maintenance, Repair, and Rehabilitation',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'MANA')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'MANA','Management',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'MANP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'MANP','Management Plan',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'MBTA')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'MBTA','MBTA',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'MINM')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'MINM','Migratory Birds and Eagles - Management',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'MINP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'MINP','Migratory Birds and Eagles - Plans, Studies, and Permits',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'MINT')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'MINT','Migratory Birds and Eagles - Monitoring',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'MINV')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'MINV','Migratory Birds and Eagles - Inventory',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'MNHP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'MNHP','Mitigation - NHPA',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'MONI')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'MONI','Monitoring',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'NA')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'NA','N/A',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'NHPA')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'NHPA','Monitoring - NHPA',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'NOIS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'NOIS','Noise Control',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'NONE')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'NONE','Non-Environmental Staff (Awareness)',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'NRHP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'NRHP','NRHP Nomination',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'NTRG')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'NTRG','Natural Training',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'OEBG')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'OEBG','OEBGD',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'OPAR')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'OPAR','Other Plans and Reports',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'OTHE')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'OTHE','Other IT',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'OUTR')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'OUTR','Outreach',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'PANF')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'PANF','Permits and Fees - ASTs',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'PCBM')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'PCBM','PCB Management',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'PERM')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'PERM','Permits and Fees',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'PLAN')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'PLAN','Planning',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'POAE')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'POAE','Public Outreach and Education',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'POEW')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'POEW','Public Outreach, Education, and Awareness',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'PRIO')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'PRIO','Priority Area Lead Sampling',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'PROG')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'PROG','Program Support',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'PSAC')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'PSAC','Plans, Studies, and Consultation',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'PSPM')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'PSPM','Plans, Studies, and Permits',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'RACA')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'RACA','Release Assessment and Corrective Action',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'RADO')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'RADO','Radon Management',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'REPA')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'REPA','Compliance/Repatriation',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'REST')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'REST','Management (incl. Restoration)',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'RVAS')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'RVAS','Range Vulnerability Assessment',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'SALY')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'SALY','Salary',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'SAMP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'SAMP','Sampling, Monitoring, and Analysis',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'SITE')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'SITE','Site Screening',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'SMAW')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'SMAW','Sampling, Monitoring, and Analysis (waste characterization)',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'SOIL')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'SOIL','Soil Survey',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'SPCC')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'SPCC','SPCC Plan / FRP / ICP',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'SSCR')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'SSCR','Site Screening / Removal',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'SSVC')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'SSVC','Supplies and Services',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'STAD')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'STAD','Storage and Disposal - HW',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'STOR')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'STOR','Storage Tank Management Plan',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'SUPP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'SUPP','Supplies and Equipment',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'SWMP')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'SWMP','SW Management Plan',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'SWSR')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'SWSR','SW Source Reduction',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'TORM')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'TORM','Stormwater P2 Plan/ Stormwater Management Plan',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'TOXI')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'TOXI','Toxic Substances',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'TRAV')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'TRAV','Travel',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'TREA')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'TREA','Treatment Upgrades',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'TRIT')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'TRIT','TRI and Tier II Reporting',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'TRNG')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'TRNG','Training',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'UPGR')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'UPGR','Equipment and Upgrades',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'VAPO')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'VAPO','Vapor Intrusion Assessment',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'WAST')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'WAST','Wastewater Treatment Plan (incl. Sludge Management)',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'WATE')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'WATE','Water',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'WFRE')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'WFRE','Wildland Fire',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'WSVA')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'WSVA','Water System Vulnerability Assessment / Emergency Response Plan (Assessment, Study, or Plan)',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2003 and Code_Value_Key = 'WTRG')    Begin   Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,    Created_Date, Modified_By,Modified_Date)     Values  (2003,'WTRG','Web-based Training',NULL,NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End

-- creation of code values for Law Reg
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'ALL')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'ALL','All','N',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'MULT')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'MULT','Multimedia','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'CAA')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'CAA','Clean Air Act','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'CWA')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'CWA','Clean Water Act','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'NCA')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'NCA','Noise Control Act','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'NEPA')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'NEPA','National Environmental Policy Act','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'RCRC')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'RCRC','Hazardous Waste Management','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'RCRD')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'RCRD','Solid Waste Management','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'RCRI')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'RCRI','Underground Storage Tanks','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'SDWA')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'SDWA','Safe Drinking Water Act','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'TSCA')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'TSCA','Toxic Substances Control Act','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = '2004')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'2004','2001- Army Regulation 200-1','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = '3679')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'3679','Curation, 36 CFR','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'AIRF')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'AIRF','American Indian Religious Freedom Act and Executive Orders 13007 and 13175','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'ESA')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'ESA','Endangered Species Act','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'FFRA')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'FFRA','Federal Insecticide, Fungicide and Rodenticide Act','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'NAGP')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'NAGP','Native American Graves Protection and Repatriation Act','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'NHPA')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'NHPA','National Historic Preservation Act and Executive Order 11593','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'SIKE')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'SIKE','Sikes Act','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'PRVN')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'PRVN','Pollution Prevention','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'ARPA')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'ARPA','Archaeological Resources Protection Act and 36 CFR 79','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'BGEP')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'BGEP','Bald and Golden Eagle Protection Act','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'MBTA')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'MBTA','Migratory Bird Treaty Act','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'MMRP')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'MMRP','Military Munitions Response','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'EPCR')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'EPCR','Emergency Planning and Community Right-to-Know Act','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End
IF Not Exists (Select 1 from Code_Value where    Code_Id = 2004 and Code_Value_Key = 'ACUB')    Begin      Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By,      Created_Date, Modified_By,Modified_Date)        Values  (2004,'ACUB','Army Compatible Use Buffer Initiative','Y',NULL,NULL,Null, @Created_By,GETDATE(), @Modified_By,GETDATE())   End


-- Code values for Program Areas
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'ALL' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'ALL','All','N',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'SATL' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'SATL','Salaries/Travel','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'TRAN' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'TRAN','Training','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'ADCO' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'ADCO','Administrative Costs','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'EMS' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'EMS','EMS','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'EPAS' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'EPAS','EPAS','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'SISC' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'SISC','Site Screening','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'SAMP' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'SAMP','Sampling','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'EQUI' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'EQUI','Equipment','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'PEST' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'PEST','Permits/Studies','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'SAAP' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'SAAP','Studies, Assessments, Audits and Plans','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'SAAM' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'SAAM','Sampling, Analysis and Monitoring','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'PEFE' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'PEFE','Permits and Fees','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'SUEQ' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'SUEQ','Supplies and Equipment','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'SPCC' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'SPCC','Implemention of SPCC Plans','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'NOCC' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'NOCC','Noice Control Construction','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'NOCP' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'NOCP','Noise Control Planning','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'EAEI' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'EAEI','Environmental Assessment/Environmental Impact Statement','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'PIEA' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'PIEA','Public Involvement for an EA/EIS','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'NEPA' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'NEPA','NEPA Mitigation and Monitoring','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'HAWD' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'HAWD','Hazardous Waste Disposal','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'PLST' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'PLST','Plans and Studies','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'HWFS' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'HWFS','Hazardous Waste Fees and Surcharges','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'HWSA' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'HWSA','Hazardous Waste Sampling and Analysis','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'CLPL' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'CLPL','Closure Plans','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'FESU' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'FESU','Fees and Surcharges','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'SDLM' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'SDLM','Subtitle D SW Landfill Sampling/Monitoring','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'WEPO' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'WEPO','Wellhead Protection','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'ASBE' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'ASBE','Asbestos','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'LBPO' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'LBPO','Lead-based Paint','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'SDPC' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'SDPC','Storage and Disposal of PCBs','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'RADO' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'RADO','Radon','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'GIS' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'GIS','GIS','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'WIFI' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'WIFI','Wildland Fire','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'ACUB' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'ACUB','ACUB','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'PLSL' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'PLSL','Planning Level Surveys','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'NRPR' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'NRPR','Natural Resource Plans or Revision','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'MONI' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'MONI','Monitoring','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'IMPL' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'IMPL','Implementation','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'SOSU' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'SOSU','Soil Sustainment','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'FIWM' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'FIWM','Fish and Wildlife Management',Null,NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'PLSU' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'PLSU','Plans/Surveys','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'CNSL' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'CNSL','Consultation','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'ESMC' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'ESMC','ESMC Implementation','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'WEMG' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'WEMG','Wetlands Management','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'PLAN' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'PLAN','Plans','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'PANM' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'PANM','Plans/Annual Meeting',Null,NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'CURA' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'CURA','Curation','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'EVAL' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'EVAL','Evaluation','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'MRRE' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'MRRE','Maintenance, Repair and Rehabilitation','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'AGDO' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'AGDO','Agreement Documents','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'REPA' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'REPA','Repatriation','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'INES' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'INES','Inventory/Evalutation/Surveys','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'MITI' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'MITI','Mitigation','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'NACO' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'NACO','Native American Consultation','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'MATP' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'MATP','Maintenance and Treatment Plans','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'EPCR' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'EPCR','EPCRA','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'PLAS' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'PLAS','Plans and Assessments','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'SORE' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'SORE','Source Reduction','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'NG2H' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'NG2H','NG2 (NGB-HQ Only)','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'CURT' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'CURT','Cultural Resource Training','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'NART' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'NART','Natural Resource Training','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'GIST' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'GIST','GIS Training','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'ESDT' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'ESDT','Env. Staff Prof. Development Training','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'AGST' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'AGST','Above Ground Storage Tanks Permits and Fees','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'ENST' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'ENST','Environmental Stewardship','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'SUIE' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'SUIE','Surveys, Inspections and Evaluations','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'PSSI' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'PSSI','Plans, Studies, Surveys, Inspections and Evaluations','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'MANA' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'MANA','Management','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'COME' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'COME','Conservation Measure','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'PERM' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'PERM','Permit','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'NAGP' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'NAGP','NAGPRA Compliance','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'COMA' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'COMA','Conservation/Management','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'COMP' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'COMP','Compliance and Management','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'MURE' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'MURE','Munitions Response','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'REPO' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'REPO','Reporting','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2005 and Code_Value_Key = 'AACU' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2005, 'AACU','Army Compatible Use Buffer (ACUB)','Y',NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

---------- Answer Type Start ----
IF Not Exists (Select 1 from Code_Value where   Code_ID = 2006 and Code_Value_Key = 'STNG' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2006, 'STNG','String',NULL,NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 2006 and Code_Value_Key = 'BIT' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2006, 'BIT','Yes/No',NULL,NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 2006 and Code_Value_Key = 'NUME' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2006, 'NUME','Numeric',NULL,NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 2006 and Code_Value_Key = 'DATE' )  
Begin
 Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
 values  (2006, 'DATE','Date',NULL,NULL,NULL,NULL, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End
/* ============= Code_Value Data Insertion  [End] ==============*/

IF Not Exists (Select 1 from Code_Value where Code_ID = 100 and Code_Value_Key = 'EMNS')  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (100, 'EMNS',  'Content','',NULL,NULL,1, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

-- update the existing value of Brande williams that was initially scripted out
IF Not Exists (Select 1 from Code_Value where Code_ID = 100 and Code_Value_Key = 'EMNS' and Code_Value_Description = 'Content')  
Begin
	Update Code_Value set Code_Value_Description = 'Content' where Code_ID = 100 and Code_Value_Key = 'EMNS'
End

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2012 AND Code_Value_Key = 'ENFD' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2012, 'ENFD', 'Environmental (Federal)', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2012 AND Code_Value_Key = 'FCFD' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2012, 'FCFD', 'Facilities (Federal)', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2012 AND Code_Value_Key = 'TRFD' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2012, 'TRFD', 'Training (Federal)', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2012 AND Code_Value_Key = 'LGFD' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2012, 'LGFD', 'Logistics (Federal)', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2012 AND Code_Value_Key = 'AVFD' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2012, 'AVFD', 'Aviation (Federal)', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2012 AND Code_Value_Key = 'FSFD' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2012, 'FSFD', 'Force Structure (Federal)', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2012 AND Code_Value_Key = 'NFED' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2012, 'NFED', 'Non-Federal', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2012 AND Code_Value_Key = 'OFED' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2012, 'OFED', 'Other Federal Funding', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2007 AND Code_Value_Key = 'ACTV' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2007, 'ACTV', 'Active', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2007 AND Code_Value_Key = 'CMPL' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2007, 'CMPL', 'Completed', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2007 AND Code_Value_Key = 'DISC' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2007, 'DISC', 'Discontinued', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2008 AND Code_Value_Key = 'CONV' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2008, 'CONV', 'Conversion', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2008 AND Code_Value_Key = 'STEP' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2008, 'STEP', 'STEP', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2009 AND Code_Value_Key = 'MANU' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2009, 'MANU', 'Manual', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2009 AND Code_Value_Key = 'APPR' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2009, 'APPR', 'Approval', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

/* ============= Code Value Data Insertion  For Project Approval Status ==============*/
IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2010 AND Code_Value_Key = 'PRCR' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2010, 'PRCR', 'Pending Submission', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2010 AND Code_Value_Key = 'SIAA' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2010, 'SIAA', 'Submitted for Installation Admin Approval', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2010 AND Code_Value_Key = 'IAAP' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2010, 'IAAP', 'Installation Admin Approved', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2010 AND Code_Value_Key = 'IADA' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2010, 'IADA', 'Installation Admin Disapproved', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2010 AND Code_Value_Key = 'SMAA' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2010, 'SMAA', 'Submitted for MSC Admin Approval', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2010 AND Code_Value_Key = 'MAAR' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2010, 'MAAR', 'MSC Admin Approved', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2010 AND Code_Value_Key = 'MADA' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2010, 'MADA', 'MSC Admin Disapproved', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2010 AND Code_Value_Key = 'SHAP' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2010, 'SHAP', 'Submitted for HQ Approval', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2010 AND Code_Value_Key = 'FELI' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2010, 'FELI', 'Funding Eligible', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2010 AND Code_Value_Key = 'FINE' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2010, 'FINE', 'Funding Ineligible', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

-- Configuration For Class Data
IF Not Exists (Select 1 from Code_Value where Code_ID = 2011 and Code_Value_Key = '0' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (2011, '0','0',NULL,NULL,NULL,1, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 2011 and Code_Value_Key = '1' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (2011, '1','1',NULL,NULL,NULL,2, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 2011 and Code_Value_Key = '2' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (2011, '2','2',NULL,NULL,NULL,3, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

IF Not Exists (Select 1 from Code_Value where   Code_ID = 2011 and Code_Value_Key = '3' )  
Begin
	Insert Code_Value (Code_Id, Code_Value_Key, Code_Value_Description,Data1,Data2,Data3,SequenceNumber, Created_By, Created_Date, Modified_By,Modified_Date)  
	values  (2011, '3','3',NULL,NULL,NULL,4, @Created_By,GETDATE(), @Modified_By,GETDATE()) 
End

-- Approval Note Code Value Data
--IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2013 AND Code_Value_Key = 'MANU' )  
--BEGIN
--	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
--	VALUES  (2013, 'MANU', 'Manual', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
--END

--IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2013 AND Code_Value_Key = 'APAL' )  
--BEGIN
--	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
--	VALUES  (2013, 'APAL', 'Approval', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
--END

-- Change Type Code Value Data
IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2014 AND Code_Value_Key = 'INST' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2014, 'INST', 'Insert', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2014 AND Code_Value_Key = 'UPDT' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2014, 'UPDT', 'Update', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2014 AND Code_Value_Key = 'DELT' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2014, 'DELT', 'Delete', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

/* ============= Code Value Data Insertion  For Project Approval Action ==============*/
IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2015 AND Code_Value_Key = 'SUBT' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2015, 'SUBT', 'Submit For Approval', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2015 AND Code_Value_Key = 'APPR' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2015, 'APPR', 'Approve', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2015 AND Code_Value_Key = 'DAPP' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2015, 'DAPP', 'Disapprove ', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END 

/* ============= Code Value Data Insertion  For Approval Process Email Configuration ==============*/
IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2016 AND Code_Value_Key = 'CURT' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2016, 'CURT', 'Current', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2016 AND Code_Value_Key = 'FLPT' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2016, 'FLPT', 'First Level Parent', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2016 AND Code_Value_Key = 'SLPT' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2016, 'SLPT', 'Second Level Parent', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

/* ============= Code Value Data Insertion  For Approval Process Email Configuration ==============*/

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2018 AND Code_Value_Key = 'MVC' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2018, 'MVC', 'MVC', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2018 AND Code_Value_Key = 'MENU' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2018, 'MENU', 'MENU', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2018 AND Code_Value_Key = 'RLST' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2018, 'RLST', 'Report List', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2018 AND Code_Value_Key = 'UI' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2018, 'UI', 'UI', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END
IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2018 AND Code_Value_Key = 'RLGP' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2018, 'RLGP', 'Role Group', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

-- MDEP Code Value Data
IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2019 AND Code_Value_Key = 'VENQ' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2019, 'VENQ', 'VENQ', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2019 AND Code_Value_Key = 'AWCF' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2019, 'AWCF', 'Army Working Capital Fund', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2019 AND Code_Value_Key = 'CM' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2019, 'CM', 'Chemical Mission', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2019 AND Code_Value_Key = 'PA' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2019, 'PA ', 'Procurement Army', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2019 AND Code_Value_Key = 'TWCF' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2019, 'TWCF', 'Transportation Working Capital Fund', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2019 AND Code_Value_Key = 'OMA' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2019, 'OMA', 'Operations, Maintenance, Army', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

 
--Code id for admin security 
IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 100 AND Code_Value_Key = 'ASCD' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (100, 'ASCD', 'P1@T', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END
--Code id for Top 250 records 
IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 100 AND Code_Value_Key = 'TRCT' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (100, 'TRCT', 'Number of Records', 250, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 100 AND Code_Value_Key = 'TOTC' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (100, 'TOTC', 'Total Number of Records Turn On/Off', 'True', NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 100 AND Code_Value_Key = 'AMC' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (100, 'AMC', 'Client Is AMC', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

If Exists (Select 1 from Code_Value where Code_ID = 100 and Code_Value_Key = 'AMC')  
Begin
	 Update Code_Value Set Code_Value_Key='AGNY',Code_Value_Description='Name Of Agency',Data1='AMC' Where Code_ID = 100 and Code_Value_Key = 'AMC'
End 

If Exists (Select 1 from Code_Value where Code_ID = 100 and Code_Value_Key = 'EMNS')  
Begin
	 Update Code_Value Set Code_Value_Description='Email Notification Signature',Data1='Content' 
	 Where Code_ID = 100 and Code_Value_Key = 'EMNS'
End 

If Exists (Select 1 from Code_Value where Code_ID = 100 and Code_Value_Key = 'ASCD')  
Begin
	 Update Code_Value Set Code_Value_Description='Admin Security Code',Data1='P1@T' 
	 Where Code_ID = 100 and Code_Value_Key = 'ASCD'
End

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2020 AND Code_Value_Key = 'ITML' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2020, 'ITML', 'Low', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2020 AND Code_Value_Key = 'ITMM' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2020, 'ITMM', 'Medium', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2020 AND Code_Value_Key = 'ITMH' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2020, 'ITMH', 'High', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2021 AND Code_Value_Key = 'MIC1' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2021, 'MIC1', 'Mission Code 1', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2021 AND Code_Value_Key = 'MIC2' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2021, 'MIC2', 'Mission Code 2', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2022 AND Code_Value_Key = 'EILW' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2022, 'EILW', '1', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2022 AND Code_Value_Key = 'EIME' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2022, 'EIME', '2', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2022 AND Code_Value_Key = 'EIHG' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2022, 'EIHG', '3', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2023 AND Code_Value_Key = 'PNFU' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2023, 'PNFU', 'Project Number Formatting', '_', NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2024 AND Code_Value_Key = 'UNFU' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2024, 'UNFU', 'Unfunded', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2024 AND Code_Value_Key = 'FUND' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2024, 'FUND', 'Funded', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Code_Value WHERE Code_ID = 2024 AND Code_Value_Key = 'OBLI' )  
BEGIN
	INSERT Code_Value (Code_Id, Code_Value_Key, Code_Value_Description, Data1, Data2, Data3, SequenceNumber, Created_By, Created_Date, Modified_By, Modified_Date)  
	VALUES  (2024, 'OBLI', 'Obligated', NULL, NULL, NULL, NULL, @Created_By, GETDATE(), @Modified_By, GETDATE()) 
END
---========================= Fiscal Year ================================

IF NOT EXISTS (SELECT 1 FROM Fiscal_Year WHERE FY = 2013 )  
BEGIN
	INSERT INTO [Fiscal_Year] ([FY],[FY_Start_Date],[FY_End_Date],
	[CurrentYear_Start_Date],[CurrentYear_End_Date],
	[Programmed_Start_Date],[Programmed_End_Date],
	[Planning_Start_Date],[Planning_End_Date],
	[Funding_Start_Date],[Funding_End_Date],
	[Obligation_Start_Date],[Obligation_End_Date] ,
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
     VALUES (2013,	'10/1/2012','9/30/2013',
					'1/1/2012','12/31/2012',	-- Current Year Start Date & End Date
					'1/1/2012','12/31/2012',    -- Fund Period - Programmed  
					'5/1/2012','6/30/2012',		-- Fund Period - Planning (ESOB Period)
					'7/1/2012','8/31/2012',		-- Fund Period - Funding 
					'9/1/2012','10/31/2012',	-- Fund Period - Obligation	 	 
					@Created_By,GETDATE(), @Modified_By,GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Fiscal_Year WHERE FY = 2014 )  
BEGIN
	INSERT INTO [Fiscal_Year] ([FY],[FY_Start_Date],[FY_End_Date],
	[CurrentYear_Start_Date],[CurrentYear_End_Date],
	[Programmed_Start_Date],[Programmed_End_Date],
	[Planning_Start_Date],[Planning_End_Date],
	[Funding_Start_Date],[Funding_End_Date],
	[Obligation_Start_Date],[Obligation_End_Date] ,
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
     VALUES (2014,	'10/1/2013','9/30/2014',
					'1/1/2013','12/31/2013',	-- Current Year Start Date & End Date
					'1/1/2013','12/31/2013',    -- Fund Period - Programmed  
					'5/1/2013','6/30/2013',		-- Fund Period - Planning (ESOB Period)
					'7/1/2013','8/31/2013',		-- Fund Period - Funding 
					'9/1/2013','10/31/2013',	-- Fund Period - Obligation	 	 
					@Created_By,GETDATE(), @Modified_By,GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Fiscal_Year WHERE FY = 2015)  
BEGIN
	INSERT INTO [Fiscal_Year] ([FY],[FY_Start_Date],[FY_End_Date],
	[CurrentYear_Start_Date],[CurrentYear_End_Date],
	[Programmed_Start_Date],[Programmed_End_Date],
	[Planning_Start_Date],[Planning_End_Date],
	[Funding_Start_Date],[Funding_End_Date],
	[Obligation_Start_Date],[Obligation_End_Date] ,
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
     VALUES (2015,	'10/1/2014','9/30/2015',
					'1/1/2014','12/31/2014',	-- Current Year Start Date & End Date
					'1/1/2014','12/31/2014',    -- Fund Period - Programmed  
					'5/1/2014','6/30/2014',		-- Fund Period - Planning (ESOB Period)
					'7/1/2014','8/31/2014',		-- Fund Period - Funding 
					'9/1/2014','10/31/2014',	-- Fund Period - Obligation	 	 
					@Created_By,GETDATE(), @Modified_By,GETDATE())  
END

IF NOT EXISTS (SELECT 1 FROM Fiscal_Year WHERE FY = 2016 )  
BEGIN
	INSERT INTO [Fiscal_Year] ([FY],[FY_Start_Date],[FY_End_Date],
	[CurrentYear_Start_Date],[CurrentYear_End_Date],
	[Programmed_Start_Date],[Programmed_End_Date],
	[Planning_Start_Date],[Planning_End_Date],
	[Funding_Start_Date],[Funding_End_Date],
	[Obligation_Start_Date],[Obligation_End_Date] ,
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
     VALUES (2016,	'10/1/2015','9/30/2016',
					'1/1/2015','12/31/2015',	-- Current Year Start Date & End Date
					'1/1/2015','12/31/2015',    -- Fund Period - Programmed  
					'5/1/2015','6/30/2015',		-- Fund Period - Planning (ESOB Period)
					'7/1/2015','8/31/2015',		-- Fund Period - Funding 
					'9/1/2015','10/31/2015',	-- Fund Period - Obligation	 	 
					@Created_By,GETDATE(), @Modified_By,GETDATE()) 
END

IF NOT EXISTS (SELECT 1 FROM Fiscal_Year WHERE FY = 2017 )  
BEGIN
	INSERT INTO [Fiscal_Year] ([FY],[FY_Start_Date],[FY_End_Date],
	[CurrentYear_Start_Date],[CurrentYear_End_Date],
	[Programmed_Start_Date],[Programmed_End_Date],
	[Planning_Start_Date],[Planning_End_Date],
	[Funding_Start_Date],[Funding_End_Date],
	[Obligation_Start_Date],[Obligation_End_Date] ,
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
     VALUES (2017,	'10/1/2016','9/30/2017',
					'1/1/2016','12/31/2016',	-- Current Year Start Date & End Date
					'1/1/2016','12/31/2018',    -- Fund Period - Programmed  
					'5/1/2016','6/30/2018',		-- Fund Period - Planning (ESOB Period)
					'7/1/2016','8/31/2018',		-- Fund Period - Funding 
					'9/1/2016','10/31/2018',	-- Fund Period - Obligation	 
					@Created_By,GETDATE(), @Modified_By,GETDATE()) 
END
 
IF NOT EXISTS (SELECT 1 FROM Fiscal_Year WHERE FY = 2018 )  
BEGIN
	INSERT INTO [Fiscal_Year] ([FY],[FY_Start_Date],[FY_End_Date],
	[CurrentYear_Start_Date],[CurrentYear_End_Date],
	[Programmed_Start_Date],[Programmed_End_Date],
	[Planning_Start_Date],[Planning_End_Date],
	[Funding_Start_Date],[Funding_End_Date],
	[Obligation_Start_Date],[Obligation_End_Date] ,
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
     VALUES (2018,	'10/1/2017','9/30/2018',
					'1/1/2017','12/31/2017',	-- Current Year Start Date & End Date
					'1/1/2017','12/31/2017',    -- Fund Period - Programmed  
					'5/1/2017','6/30/2017',		-- Fund Period - Planning (ESOB Period)
					'7/1/2017','8/31/2017',		-- Fund Period - Funding 
					'9/1/2017','10/31/2017',	-- Fund Period - Obligation	 	 
					@Created_By,GETDATE(), @Modified_By,GETDATE()) 
END
 
IF NOT EXISTS (SELECT 1 FROM Fiscal_Year WHERE FY = 2019 )  
BEGIN
	INSERT INTO [Fiscal_Year] ([FY],[FY_Start_Date],[FY_End_Date],
	[CurrentYear_Start_Date],[CurrentYear_End_Date],
	[Programmed_Start_Date],[Programmed_End_Date],
	[Planning_Start_Date],[Planning_End_Date],
	[Funding_Start_Date],[Funding_End_Date],
	[Obligation_Start_Date],[Obligation_End_Date] ,
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
     VALUES (2019,	'10/1/2018','9/30/2019',
					'1/1/2018','12/31/2018',	-- Current Year Start Date & End Date
					'1/1/2018','12/31/2018',    -- Fund Period - Programmed  
					'5/1/2018','6/30/2018',		-- Fund Period - Planning (ESOB Period)
					'7/1/2018','8/31/2018',		-- Fund Period - Funding 
					'9/1/2018','10/31/2018',	-- Fund Period - Obligation	 	 
					@Created_By,GETDATE(), @Modified_By,GETDATE())  
END

IF NOT EXISTS (SELECT 1 FROM Fiscal_Year WHERE FY = 2020 )  
BEGIN
	INSERT INTO [Fiscal_Year] ([FY],[FY_Start_Date],[FY_End_Date],
	[CurrentYear_Start_Date],[CurrentYear_End_Date],
	[Programmed_Start_Date],[Programmed_End_Date],
	[Planning_Start_Date],[Planning_End_Date],
	[Funding_Start_Date],[Funding_End_Date],
	[Obligation_Start_Date],[Obligation_End_Date] ,
	[Created_By],[Created_Date],[Modified_By],[Modified_Date])
     VALUES (2020,	'10/1/2019','9/30/2020',
					'1/1/2019','12/31/2019',	-- Current Year Start Date & End Date
					'1/1/2019','12/31/2019',    -- Fund Period - Programmed  
					'5/1/2019','6/30/2019',		-- Fund Period - Planning (ESOB Period)
					'7/1/2019','8/31/2019',		-- Fund Period - Funding 
					'9/1/2019','10/31/2019',	-- Fund Period - Obligation	 	 
					@Created_By,GETDATE(), @Modified_By,GETDATE()) 
END


  
 
/* Removed "Role Group" Code from code and code_value table */
IF Exists (Select 1 from Code_value where code_Id = 2017)  
Begin
	delete from Code_value where code_Id=2017
	print 'Role Group related entry removed from Code_value table'  
end

IF Exists (Select 1 from Code where Id = 2017)  
Begin
	delete from code where id=2017
	print 'Role Group removed from code table'  
end

/* Removed "Mission Code" Code from code and code_value table */
IF Exists (Select 1 from Code_value where code_Id = 2021)  
Begin
	delete from Code_value where code_Id=2021
	print 'Mission Code related entry removed from Code_value table'  
end

IF Exists (Select 1 from Code where Id = 2021)  
Begin
	delete from code where id=2021
	print 'Mission Code removed from code table'  
end


----IF Exists (Select 1 from Code_value where code_Id = 2012)  
----Begin
----	delete from Code_value where code_Id=2012
----	print 'Resource Sponsor related entry removed from Code_value table'  
----end

----IF Exists (Select 1 from Code where Id = 2012)  
----Begin
----	delete from code where id=2012
----	print 'Resource Sponsor removed from code table'  
----end

-- Update  Code Id 2020 -- Impact Mission Description
IF Exists (Select 1 from Code_Value where Code_ID = 2020 and Code_Value_Key = 'ITML' And Code_Value_Description='Low')  
BEGIN
	Update Code_Value Set Code_Value_Description='1' Where Code_ID = 2020 and Code_Value_Key = 'ITML'
END
IF Exists (Select 1 from Code_Value where Code_ID = 2020 and Code_Value_Key = 'ITMM' And Code_Value_Description='Medium')  
BEGIN
	Update Code_Value Set Code_Value_Description='2' Where Code_ID = 2020 and Code_Value_Key = 'ITMM'
END
IF Exists (Select 1 from Code_Value where Code_ID = 2020 and Code_Value_Key = 'ITMH' And Code_Value_Description='High')  
BEGIN
	Update Code_Value Set Code_Value_Description='3' Where Code_ID = 2020 and Code_Value_Key = 'ITMH'
END
GO


-- Update Data 1 Value for Code Id 2011 - Class
If Exists (Select 1 from Code_Value where Code_ID = 2011 and Code_Value_Key = '0' And Data1 Is Null )  
BEGIN
	Update Code_Value Set Data1='Requirements necessary to manage the program.'
	,SequenceNumber=1 Where Code_ID = 2011 and Code_Value_Key = '0'
END

If Exists (Select 1 from Code_Value where Code_ID = 2011 and Code_Value_Key = '1' And Data1 Is Null )  
BEGIN
	Update Code_Value Set Data1='Environmental compliance required to correct existing violations
especially those identified in Notices of Violation or Compliance
Agreements.',
	SequenceNumber=2 Where Code_ID = 2011 and Code_Value_Key = '1'
END

If Exists (Select 1 from Code_Value where Code_ID = 2011 and Code_Value_Key = '2' And Data1 Is Null )  
BEGIN
	Update Code_Value Set Data1='Activities, studies, surveys etc., to correct environmental
situations to meet a known regulatory deadline in the immediate (1-5 years)
future.',SequenceNumber=3 Where Code_ID = 2011 and Code_Value_Key = '2'
END

If Exists (Select 1 from Code_Value where Code_ID = 2011 and Code_Value_Key = '3' And Data1 Is Null )  
BEGIN
	Update Code_Value Set Data1='Activity where compliance is not an issue, but demonstrates
environmental leadership.',
	SequenceNumber=4 Where Code_ID = 2011 and Code_Value_Key = '3'
END

-- Update Data 1 Value for Code Id 2020 - Mission Impact
If Exists (Select 1 from Code_Value where Code_ID = 2020 and Code_Value_Key = 'ITML' And Data1 Is Null )  
BEGIN
	Update Code_Value Set Data1='Minor mission impacts or restrictions.',SequenceNumber=1 
	Where Code_ID = 2020 and Code_Value_Key = 'ITML'
END

If Exists (Select 1 from Code_Value where Code_ID = 2020 and Code_Value_Key = 'ITMM' And Data1 Is Null )  
BEGIN
	Update Code_Value Set Data1='Moderate mission restrictions.',SequenceNumber=2 
	Where Code_ID = 2020 and Code_Value_Key = 'ITMM'
END

If Exists (Select 1 from Code_Value where Code_ID = 2020 and Code_Value_Key = 'ITMH' And Data1 Is Null )  
BEGIN
	Update Code_Value Set Data1='Loss of ability to accomplish critical mission or near mission failure.'
	,SequenceNumber=3 Where Code_ID = 2020 and Code_Value_Key = 'ITMH'
END

-- Update Data 1 Value for Code Id 2022 - Environmental Impact
If Exists (Select 1 from Code_Value where Code_ID = 2022 and Code_Value_Key = 'EILW' And Data1 Is Null )  
BEGIN
	Update Code_Value Set Data1='Insignificant-trivial consequences, easily correctable or not impact.',SequenceNumber=1 Where Code_ID = 2022 and Code_Value_Key = 'EILW'
END

If Exists (Select 1 from Code_Value where Code_ID = 2022 and Code_Value_Key = 'EIME' And Data1 Is Null )  
BEGIN
	Update Code_Value Set Data1='Moderate-somewhat harmful, but correctable.',SequenceNumber=2 Where Code_ID = 2022 and Code_Value_Key = 'EIME'
END

If Exists (Select 1 from Code_Value where Code_ID = 2022 and Code_Value_Key = 'EIHG' And Data1 Is Null )  
BEGIN
	Update Code_Value Set Data1='Severe-immediate threat likely to result in widespread damage to human
health or the environment and requiring great effort to remediate or
correct.',SequenceNumber=3 Where Code_ID = 2022 and Code_Value_Key = 'EIHG'
END

-- Update Data 1 Value for Code Id 2020 - Mission Impact
If Exists (Select 1 from Code_Value where Code_ID = 2020 and Code_Value_Key = 'ITML' And  SequenceNumber=1 )  
BEGIN
	Update Code_Value Set SequenceNumber=3 	Where Code_ID = 2020 and Code_Value_Key = 'ITML'
END
 
If Exists (Select 1 from Code_Value where Code_ID = 2020 and Code_Value_Key = 'ITMH' And  SequenceNumber=3 )  
BEGIN
	Update Code_Value Set Data1='Loss of ability to accomplish critical mission or near mission failure.'
	,SequenceNumber=1 Where Code_ID = 2020 and Code_Value_Key = 'ITMH'
END

-- Update Data 1 Value for Code Id 2022 - Environmental Impact
If Exists (Select 1 from Code_Value where Code_ID = 2022 and Code_Value_Key = 'EILW' And SequenceNumber=1 )  
BEGIN
	Update Code_Value Set SequenceNumber=3 Where Code_ID = 2022 and Code_Value_Key = 'EILW'
END
 
If Exists (Select 1 from Code_Value where Code_ID = 2022 and Code_Value_Key = 'EIHG' And SequenceNumber=3 )  
BEGIN
	Update Code_Value Set SequenceNumber=1 Where Code_ID = 2022 and Code_Value_Key = 'EIHG'
END

-- Update  Code Id 2020 -- Impact Mission Description
If Exists (Select 1 from Code_Value where Code_ID = 2020 and Code_Value_Key = 'ITML' And Code_Value_Description = '1' )  
BEGIN
	Update Code_Value Set Code_Value_Description='1 - Minor' Where Code_ID = 2020 and Code_Value_Key = 'ITML' And Code_Value_Description = '1'
END
If Exists (Select 1 from Code_Value where Code_ID = 2020 and Code_Value_Key = 'ITMM' And Code_Value_Description = '2' )  
BEGIN
	Update Code_Value Set Code_Value_Description='2 - Moderate' Where Code_ID = 2020 and Code_Value_Key = 'ITMM' And Code_Value_Description = '2'
END
If Exists (Select 1 from Code_Value where Code_ID = 2020 and Code_Value_Key = 'ITMH' And Code_Value_Description = '3' )  
BEGIN
	Update Code_Value Set Code_Value_Description='3 - Critical' Where Code_ID = 2020 and Code_Value_Key = 'ITMH' And Code_Value_Description = '3'
END


-- Update  Code Id 2022 -- Environmental Impact Description
If Exists (Select 1 from Code_Value where Code_ID = 2022 and Code_Value_Key = 'EILW' And Code_Value_Description = '1' )  
BEGIN
	Update Code_Value Set Code_Value_Description='1 - Insignificant' Where Code_ID = 2022 and Code_Value_Key = 'EILW' And Code_Value_Description = '1'
END
If Exists (Select 1 from Code_Value where Code_ID = 2022 and Code_Value_Key = 'EIME' And Code_Value_Description = '2' )  
BEGIN
	Update Code_Value Set Code_Value_Description='2 - Moderate' Where Code_ID = 2022 and Code_Value_Key = 'EIME' And Code_Value_Description = '2'
END
If Exists (Select 1 from Code_Value where Code_ID = 2022 and Code_Value_Key = 'EIHG' And Code_Value_Description = '3' )  
BEGIN
	Update Code_Value Set Code_Value_Description='3 - Severe' Where Code_ID = 2022 and Code_Value_Key = 'EIHG' And Code_Value_Description = '3'
END
GO





 


