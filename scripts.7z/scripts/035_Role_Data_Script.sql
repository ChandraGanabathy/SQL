GO
Declare @CreatedBy Varchar(50)
Declare @CreatedDate DateTime
Set @CreatedBy ='Plateauinc'
Set @CreatedDate=GETDATE()
--Select * From Role
-- Delete From Role
IF Not Exists (Select 1 from [Role] Where Id=1 And Role_Key = 'WEBADMN' And Name='Web Administrator'  ) 
Begin
	INSERT [dbo].[Role] ([Id], [Role_Key], [Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
	VALUES
	(1, 'WEBADMN','Web Administrator',1200,'HQ',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from [Role] Where Id=2 And Role_Key = 'HQADMN' And Name='HQ Administrator'  ) 
Begin
	INSERT [dbo].[Role] ([Id], [Role_Key], [Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
	VALUES
	(2, 'HQADMN','HQ Administrator',1200,'HQ',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from [Role] Where Id=3 And Role_Key = 'HQUSER' And Name='HQ User'  ) 
Begin
	INSERT [dbo].[Role] ([Id], [Role_Key], [Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
	VALUES
	(3, 'HQUSER','HQ User',1200,'HQ',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from [Role] Where Id=4 And Role_Key = 'HQREAD' And Name='HQ Read Only User'  ) 
Begin
	INSERT [dbo].[Role] ([Id], [Role_Key], [Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
	VALUES
	(4, 'HQREAD','HQ Read Only User',1200,'HQ',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from [Role] Where Id=5 And Role_Key = 'MSCADMN' And Name='MSC Administrator'  ) 
Begin
	INSERT [dbo].[Role] ([Id], [Role_Key], [Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
	VALUES
	(5, 'MSCADMN','MSC Administrator',1200,'MSC',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from [Role] Where Id=6 And Role_Key = 'MSCUSER' And Name='MSC User'  ) 
Begin
	INSERT [dbo].[Role] ([Id], [Role_Key], [Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
	VALUES
	(6, 'MSCUSER','MSC User',1200,'MSC',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from [Role] Where Id=7 And Role_Key = 'MSCREAD' And Name='MSC Read Only User'  ) 
Begin
	INSERT [dbo].[Role] ([Id], [Role_Key], [Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
	VALUES
	(7, 'MSCREAD','MSC Read Only User',1200,'MSC',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from [Role] Where Id=8 And Role_Key = 'INSTADMN' And Name='Installation Administrator'  ) 
Begin
	INSERT [dbo].[Role] ([Id], [Role_Key], [Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
	VALUES
	(8, 'INSTADMN','Installation Administrator',1200,'INST',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from [Role] Where Id=9 And Role_Key = 'INSTUSER' And Name='Installation  User'  ) 
Begin
	INSERT [dbo].[Role] ([Id], [Role_Key], [Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
	VALUES
	(9, 'INSTUSER','Installation  User',1200,'INST',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from [Role] Where Id=10 And Role_Key = 'INSTREAD' And Name='Installation  Read Only User'  ) 
Begin
	INSERT [dbo].[Role] ([Id], [Role_Key], [Name],[Hierarchy_Level_Id],[Hierarchy_Level_Key], [Created_By], [Created_Date], [Modified_By], [Modified_Date])
	VALUES
	(10, 'INSTREAD','Installation  Read Only User',1200,'INST',@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

GO
Declare @CreatedBy Varchar(50)
Declare @CreatedDate DateTime
Set @CreatedBy ='Plateauinc'
Set @CreatedDate=GETDATE()
 
 -- Web Administrator Mapping
IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=1 And Parent_Role_Id =1 And Child_Role_Id=2  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(1,1,2,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=2 And Parent_Role_Id =1 And Child_Role_Id=3  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(2,1,3,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=3 And Parent_Role_Id =1 And Child_Role_Id=4) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(3,1,4,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=4 And Parent_Role_Id =1 And Child_Role_Id= 5 ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(4,1,5,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=5 And Parent_Role_Id =1 And Child_Role_Id= 6 ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(5,1,6,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=6 And Parent_Role_Id =1 And Child_Role_Id=7  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(6,1,7,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=7 And Parent_Role_Id =1 And Child_Role_Id=8  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(7,1,8,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End


IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=8 And Parent_Role_Id =1 And Child_Role_Id= 9 ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(8,1,9,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=9 And Parent_Role_Id =1 And Child_Role_Id=10  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(9,1,10,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End
-- HQ Admin Mapping
IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=10 And Parent_Role_Id =2 And Child_Role_Id=3  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(10,2,3,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=11 And Parent_Role_Id =2 And Child_Role_Id=4  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(11,2,4,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=12 And Parent_Role_Id =2 And Child_Role_Id=5  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(12,2,5,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=13 And Parent_Role_Id =2 And Child_Role_Id=6  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(13,2,6,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=14 And Parent_Role_Id =2 And Child_Role_Id=7  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(14,2,7,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=15 And Parent_Role_Id =2 And Child_Role_Id=8  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(15,2,8,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=16 And Parent_Role_Id =2 And Child_Role_Id=9  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(16,2,9,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=17 And Parent_Role_Id =2 And Child_Role_Id=10  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(17,2,10,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End
-- MSC Admin Mapping
IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=18 And Parent_Role_Id =5 And Child_Role_Id=6  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(18,5,6,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=19 And Parent_Role_Id =5 And Child_Role_Id=7  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(19,5,7,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=20 And Parent_Role_Id =5 And Child_Role_Id=8  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(20,5,8,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=21 And Parent_Role_Id =5 And Child_Role_Id=9  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(21,5,9,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=22 And Parent_Role_Id =5 And Child_Role_Id=10  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(22,5,10,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End


-- Installation Admin Mapping
IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=23 And Parent_Role_Id =8 And Child_Role_Id= 9 ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(23,8,9,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End

IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=24 And Parent_Role_Id =8 And Child_Role_Id=10  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(24,8,10,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End
-- Adding for HQ Admin should be able to invite other HQ admin
IF Not Exists (Select 1 from Role_Invitation_Mapping Where Id=25 And Parent_Role_Id =2 And Child_Role_Id=2  ) 
Begin
	INSERT INTO [Role_Invitation_Mapping](Id,[Parent_Role_Id],[Child_Role_Id],[Created_By] ,[Created_Date],[Modified_By],[Modified_Date])   
	VALUES
	(25,2,2,@CreatedBy,@CreatedDate,@CreatedBy,@CreatedDate)
End
