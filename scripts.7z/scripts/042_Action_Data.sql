Declare @Created_By varchar(100)
Declare @Modified_By varchar(100)

Select @Created_By = 'Plateauinc'
Select @Modified_By = 'Plateauinc'

/*Delete From [dbo].[Action]
Delete From [dbo].[Role_Action]*/	

--=========================== Home Controller =======================
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 1 And Controller_Name='Home' And Action_Name='DashBoard')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(1,'DashBoard','Home','Dashboard',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 2 And Controller_Name='Home' And Action_Name='Details')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(2,'Details','Home','Dashboard Details',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END
--=========================== User Managment Controller=======================
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 3 And Controller_Name='UserManagement' And Action_Name='InviteUser')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(3,'InviteUser','UserManagement','Invite a New User',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 4 And Controller_Name='UserManagement' And Action_Name='EditUser')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(4,'EditUser','UserManagement','Edit User',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 5 And Controller_Name='UserManagement' And Action_Name='UserInfo')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(5,'UserInfo','UserManagement','View User information',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 6 And Controller_Name='UserManagement' And Action_Name='UsersListing')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(6,'UsersListing','UserManagement','View User List and Delete a user',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END		
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 7 And Controller_Name='UserManagement' And Action_Name='UserPreference')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(7,'UserPreference','UserManagement','Set User Preference',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END
--=========================== Catelog Section ==========================
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 8 And Controller_Name='CatalogManagement' And Action_Name='ManageCatalog')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(8,'ManageCatalog','CatalogManagement','View all Catalog information',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 9 And Controller_Name='CatalogManagement' And Action_Name='AddCatalog')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(9,'AddCatalog','CatalogManagement','Add a new Catalog',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 10 And Controller_Name='CatalogManagement' And Action_Name='EditCatalog')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(10,'EditCatalog','CatalogManagement','Edit Catalog',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END			
--=========================== Project Section ==========================
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 11 And Controller_Name='ProjectManagement' And Action_Name='ProjectListing')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(11,'ProjectListing','ProjectManagement','View all Projects',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 12 And Controller_Name='ProjectManagement' And Action_Name='AddProject')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(12,'AddProject','ProjectManagement','Add a new project',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 13 And Controller_Name='ProjectManagement' And Action_Name='EditProject')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(13,'EditProject','ProjectManagement','Edit project',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END	

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 14 And Controller_Name='ProjectManagement' And Action_Name='Prioritization')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(14,'Prioritization','ProjectManagement','View all project to prioritize',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END		
--=========================== Budgeting Section ==========================
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 15 And Controller_Name='Budgeting' And Action_Name='BudgetExecution')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(15,'BudgetExecution','Budgeting','project funding execution',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END
--=========================== Planning Section ==========================
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id =16 And Controller_Name='Planning' And Action_Name='PAFG')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(16,'PAFG','Planning','View all planning anual funding',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END		
--=========================== Utilities Section ==========================	 
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 17 And Controller_Name='Utilities' And Action_Name='EmailNotification')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(17,'EmailNotification','Utilities','Send Email Notification',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 18 And Controller_Name='Utilities' And Action_Name='FileManager')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(18,'FileManager','Utilities','View all the files to manage',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 19 And Controller_Name='Utilities' And Action_Name='FiscalYearListing')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(19,'FiscalYearListing','Utilities','View all the fiscal years',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 20 And Controller_Name='Utilities' And Action_Name='EditFiscal')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(20,'EditFiscal','Utilities','View the fiscal year details',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 21 And Controller_Name='Utilities' And Action_Name='ChangeProjectOwner')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(21,'ChangeProjectOwner','Utilities','Change the project owner',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 22 And Controller_Name='Utilities' And Action_Name='AdminQuery')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(22,'AdminQuery','Utilities','Help the user to select the records',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 23 And Controller_Name='Utilities' And Action_Name='Documents')  
Begin
	IF EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 23 And Controller_Name='Utilities' And Action_Name='UserManual')  
	Begin
		Update [dbo].[Action] Set Action_Name='Documents' WHERE Id = 23 And Controller_Name='Utilities' And Action_Name='UserManual'
	END	
	ELSE
	Begin
		INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
			VALUES(23,'Documents','Utilities','Documents',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
	END
END	
--=========================== Reports Section ==========================
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 24 And Controller_Name='Reports' And Action_Name='ReportsList')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(24,'ReportsList','Reports','View all the reports',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 25 And Controller_Name='Reports' And Action_Name='ReportParameters')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(25,'ReportParameters','Reports','Show the report parameters',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END	
--=========================== Help Section ==========================
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 26 And Controller_Name='Help' And Action_Name='Manuals')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(26,'Manuals','Help','User manual document',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END
--====================== Update Type_id and Type_key in action table Data  ====================
DECLARE @RoleTypeId INT
SET @RoleTypeId = (select id from code where Code_Description='Role Action')
--IF NOT EXISTS (SELECT * FROM Action WHERE Type_Key = 'MVC')
--BEGIN
--	update Action set [Type_Id] = @RoleTypeId ,Type_Key ='MVC' where id between 1 and 20 
--END
--====================== Menu section  ====================
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 27 And Controller_Name='Menu' And Action_Name='User')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(27,'User','Menu','User Menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'MENU')
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 28 And Controller_Name='Menu' And Action_Name='Catalog')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(28,'Catalog','Menu','Catalog Menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'MENU')
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 29 And Controller_Name='Menu' And Action_Name='Project')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(29,'Project','Menu','Project Menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'MENU')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 30 And Controller_Name='Menu' And Action_Name='Budgeting')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(30,'Budgeting','Menu','Budgeting Menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'MENU')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 31 And Controller_Name='Menu' And Action_Name='Planning')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(31,'Planning','Menu','Planning Menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'MENU')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 32 And Controller_Name='Menu' And Action_Name='Utilities')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(32,'Utilities','Menu','Utilities Menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'MENU')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 33 And Controller_Name='Menu' And Action_Name='Reports')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(33,'Reports','Menu','Reports Menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'MENU')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 34 And Controller_Name='Menu' And Action_Name='Help')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(34,'Help','Menu','Help Menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'MENU')
END		 
--====================== Report list ====================
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 35 And Controller_Name='ReportsList' And Action_Name='RoleAction')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(35,'RoleAction','ReportsList','Role Action',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'RLST')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 36 And Controller_Name='ReportsList' And Action_Name='User')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(36,'User','ReportsList','User',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'RLST')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 37 And Controller_Name='ReportsList' And Action_Name='CatalogSummary')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(37,'CatalogSummary','ReportsList','Catalog Summary',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'RLST')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 38 And Controller_Name='ReportsList' And Action_Name='CatalogDetail')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(38,'CatalogDetail','ReportsList','Catalog Detail',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'RLST')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 39 And Controller_Name='ReportsList' And Action_Name='ProjectSummary')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(39,'ProjectSummary','ReportsList','Project Summary',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'RLST')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 40 And Controller_Name='ReportsList' And Action_Name='ProjectDetail')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(40,'ProjectDetail','ReportsList','Project Detail',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'RLST')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 41 And Controller_Name='ReportsList' And Action_Name='FSbyMLawReg')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(41,'FSbyMLawReg','ReportsList','Funding Summary by Media Law Reg',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'RLST')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 42 And Controller_Name='ReportsList' And Action_Name='FSbyPB28')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(42,'FSbyPB28','ReportsList','Funding Summary by PB28',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'RLST')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 43 And Controller_Name='ReportsList' And Action_Name='CatalogUsage')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(43,'CatalogUsage','ReportsList','Catalog Usage',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'RLST')
END	

							 
----====================== Role Group ====================
--IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 44 And Controller_Name='RoleGroup' And Action_Name='ADMN')  
--Begin
--	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
--		VALUES(44,'ADMN','RoleGroup','Admin',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'RLGP')
--END

--IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 45 And Controller_Name='RoleGroup' And Action_Name='READ')  
--Begin
--	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
--		VALUES(45,'READ','RoleGroup','Read Only',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'RLGP')
--END

--IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 46 And Controller_Name='RoleGroup' And Action_Name='WRITE')  
--Begin
--	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
--		VALUES(46,'WRITE','RoleGroup','Write',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'RLGP')
--END
--====================== UI section  ====================
--Priorities action script
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 44 And Controller_Name='Priority' And Action_Name='EditlocalPriority')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(44,'EditlocalPriority','Priority','Edit access to local Priority',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'UI')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 45 And Controller_Name='Priority' And Action_Name='EditMSCPriority')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(45,'EditMSCPriority','Priority','Edit access to MSC Priority',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'UI')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 46 And Controller_Name='Priority' And Action_Name='EditHQPriority')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(46,'EditHQPriority','Priority','Edit access to HQ Priority',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'UI')

END		
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 47 And Controller_Name='PAFG' And Action_Name='btnAllocate')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(47,'btnAllocate','PAFG','Allocation action in PAFG menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'UI')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 48 And Controller_Name='PAFG' And Action_Name='btnAuthorize')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(48,'btnAuthorize','PAFG','Authroziation action in PAFG menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'UI')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 49 And Controller_Name='PAFG' And Action_Name='btnSave')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(49,'btnSave','PAFG','Save action in PAFG menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'UI')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 50 And Controller_Name='Catalog' And Action_Name='btnSave')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(50,'btnSave','Catalog','Save Authroziation action in Catalog menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'UI')
END	

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 51 And Controller_Name='AddEditProject' And Action_Name='btnSave')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(51,'btnSave','AddEditProject','Save action in AddProject menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'UI')
END	

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 52 And Controller_Name='AddEditProject' And Action_Name='btnUpdateProjectFunding')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(52,'btnUpdateProjectFunding','AddEditProject','Update Project funding action in AddProject menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'UI')
END	

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 53 And Controller_Name='AddEditProject' And Action_Name='btnUpdateProjectAnswer')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(53,'btnUpdateProjectAnswer','AddEditProject','Update Project Answer action in AddProject menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'UI')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 54 And Controller_Name='AddEditProject' And Action_Name='btnUpdateProjectNote')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(54,'btnUpdateProjectNote','AddEditProject','Update Project Note action in AddProject menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'UI')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 55 And Controller_Name='Priority' And Action_Name='btnSave')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(55,'btnSave','Priority','Save Project priorities in Prioritization menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'UI')
END	

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 56 And Controller_Name='FiscalYear' And Action_Name='btnSave')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(56,'btnSave','FiscalYear','Save Fiscal Year details in FiscalYearDetails menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'UI')
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 57 And Controller_Name='DashBoard' And Action_Name='tabApprovalProjects')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(57,'tabApprovalProjects','DashBoard','Show the Approval project tabs in DashBoard menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'UI')
END				

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 58 And Controller_Name='Utilities' And Action_Name='RoleAction')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(58,'RoleAction','Utilities','Configure Role With Action',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'MVC')
END	

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 59 And Controller_Name='DashBoard' And Action_Name='tabMyProjects')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(59,'tabMyProjects','DashBoard','Show the Approval project tabs in DashBoard menu',@Created_By,GetDate(),@Modified_By,GetDate(),@RoleTypeId,'UI')
END	
IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 60 And Controller_Name='AddEditProject' And Action_Name='divDropdownHierarchyData')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(60,'divDropdownHierarchyData','AddEditProject','Show Hierarch dropdown with list of property',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'UI')
END	

IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 61 And Controller_Name='AddEditProject' And Action_Name='divLabelHierarchyData')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(61,'divLabelHierarchyData','AddEditProject','Show Property Info with the label',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'UI')
END	

-- Entry for to show/hide Pillar LawReg Program Area tab section in user role popup in invite user screen
 IF NOT EXISTS (SELECT 1 FROM [dbo].[Action] WHERE Id = 62 And Controller_Name='InviteUserPage' And Action_Name='divLawRegProgramArea_InviteUserPage')  
Begin
	INSERT INTO [dbo].[Action]([Id],[Action_Name],[Controller_Name],[Action_Description],[Created_By],[Created_Date],[Modified_By],[Modified_Date],Type_Id,Type_Key)
		VALUES(62,'divLawRegProgramArea_InviteUserPage','InviteUserPage','Show/Hide Pillar-LawReg-Program Area tab section in user role popup in invite user screen',@Created_By,GetDate(),@Modified_By,GetDate(),2018,'UI')
END	