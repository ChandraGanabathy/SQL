Declare @User_Id int
Declare @User_Role_Id int
Declare @Created_Modified_User_Name varchar(100)
Select @Created_Modified_User_Name = 'QA Process'

delete from Audit_Details WHERE Audit_Id IN ( SELECT a.Id FROM Audit a 
												JOIN Project p ON a.Project_Id = p.Id
												WHERE p.Created_By = @Created_Modified_User_Name)
delete from Audit WHERE Project_Id IN (SELECT Id FROM Project WHERE Created_By = @Created_Modified_User_Name )
delete from Project_Note WHERE Project_Id IN (SELECT Id FROM Project WHERE Created_By = @Created_Modified_User_Name )
delete from Project_Document where Created_By = @Created_Modified_User_Name 
delete from Project_Answer where Created_By = @Created_Modified_User_Name 
Delete from Project_Funding where Created_By = @Created_Modified_User_Name 
Delete from Project where Created_By = @Created_Modified_User_Name 

Delete from Catalog where Created_By = @Created_Modified_User_Name 

-- Create the Project using User Id of 'Admin@PlateauInc.com'

Select @User_Id = Id from Users where Email_Id = 'HQ_Admin@amc.army.mil'
Select @User_Role_Id = Id from User_Role where User_Id = @User_Id

-- Insert into Project
-- Using the ROI column to store the random number, so i can use that value to populate funding records
-- Limiting the number of projects created
Insert into Project (Project_Name, Project_Number, Hierarchy_Data_Id, Catalog_Id, 
Class_Id, Class_Key, Owner_Id, Created_User_Role_Id, Project_Description, ROI,
Impact_to_Mission_Id,Impact_to_Mission_Key,Is_Recurring,Environmental_Impact_Code_Id,Environmental_Impact_Code_Key,
Created_By,Created_Date, Modified_By,Modified_Date )
Select top 100 left( convert(varchar,C.Id) + ' Project For ' + Name,100), left( HD.Code +'_'+ CV1.Data2 + RIGHT('0000'+CAST(C.Id AS VARCHAR(4)),4) ,100)
, HD.Id, C.Id, 2011,'0',@User_Id, @User_Role_Id, 'Project For ' + HD.Name + ' ' + C.Catalog_Name, ABS(CAST(NEWID() AS binary(6)) %1000) + 1 
,2020,'ITMH',0,2022,'EIHG'
,@Created_Modified_User_Name, GETDATE(),@Created_Modified_User_Name, GETDATE()
from Hierarchy_Data HD
Cross Join Catalog C 
Join Pillar_LawReg_Mapping PLM
	on (PLM.Id = C.Pillar_Lawreg_Mapping_Id)
Join Code_Value CV1 
	on (CV1.Code_ID = PLM.Pillar_Id and CV1.Code_Value_Key = PLM.Pillar_Key)
where PLM.Pillar_Key = 'CMP'

Insert into Project (Project_Name, Project_Number, Hierarchy_Data_Id, Catalog_Id, 
Class_Id, Class_Key, Owner_Id, Created_User_Role_Id, Project_Description, ROI,
Impact_to_Mission_Id,Impact_to_Mission_Key,Is_Recurring,Environmental_Impact_Code_Id,Environmental_Impact_Code_Key,
Created_By,Created_Date, Modified_By,Modified_Date )
Select top 100 left( convert(varchar,C.Id) + ' Project For ' + Name,100), left( HD.Code +'_'+ + CV1.Data2 + RIGHT('0000'+CAST(C.Id AS VARCHAR(4)),4) ,100)
, HD.Id, C.Id, 2011,'0',@User_Id, @User_Role_Id, 'Project For ' + HD.Name + ' ' + C.Catalog_Name, ABS(CAST(NEWID() AS binary(6)) %1000) + 1 
,2020,'ITMH',0,2022,'EIHG'
,@Created_Modified_User_Name, GETDATE(),@Created_Modified_User_Name, GETDATE()
from Hierarchy_Data HD
Cross Join Catalog C 
Join Pillar_LawReg_Mapping PLM
	on (PLM.Id = C.Pillar_Lawreg_Mapping_Id)
Join Code_Value CV1 
	on (CV1.Code_ID = PLM.Pillar_Id and CV1.Code_Value_Key = PLM.Pillar_Key)
where PLM.Pillar_Key = 'CNS'

Insert into Project (Project_Name, Project_Number, Hierarchy_Data_Id, Catalog_Id, 
Class_Id, Class_Key, Owner_Id, Created_User_Role_Id, Project_Description, ROI,
Impact_to_Mission_Id,Impact_to_Mission_Key,Is_Recurring,Environmental_Impact_Code_Id,Environmental_Impact_Code_Key,
Created_By,Created_Date, Modified_By,Modified_Date )
Select top 100 left( convert(varchar,C.Id) + ' Project For ' + Name,100), left( HD.Code +'_'+ CV1.Data2 + RIGHT('0000'+CAST(C.Id AS VARCHAR(4)),4) ,100)
, HD.Id, C.Id,  2011,'0',@User_Id, @User_Role_Id, 'Project For ' + HD.Name + ' ' + C.Catalog_Name, ABS(CAST(NEWID() AS binary(6)) %1000) + 1 
,2020,'ITMH',0,2022,'EIHG'
,@Created_Modified_User_Name, GETDATE(),@Created_Modified_User_Name, GETDATE()
from Hierarchy_Data HD
Cross Join Catalog C 
Join Pillar_LawReg_Mapping PLM
	on (PLM.Id = C.Pillar_Lawreg_Mapping_Id)
Join Code_Value CV1 
	on (CV1.Code_ID = PLM.Pillar_Id and CV1.Code_Value_Key = PLM.Pillar_Key)
where PLM.Pillar_Key = 'PPN'

-- Insert into Project Funding
Insert into Project_Funding 
	(
		Project_Id, FY, Priority, MSC_Priority, HQ_Priority, 
		Validated, Programmed, Planned, 
		Funded, Obligated, Approval_Status_Id, Approval_Status_Key , IS_UFR, MDEP_Id, MDEP_Key
		,Funding_Status_Code_Id,Funding_Status_Code_Key
		,Created_By,Created_Date, Modified_By,Modified_Date 
	)
Select
	P.Id, FY.FY, 0, 0, 0, 
	CONVERT(decimal(9,2),P.ROI) * 90 , CONVERT(decimal(9,2),P.ROI) * 90 , CONVERT(decimal(9,2),P.ROI) * 80,
	CONVERT(decimal(9,2),P.ROI) * 70, CONVERT(decimal(9,2),P.ROI) * 60, 2010, 'FELI', 0,2019, 'VENQ',
	2024,'OBLI',
	@Created_Modified_User_Name, GETDATE(),@Created_Modified_User_Name, GETDATE()
from Project P
Cross Join Fiscal_Year FY
where P.Created_By = @Created_Modified_User_Name

-- Current fiscal year 2017 remove obligated values and set the funding status as "funded"
Update Project_Funding set Funding_Status_Code_Key = 'FUND', Obligated = 0 where FY = 2017

-- All future fiscal year funding information cleanup, since they wont ideally be funded right now
Update Project_Funding set Approval_Status_Key = 'PRCR', Funding_Status_Code_Key = 'UNFU', Planned = 0, Funded = 0, Obligated = 0, Validated = 0 where FY > 2017

-- Set source for the test projects as "STEP"
--Update Project set Source_Key = 'STEP'


-- Associate project owner for newly created users for testing purpose

Select @User_Id = Id from Users where Email_Id = 'HQ_Admin@amc.army.mil'
Select @User_Role_Id = Id from User_Role where User_Id = @User_Id

Update Project set Owner_Id = @User_Id, Created_User_Role_Id = @User_Role_Id where Hierarchy_Data_Id = 1

Select @User_Id = Id from Users where Email_Id = 'JMC_MSC_Admin@amc.army.mil'
Select @User_Role_Id = Id from User_Role where User_Id = @User_Id

Update Project set Owner_Id = @User_Id, Created_User_Role_Id = @User_Role_Id where Hierarchy_Data_Id = 9

Select @User_Id = Id from Users where Email_Id = 'TACOM_MSC_Admin@amc.army.mil'
Select @User_Role_Id = Id from User_Role where User_Id = @User_Id

Update Project set Owner_Id = @User_Id, Created_User_Role_Id = @User_Role_Id where Hierarchy_Data_Id = 22

Select @User_Id = Id from Users where Email_Id = 'TOAD_Inst_Admin@amc.army.mil'
Select @User_Role_Id = Id from User_Role where User_Id = @User_Id

Update Project set Owner_Id = @User_Id, Created_User_Role_Id = @User_Role_Id where Hierarchy_Data_Id = 10

Select @User_Id = Id from Users where Email_Id = 'BGAD_Inst_Admin@amc.army.mil'
Select @User_Role_Id = Id from User_Role where User_Id = @User_Id

Update Project set Owner_Id = @User_Id, Created_User_Role_Id = @User_Role_Id where Hierarchy_Data_Id = 21

Select @User_Id = Id from Users where Email_Id = 'SIAD_Inst_Admin@amc.army.mil'
Select @User_Role_Id = Id from User_Role where User_Id = @User_Id

Update Project set Owner_Id = @User_Id, Created_User_Role_Id = @User_Role_Id where Hierarchy_Data_Id = 24

Select @User_Id = Id from Users where Email_Id = 'RRAD_Inst_Admin@amc.army.mil'
Select @User_Role_Id = Id from User_Role where User_Id = @User_Id

Update Project set Owner_Id = @User_Id, Created_User_Role_Id = @User_Role_Id where Hierarchy_Data_Id = 25

