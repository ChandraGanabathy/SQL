

		Declare @Created_By varchar(100)
		Declare @Modified_By varchar(100)

		Select @Created_By = 'Plateauinc'
		Select @Modified_By = 'Plateauinc'
				
		BEGIN TRANSACTION;
		BEGIN TRY
				truncate table Role_Action

				Declare @Level1_Action_Not_Allowed Varchar(Max)  --WEBADMN
				Set @Level1_Action_Not_Allowed='61,62'				 
								
				Declare @Level2_Action_Not_Allowed Varchar(Max)  --HQADMN
				Set @Level2_Action_Not_Allowed='18,19,20,22,35,44,45,58,61,62'
				
				Declare @Level3_Action_Not_Allowed Varchar(Max)  --HQUSER
				Set @Level3_Action_Not_Allowed='3,4,6,9,14,15,16,17,18,19,20,21,22,27,32,30,36,35,43,44,45,46,47,48,50,57,58,61,62'

				Declare @Level4_Action_Not_Allowed Varchar(Max)  --HQREAD
				Set @Level4_Action_Not_Allowed='3,4,6,9,12,16,14,15,17,18,19,20,21,22,27,30,32,35,36,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,62'
				
				Declare @Level5_Action_Not_Allowed Varchar(Max)  --MSCADMN
				Set @Level5_Action_Not_Allowed='3,4,6,9,16,17,18,19,20,22,27,30,35,36,43,44,46,47,48,50,58,61,62'

				Declare @Level6_Action_Not_Allowed Varchar(Max)  --MSCUSER
				Set @Level6_Action_Not_Allowed='3,4,6,9,14,15,16,17,18,19,20,21,22,27,30,32,35,36,43,44,45,46,47,48,50,57,58,61,62'

				Declare @Level7_Action_Not_Allowed Varchar(Max)  --MSCREAD
				Set @Level7_Action_Not_Allowed='3,4,6,9,12,14,15,16,17,18,19,20,21,22,27,30,32,35,36,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,62'

				Declare @Level8_Action_Not_Allowed Varchar(Max)  --INSTADMN
				Set @Level8_Action_Not_Allowed='3,4,6,9,16,17,18,19,20,22,27,30,35,36,43,45,46,47,48,50,58,60,62'
				 
				Declare @Level9_Action_Not_Allowed Varchar(Max)  --INSTUSER
				Set @Level9_Action_Not_Allowed='3,4,6,9,16,14,15,17,18,19,20,21,22,27,30,31,32,35,36,43,44,45,46,47,48,50,57,58,60,62'

				Declare @Level10_Action_Not_Allowed Varchar(Max) --INSTREAD
				Set @Level10_Action_Not_Allowed='3,4,6,9,12,14,15,16,17,18,19,20,21,22,27,30,31,32,35,36,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,62'
				
				-- Get the number of rows in the Role table
				DECLARE @RowCount_Role INT
				SET @RowCount_Role =(SELECT COUNT(ID) FROM Role) 
				 -- Declare an iterator
				DECLARE @I_Role INT
				-- Initialize the iterator
				SET @I_Role = 1


				-- Loop through the rows of a table Role
				WHILE (@I_Role <= @RowCount_Role)
				BEGIN
									-- Get the number of rows in the Action table
							DECLARE @RowCount_Action INT
							SET @RowCount_Action = (SELECT COUNT(Id) FROM Action) 
							 -- Declare an iterator for Action Table
							DECLARE @I_Action INT
							-- Initialize the iterator
							SET @I_Action = 1


							-- Loop through the rows of a table Action
							WHILE (@I_Action <= @RowCount_Action)
							BEGIN
									-- Check and Set IsAllowed
															--Declare @IsAllowed Bit
															--Set @IsAllowed=1
															
															IF (@I_Role = 1)
																BEGIN
																IF NOT Exists (Select 1 from dbo.Split(@Level1_Action_Not_Allowed, ',') Where Data=@I_Action)
																BEGIN
																	INSERT INTO [dbo].[Role_Action]
																			([Role_Id],[Action_Id],[Created_By],[Created_Date],[Modified_By],[Modified_Date])
																	VALUES(@I_Role,@I_Action,@Created_By,GetDate(),@Modified_By,GetDate())
																END
															End
															IF (@I_Role = 2)
															Begin
																IF NOT Exists (Select 1 from dbo.Split(@Level2_Action_Not_Allowed, ',') Where Data=@I_Action)
																BEGIN
																	INSERT INTO [dbo].[Role_Action]
																		([Role_Id],[Action_Id],[Created_By],[Created_Date],[Modified_By],[Modified_Date])
																	VALUES(@I_Role,@I_Action,@Created_By,GetDate(),@Modified_By,GetDate())
																END
															End
															
															IF (@I_Role = 3)
															Begin
																IF NOT Exists (Select 1 from dbo.Split(@Level3_Action_Not_Allowed, ',') Where Data=@I_Action)
																BEGIN
																	INSERT INTO [dbo].[Role_Action]
																		([Role_Id],[Action_Id],[Created_By],[Created_Date],[Modified_By],[Modified_Date])
																	VALUES(@I_Role,@I_Action,@Created_By,GetDate(),@Modified_By,GetDate())
																END
															End
															
															IF (@I_Role = 4)
															Begin
																IF NOT Exists (Select 1 from dbo.Split(@Level4_Action_Not_Allowed, ',') Where Data=@I_Action)
																BEGIN
																	INSERT INTO [dbo].[Role_Action]
																		([Role_Id],[Action_Id],[Created_By],[Created_Date],[Modified_By],[Modified_Date])
																	VALUES(@I_Role,@I_Action,@Created_By,GetDate(),@Modified_By,GetDate())
																END
															End
															
															IF (@I_Role = 5)
															Begin
																IF  NOT Exists (Select 1 from dbo.Split(@Level5_Action_Not_Allowed, ',') Where Data=@I_Action)
																BEGIN
																	INSERT INTO [dbo].[Role_Action]
																		([Role_Id],[Action_Id],[Created_By],[Created_Date],[Modified_By],[Modified_Date])
																	VALUES(@I_Role,@I_Action,@Created_By,GetDate(),@Modified_By,GetDate())
																END
															End

															IF (@I_Role = 6)
															Begin
																IF  NOT Exists (Select 1 from dbo.Split(@Level6_Action_Not_Allowed, ',') Where Data=@I_Action)
																BEGIN
																	INSERT INTO [dbo].[Role_Action]
																		([Role_Id],[Action_Id],[Created_By],[Created_Date],[Modified_By],[Modified_Date])
																	VALUES(@I_Role,@I_Action,@Created_By,GetDate(),@Modified_By,GetDate())
																END
															End

															IF (@I_Role = 7)
															Begin
																IF  NOT Exists (Select 1 from dbo.Split(@Level7_Action_Not_Allowed, ',') Where Data=@I_Action)
																BEGIN
																	INSERT INTO [dbo].[Role_Action]
																		([Role_Id],[Action_Id],[Created_By],[Created_Date],[Modified_By],[Modified_Date])
																	VALUES(@I_Role,@I_Action,@Created_By,GetDate(),@Modified_By,GetDate())
																END
															End

															IF (@I_Role = 8)
															Begin
																IF  NOT Exists (Select 1 from dbo.Split(@Level8_Action_Not_Allowed, ',') Where Data=@I_Action)
																BEGIN
																	INSERT INTO [dbo].[Role_Action]
																		([Role_Id],[Action_Id],[Created_By],[Created_Date],[Modified_By],[Modified_Date])
																	VALUES(@I_Role,@I_Action,@Created_By,GetDate(),@Modified_By,GetDate())
																END
															End
															IF (@I_Role = 9)
															Begin
																IF  NOT Exists (Select 1 from dbo.Split(@Level9_Action_Not_Allowed, ',') Where Data=@I_Action)
																BEGIN
																	INSERT INTO [dbo].[Role_Action]
																		([Role_Id],[Action_Id],[Created_By],[Created_Date],[Modified_By],[Modified_Date])
																	VALUES(@I_Role,@I_Action,@Created_By,GetDate(),@Modified_By,GetDate())
																END
															End
															IF (@I_Role = 10)
															Begin
																IF  NOT Exists (Select 1 from dbo.Split(@Level10_Action_Not_Allowed, ',') Where Data=@I_Action)
																BEGIN
																	INSERT INTO [dbo].[Role_Action]
																		([Role_Id],[Action_Id],[Created_By],[Created_Date],[Modified_By],[Modified_Date])
																	VALUES(@I_Role,@I_Action,@Created_By,GetDate(),@Modified_By,GetDate())
																END
															End
															
															---- Insert Data Into Role_Action Table
															--Select 1 FROM [dbo].[Role_Action] WHERE Action_Id =@I_Action And Role_Id=@I_Role And is_Allowed=@IsAllowed
															--IF NOT EXISTS (Select 1 FROM [dbo].[Role_Action] WHERE Action_Id =@I_Action And Role_Id=@I_Role And is_Allowed=@IsAllowed)  
															--Begin
															--	INSERT INTO [dbo].[Role_Action]
															--			   ([Role_Id]
															--			   ,[Action_Id]
															--			   ,[is_Allowed]
															--			   ,[Created_By]
															--			   ,[Created_Date]
															--			   ,[Modified_By]
															--			   ,[Modified_Date])
															--	VALUES	  (@I_Role,
															--			   @I_Action,
															--			   @IsAllowed,
															--			   @Created_By,
															--			   GetDate(),
															--			   @Modified_By,
															--			   GetDate()	
															--			  )
															--End
									
									
								SET @I_Action = @I_Action + 1
							END
				
					SET @I_Role = @I_Role + 1
				END
	 
		COMMIT TRANSACTION
		--ROLLBACK TRANSACTION 
END TRY

BEGIN CATCH
SELECT 
         ERROR_NUMBER() AS ErrorNumber
        ,ERROR_SEVERITY() AS ErrorSeverity
        ,ERROR_STATE() AS ErrorState
        ,ERROR_PROCEDURE() AS ErrorProcedure
        ,ERROR_LINE() AS ErrorLine
        ,ERROR_MESSAGE() AS ErrorMessage;
		IF @@TRANCOUNT > 0
		BEGIN
			ROLLBACK TRANSACTION 
		END
END CATCH

GO 

--remove is_allowed column from Role Action table
IF EXISTS(SELECT * FROM SYS.COLUMNS WHERE Name = N'Is_Allowed' AND OBJECT_ID = OBJECT_ID(N'Role_Action'))
BEGIN
    ALTER TABLE dbo.Role_Action drop column Is_Allowed  
    Print 'Is_Allowed Column removed from Role Action Table'
END
GO

IF EXISTS(SELECT * FROM SYS.tables WHERE  OBJECT_ID = OBJECT_ID(N'Report_Role_Mapping'))
BEGIN
	drop table Report_Role_Mapping
END
GO
IF EXISTS(SELECT * FROM SYS.tables WHERE  OBJECT_ID = OBJECT_ID(N'Report'))
BEGIN
	drop table Report
END